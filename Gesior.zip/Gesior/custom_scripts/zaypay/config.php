<?php
$options[155461]['name'] = 'Buy 100 premium points';
$options[155461]['payalogue_id'] = 136569;
$options[155461]['price_id'] = 155461 ;
$options[155461]['price_key'] = '02e7503a4c3e0005eeb69d121b9da073';
$options[155461]['points'] = 100;

$options[155463]['name'] = 'Buy 250 premium points';
$options[155463]['payalogue_id'] = 136571;
$options[155463]['price_id'] = 155463;
$options[155463]['price_key'] = 'f3370f09e66d5369c05e0dcab02844d2';
$options[155463]['points'] = 250;

