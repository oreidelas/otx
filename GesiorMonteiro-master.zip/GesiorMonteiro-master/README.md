# Gesior
Gesior by: Leonardo Pereira and Marco Oliveira

This gesior aims to be as close as possible to the layout of the global tibia.
I ask your collaboration to make it possible, reporting bugs and failures in aac.

• The installation is very simple, just go in the config folder of the site!
----------------------------------------------------------------------------------

Website officially developed for <b>Malvera Server</b>.
It can be viewed at <b>malvera.online</b>.
