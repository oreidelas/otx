
<?php
Header ("Location: ../");
?>