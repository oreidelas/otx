<?PHP header("Content-Type: text/html; charset=UTF-8",true);
if(!defined('INITIALIZED'))
	exit;
$main_content .= '
	<div class="TopButtonContainer">
		<div class="TopButton">
		<a href="#top">
		<img style="border:0px;" src="./layouts/tibiacom/images/content/back-to-top.gif"></a></div></div>
		<div class="TableContainer">
	<div class="CaptionContainer">
							<div class="CaptionInnerContainer"> 
								<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>							
								<div class="Text">Donation Rules</div>
								<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
								<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
							</div>
						</div><table class="Table4" cellpadding="0" cellspacing="0">
						
						<tbody><tr>
							<td>
								
									<div class="InnerTableContainer">          
		<table style="width:100%;"><tbody><tr><td>
		<div class="TableShadowContainerRightTop">  
		<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div></div>
		<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
		<div class="TableContentContainer">    <table class="TableContent" width="100%"><tbody><tr><td><table style="width:100%;">
		<tbody>
		<tr><td>
<b>Before making a donation, remember to comply with current rules and aware of all the necessary information..</b><br><br>
			<textarea rows="10" wrap="physical" cols="100" readonly="true" width="100%" height="500px">
a) The Malvera is an alternative Tibia server planned, built and implemented within the existing rules that allow the operation thereof without breaking any law (whether national or not).
b) All the money deposited and credited on the server is directly applied to their own maintenance, that is, all the capital rotated around the same is directly channeled to the direction of self-sufficiency .
c) The Malvera struggle for stability, however, we can not prevent mistakes will happen.
d) The history of donations is being saved, meaning you will never be forgotten.
e) The name assigned to the central points exchanges - Malvera Shop - is fictitious; the Malvera not sell any kind of product.

2. Loss &amp; Damage
a) Save your gift voucher. It is the only document that proves your help for server maintenance.
b) If resets all donations that were made will not be recreditadas to player accounts.
c) In case of falls and (or) problems that cause the Malvera go offline or waiting for three consecutive days or more , players who have chosen to charge your VIP time points will be re-credited in the same way, the lost days (counting from the third day).
d) In case of unexpected stoppage of activities, there will be no replacement or recreditação of invested capital on the server, since every donation is directly sent to maintenance. In this case , players will be notified by the vehicle information (official website or forum).
e) In case of pre -programmed stoppage of activities , players will be informed through our vehicle information and the date that the donation system will be out of air.
f) The Malvera offers and invests in basic security for the server , up to you to keep it safe; ie not responsible for their pertencens, characters and accounts.

3. Denotation # Donation
a) Act or effect of giving. 
b) What gives himself.
c) Contract or document that ensures and legalizes the simple gift : that is made by unique resolution of the donor.
</textarea><br><br>
The rules and information set forth in the above dialog box can be modified without notice.<br>
If you do not agree with the hiring of the simple donation please do not proceed.<br>

		</td></tr>
		</tbody></table></td>
		  </tr></tbody></table>  </div></div><div class="TableShadowContainer"> 
		<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">   
		<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>  
		<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div> 
		</div></div></td></tr>          </tbody></table>        </div>
								
							</td></tr></tbody></table>
						</div>
';
?>