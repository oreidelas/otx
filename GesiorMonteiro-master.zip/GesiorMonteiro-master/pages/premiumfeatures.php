<?PHP header("Content-Type: text/html; charset=UTF-8",true);
if(!defined('INITIALIZED'))
	exit;
$main_content .= '
<H3>Why Should You Make Your Account Premium?</H3>

Tibia is free, and players are welcome to play free of charge for as long as they like. However, if you enjoy Tibia, you may consider to take the game further by buying Premium Time. As a premium player you will have additional abilities and advantages inside and outside the game. Buy Premium Time today to make Tibia even more fun!<BR><BR>

The following benefits are available to premium players:<BR><BR>

<TABLE><TR><TD><IMG SRC="http://static.tibia.com/images/global/general/blank.gif" WIDTH=10 HEIGHT=1 BORDER=0></TD><TD><TABLE>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Access to Premium Areas</B><BR>As a premium player you can travel to new, exciting places you have never seen before. Visit the mysterious magical academy in Edron, explore the weather-beaten shores of Quirefang and wander through the not quite deserted streets of the fallen city of Yalahar! Brave the unforgiving cold on the Ice Islands or head south to the pirate-infested waters of the legendary Shattered Isles! Join the desperate fight against the forces that are corrupting the once-mighty lizard empire of Zao or unravel the secrets of the past in the sands of the Ankrahmun! There are whole new continents are out there waiting for you to explore them! Even Rookgaard boasts its own exclusive premium area! Visit new cities! Do new quests! Battle new monsters! You will find that, as a premium player, there is simply much more to see and more to do!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Transportation</B><BR>All premium player can use the Tibian transport system. There are ships and magic carpets available for a comfortable journey. For a small fee our captains will bring you to all cities and even to some remote islands. Premium Time will surely save you some long and tiresome marches!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Improved Login</B><BR>
When a game world is getting close to its maximum capacity, only premium players are still admitted to this game world, while characters on free accounts must wait. Of course once the maximum capacity of a game world has been reached, no further characters can log in.</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Cool New Spells</B><BR>
The mighty wizards from the magic guild of Edron have developed new spells. Cast haste on your character and run away from your enemies! Fry your opponents with the mighty Hells Core! From useful everyday spells to powerful offensive magic, premium players simply have more spells to cast!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Character Promotions</B><BR>
Premium characters of level 20 or higher can be promoted to a veteran rank which results in several important advantages over regular characters. To name but a few, promoted characters regenerate mana, soul points and hit points faster than regular players, and they lose fewer experience points and skills upon death. Bring out the best in your characters and promote them today!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Loyalty System</B><BR>
Premium players benefit from our loyalty system. Characters on accounts who had premium status for a longer time do not only receive great titles and might appear in the loyalty highscores of their game world, but they also benefit from enhanced skills.</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Arenas</B><BR>
Dying without a death penalty? The Tibian gods love to watch a good fight and so they decided that they will resurrect all defeated characters for free that courageously rise to the challenge of a tough battle in one of Tibia arenas. Premium players cannot only prove their combat skills here without the risk of losing something, the most skilful fighters can even win some nice prizes.</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Improved Stamina</B><BR>
Only premium players have improved stamina which will temporarily gain them 50% more of the regular experience points for killing monsters. So premium players can raise in levels even quicker!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Offline Training</B><BR>
As you progress, training your favourite characters skills can become hard work ... but not if you are a premium player! If your account is premium, you can train your characters skills even while you are offline! Why toil on the battlefield for hours on end to raise your characters skills when they can train them in their sleep!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Renting Houses</B><BR>
Premium players are allowed to rent houses or flats in which your characters can recover from the hardships of an adventurers life. Furnish your new home with all kinds of furniture and impress your fellow Tibians with your stately home! Invite your friends and have parties! You will find that having a home of your own is a rewarding experience you will never want to miss once you have had it!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Placing Market Offers</B><BR>
Want to sell your loot fast and effectively? Offer it in the Market. Only premium players are able to place buy and sell offers there.</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Guild Leadership</B><BR>
Why serve in heaven when you can rule in hell? As a premium player you can found a guild of your own. Choose your own cool name and logo, recruit followers and rent a nice guildhall! As a premium player you will be able to build up the guild of your dreams. Make a name for yourself as the leader of a powerful Tibia guild!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Access to a Premium-Only Game World</B><BR>
Looking for a smaller community? The world of Premia might be just what you are looking for! A world that is exclusively reserved to premium players, Premia has fewer inhabitants than other worlds. If you are looking for less crowded dungeons, you should come over to Premia today!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Improved Chat Options</B><BR>
Premium players are allowed to open up private chat channels to which they can invite their friends. Also, if you are a premium player, your VIP list will be greatly enlarged in size. With up to 100 players on your list you will always know when your friends and foes are online!</TD></TR>
<TR><TD valign=top><IMG SRC="\layouts\tibiacom\images\content\bullet.gif" width=12 height=15 border=0 align=top></TD><TD><B>Larger Depots</B><BR>
As a premium player you can store even more items in your depot chest. Instead of just 2,000 items like free account characters, characters on premium accounts can store up to 10,000 items in their depot chest.</TD></TR>
</TABLE></TD><TD><IMG SRC="layouts\tibiacom\images\general/blank.gif" WIDTH=10 HEIGHT=1 BORDER=0></TD></TR></TABLE><BR>

Please note this is not an exhaustive list. Other benefits are sure to follow, but it is also possible that existing ones are changed or even removed in future. Best of all, Tibia Premium Time is inexpensive! You can upgrade your account to premium starting from as little as EUR 5.83 for a month:<BR><BR>

<TABLE WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=4>
<TR><TD BGCOLOR="#505050" CLASS=white COLSPAN=3><B>Tibia Premium Time (can only be used for your own account)</B></TD></TR>
<TR BGCOLOR="#D4C0A1"><TD WIDTH=35%><B>Duration</B></TD><TD WIDTH=35%><B>Price</B></TD><TD></TD></TR>
<TR BGCOLOR="#F1E0C6"><TD>1 month (30 days)</TD><TD>EUR 8.45</TD><TD></TD></TR>
<TR BGCOLOR="#D4C0A1"><TD>3 months (90 days)</TD><TD>EUR 22.35</TD><TD></TD></TR>
<TR BGCOLOR="#F1E0C6"><TD>6 months (180 days)</TD><TD>EUR 39.95</TD><TD></TD></TR>
<TR BGCOLOR="#D4C0A1"><TD>12 months (360 days)</TD><TD>EUR 69.95</TD><TD></TD></TR>
</TABLE><BR>
And that is not all, you can also buy Premium Time for Tibia Coins in the store ingame! As Tibia Coins can also be sold in the Market for Tibia gold, you can purchase them and buy Premium Time or an extra service for your account even if you find yourself unable to pay with real money for Premium Time or Tibia Coins right now. There really is no excuse not to make your account premium - buy Premium Time or Tibia Coins and enjoy the full Tibia experience today!</BR></BR>
<TABLE WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=4>
<TR><TD BGCOLOR="#505050" CLASS=white COLSPAN=3><B>Tibia Coin Packages (Tibia Coins can be used to purchase Premium Time or special products for your own account in the Store, or if transferable, traded via the Market or gifted to other characters)</B></TD></TR>
<TR BGCOLOR="#D4C0A1"><TD WIDTH=25%><B>Package</B></TD><TD WIDTH=30%><B>Price</B></TD><TD></TD></TR>
<TR BGCOLOR="#F1E0C6"><TD>250 Tibia Coins</TD><TD>EUR 8.95</TD><TD></TD></TR>
<TR BGCOLOR="#D4C0A1"><TD>750 Tibia Coins</TD><TD>EUR 24.95</TD><TD></TD></TR>
<TR BGCOLOR="#F1E0C6"><TD>1500 Tibia Coins</TD><TD>EUR 49.90</TD><TD></TD></TR>
<TR BGCOLOR="#D4C0A1"><TD>3000 Tibia Coins</TD><TD>EUR 99.80</TD><TD></TD></TR>
<TR BGCOLOR="#F1E0C6"><TD>4500 Tibia Coins</TD><TD>EUR 149.70</TD><TD></TD></TR>
</TABLE><BR>
';
?>