<?PHP header("Content-Type: text/html; charset=UTF-8",true);
if(!defined('INITIALIZED'))
	exit;
$main_content .= '
<div class="BoxContent" style="background-image:url(./layouts/tibiacom/images/content/scroll.gif)">

	<center><font size="5"><b>Reward Chest System</b></font><br><br>
<img src="/images/reward.png" alt="Reward Chest"></center><br>

		<div class="TableContainer">
			<div class="CaptionContainer">
					<div class="CaptionInnerContainer"> 
						<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
						<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
						<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
						<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>						
						<div class="Text">Reward System</div>
						<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
						<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
						<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
						<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
					</div>
				</div><table class="Table3" cellpadding="0" cellspacing="0">
				
				<tbody><tr>
					<td><div class="InnerTableContainer">
						<table style="width:100%;">
							<tbody><tr>
								<td>
									<div class="TableShadowContainerRightTop">
											<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div>
										</div>
										<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
											<div class="TableContentContainer">
												<table class="TableContent" width="100%">
													<tbody><tr bgcolor="#D4C0A1">
														<td>On Update 10.20 was implemented the Reward System, in it all players who participated in the struggle against bosses receive an individual creature loot.</td>
													</tr>
												</tbody></table>
											</div>
										</div>
										<div class="TableShadowContainer">
											<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">
												<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>
												<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div>
											</div>
										</div>
									</td>
								</tr></tbody></table>
								<table style="width:100%;">
								<tbody><tr>
									<td><div class="TableShadowContainerRightTop">
											<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div>
										</div>
										<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
											<div class="TableContentContainer">
												<table class="TableContent" width="100%">
													<tbody><tr bgcolor="#D4C0A1">
														<td>Unlike the common loot creatures, the loot from bosses are sent directly to the Reward Chest after the boss corpse disappears, the Reward Chest is located in Adventures Guild to access use a Adventurers Stone inside a temple.									
														<br><br><b>This differentiated loot system brings some advantages to the player:</b>
														<br><br><b>1.</b> It gives the possibility to all players who participated in the fight with the boss get access to the loot.
														<br><b>2.</b> Depending of participation level in the fight the boss gives the right to have a loot with better items. After the creatures being killed, the creatures items are divided to players based on some criteria, check the table below.														
														<br></td>
													</tr>
												</tbody></table>
											</div>
										</div>
										<div class="TableShadowContainer">
											<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">
												<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>
												<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div>
											</div>
										</div>
										
									</td>
								</tr>
							</tbody></table>
						</div>
					</td>
				</tr>
			</tbody></table>
		</div><br><div class="TableContainer">
			<div class="CaptionContainer">
					<div class="CaptionInnerContainer"> 
						<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
						<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
						<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
						<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>						
						<div class="Text">Participation level</div>
						<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
						<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
						<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
						<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
					</div>
				</div><table class="Table3" cellpadding="0" cellspacing="0">
				
				<tbody><tr>
					<td><div class="InnerTableContainer">
						<div style="margin:15px 0px 15px 0px">
							<table border="0" style="width: 99%; border-radius:5px; border:1px dashed #A7D7F9; background-color:#EEF6FA; padding:2px">
								<tbody><tr>
									<td><b>Notice:</b> How greater damage to the Boss generate greater level of participation, however block the creature will also reckon points.</td>
								</tr>
							</tbody></table>
						</div>
						<table style="width:100%;">
							
							<tbody><tr>
								<td><div class="TableShadowContainerRightTop">
										<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div>
									</div>
									<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
										<div class="TableContentContainer">
											<table class="TableContent" width="100%">
												<tbody><tr bgcolor="#D4C0A1">
													<td width="60%"><b><center>Loot</center></b></td>
													<td width="15%"><b>Points</b></td>
													<td width="10%"><b>Level</b></td>
												</tr>
												<tr bgcolor="#F1E0C6">
													<td width="60%">Item Comum</td>
													<td width="15%">10~40pts</td>
													<td width="10%">1</td>
												</tr>
												<tr bgcolor="#D4C0A1">
													<td width="60%">Common Item + Semi Rare Item</td>
													<td width="15%">40~60pts</td>
													<td width="10%">2</td>
												</tr>
												<tr bgcolor="#F1E0C6">
													<td width="60%">Common Item + Semi Rare Item + Rare Item</td>
													<td width="15%">60~80pts</td>
													<td width="10%">3</td>
												</tr>
												<tr bgcolor="#D4C0A1">
													<td width="60%">Common Item + Semi Rare Item + Rare Item + Very Rare Item</td>
													<td width="15%">80~95pts</td>
													<td width="10%">4</td>
												</tr>
												<tr bgcolor="#F1E0C6">
													<td width="60%">Common Item + Semi Rare Item + Rare Item + Item that always drop</td>
													<td width="15%">96~100pts</td>
													<td width="10%">5</td>
												</tr>
											</tbody></table>
										</div>
									</div>
									<div class="TableShadowContainer">
										<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">
											<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>
											<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div>
										</div>
									</div>
								</td>
							</tr>
							</tbody></table>
							<table style="width:100%;">
							<tbody><tr>
								<td><div class="TableShadowContainerRightTop">
										<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div>
									</div>
									<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
										<div class="TableContentContainer">
											<table class="TableContent" width="100%">
												<tbody><tr bgcolor="#D4C0A1">
													<td>The player who get level 1 will only receive money or other common items.</td>
												</tr>
											</tbody></table>
										</div>
									</div>
									<div class="TableShadowContainer">
										<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">
											<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>
											<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div>
										</div>
									</div>
								</td>
							</tr>	
						</tbody></table>
					</div>
				</td>
			</tr>
		</tbody></table>
	</div><br><div class="TableContainer">
		<div class="CaptionContainer">
				<div class="CaptionInnerContainer"> 
					<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
					<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
					<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
					<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>						
					<div class="Text">Reward System Bosses</div>
					<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
					<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
					<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
					<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
				</div>
			</div><table class="Table3" cellpadding="0" cellspacing="0">
			
			<tbody><tr>
				<td>
					<div class="InnerTableContainer">
						<table style="width:100%;">	
							<tbody><tr>
								<td><div class="TableShadowContainerRightTop">
										<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div>
									</div>
									<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
										<div class="TableContentContainer">
											<table class="TableContent" width="100%">
												<tbody><tr bgcolor="#D4C0A1">
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/a/a3/The_Welter.gif"><li>The Welter</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/a/ab/White_Pale.gif"><li>White Pale</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/7/7c/Tyrn.gif"><li>Tyrn</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/9/93/Hirintror.gif"><li>Hirintror</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/b/b5/Zushuka.gif"><li>Zushuka</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/8/85/Ocyakao.gif"><li>Ocyakao</li></td>
												</tr>
												<tr bgcolor="#F1E0C6">
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/f/f2/Shlorg.gif"><li>Shlorg</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/1/11/The_Pale_Count.gif"><li>The Pale Count</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/e/e1/Furyosa.gif"><li>Furyosa</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/2/2f/Mad_Mage.gif"><li>Mad Mage</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/9/90/Raging_Mage.gif"><li>Raging Mage</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/0/0f/Ferumbras.gif"><li>Ferumbras</li></td>
												</tr>
												<tr bgcolor="#D4C0A1">
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/c/ce/Morgaroth.gif"><li>Morgaroth</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/5/5e/Ghazbaran.gif"><li>Ghazbaran</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/c/ce/Orshabaal.gif"><li>Orshabaal</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/b/ba/Zulazza_the_Corruptor.gif"><li>Zulazza the Corruptor</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/f/fa/Chizzoron_the_Distorter.gif"><li>Chizzoron the Distorter</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/7/7b/The_Mutated_Pumpkin.gif"><li>The Mutated Pumpkin</li></td>
												</tr>
												<tr bgcolor="#F1E0C6">
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/1/13/Bibby_Bloodbath.gif"><li>Bibby Bloodbath</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/6/63/Gaz%27Haragoth.gif"><li>GazHaragoth</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/6/67/Tanjis.gif"><li>Tanjis</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/8/84/Jaul.gif"><li>Jaul</li></td>
													<td width="15%" align="center"><img src="http://www.tibiawiki.com.br/images/0/01/Obujos.gif"><li>Obujos</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/0/0e/Tarbaz.gif"><li>Tarbaz</li></td>
												</tr>
												<tr bgcolor="#D4C0A1">														
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/3/34/Shulgrax.gif"><li>Shulgrax</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/2/2b/The_Lord_of_the_Lice.gif"><li>The Lord of The Lice</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/f/fd/Plagirath.gif"><li>Plagirath</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/b/b1/Zamulosh.gif"><li>Zamulosh</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/b/b4/Mazoran.gif"><li>Mazoran</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/5/56/The_Shatterer.gif"><li>The Shatterer</li></td>
												</tr>
												<tr bgcolor="#F1E0C6">
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/d/db/Razzagorn.gif"><li>Razzagorn</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/7/75/Ragiaz.gif"><li>Ragiaz</li></td>
													<td width="15%" align="center"><img src="http://tibiawiki.com.br/images/f/f1/Ferumbras_Mortal_Shell.gif"><li>Ferumbras Mortal Shell</li></td>
													<td width="15%" align="center"></td>
													<td width="15%" align="center"></td>
													<td width="15%" align="center"></td>
												</tr>
											</tbody></table>
										</div>
									</div>
									<div class="TableShadowContainer">
										<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">
											<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>
											<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div>
										</div>
									</div>
								</td>
							</tr>
						</tbody></table>
					</div>
				</td>
			</tr>
		</tbody></table>
		</div></div>
';
?>