<?PHP header("Content-Type: text/html; charset=UTF-8",true);
if(!defined('INITIALIZED'))
	exit;
	$main_content .= '
	<div class="TopButtonContainer">
		<div class="TopButton">
		<a href="#top">
		<img style="border:0px;" src="./layouts/tibiacom/images/content/back-to-top.gif"></a></div></div>
		<div class="TableContainer">
	<div class="CaptionContainer">
							<div class="CaptionInnerContainer"> 
								<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>							
								<div class="Text">General Information</div>
								<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
								<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
							</div>
						</div><table class="Table4" cellpadding="0" cellspacing="0">
						
						<tbody><tr>
							<td>
								
									<div class="InnerTableContainer">          
		<table style="width:100%;"><tbody><tr><td>
		<div class="TableShadowContainerRightTop">  
		<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div></div>
		<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
		<div class="TableContentContainer">    <table class="TableContent" width="100%"><tbody><tr><td><table style="width:100%;">
		<tbody>
		<tr><td>
		<b>Ip:</b> malvera.oline </p><b>Port:</b> 7171</p><b>Version:</b> 10.99 | 11.00
		</td></tr>
		</tbody></table></td>
		  </tr></tbody></table>  </div></div><div class="TableShadowContainer"> 
		<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">   
		<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>  
		<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div> 
		</div></div></td></tr>          </tbody></table>        </div>
								
							</td></tr></tbody></table>
						</div>
	<div>   </div>
	
	
	<div class="TopButtonContainer">
		<div class="TopButton">
		<a href="#top">
		<img style="border:0px;" src="./layouts/tibiacom/images/content/back-to-top.gif"></a></div></div>
		<div class="TableContainer">
	<div class="CaptionContainer">
							<div class="CaptionInnerContainer"> 
								<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>							
								<div class="Text">Server Info</div>
								<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
								<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
							</div>
						</div><table class="Table4" cellpadding="0" cellspacing="0">
						
						<tbody><tr>
							<td>
								
									<div class="InnerTableContainer">          
		<table style="width:100%;"><tbody><tr><td>
		<div class="TableShadowContainerRightTop">  
		<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div></div>
		<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
		<div class="TableContentContainer">    <table class="TableContent" width="100%"><tbody><tr><td><table style="width:100%;">
		<tbody>
		<tr>
                           
						   
		<table width="100%" style="border:2px solid #D4C0A1;border-spacing: 0px;"> <tbody> <tr align="center" bgcolor="#D4C0A1"> <td><b>From Level</b></td> <td><b>To Level</b></td> <td><b>Rate</b></td> </tr> 
		
		<tr align="center" bgcolor="#F1E0C6">
		<td>1</td> <td> 10</td> <td> 50x</td> </tr> 
		
		<tr align="center" bgcolor="#D4C0A1">
		<td>11</td> <td> 50</td> <td> 200x</td> </tr> 
		
		<tr align="center" bgcolor="#F1E0C6">
		<td>51</td> <td> 80</td> <td> 150x</td> </tr> 
		
		<tr align="center" bgcolor="#D4C0A1">
		<td>81</td> <td> 100</td> <td> 100x</td> </tr> 		
		
		<tr align="center" bgcolor="#F1E0C6">
		<td>101</td> <td> 120</td> <td> 80x</td> </tr> 
		
		<tr align="center" bgcolor="#D4C0A1">
		<td>121</td> <td> 140</td> <td> 60x</td> </tr> 
	
		<tr align="center" bgcolor="#F1E0C6">
		<td>141</td> <td> 160</td> <td> 40x</td> </tr> 
						   		
		<tr align="center" bgcolor="#D4C0A1">
		<td>161</td> <td> 180</td> <td> 20x</td> </tr> 
	
		<tr align="center" bgcolor="#F1E0C6">
		<td>181</td> <td> 200</td> <td> 15x</td> </tr> 
				
		<tr align="center" bgcolor="#D4C0A1">
		<td>201</td> <td> 220</td> <td> 10x</td> </tr> 
	
		<tr align="center" bgcolor="#F1E0C6">
		<td>221</td> <td> 240</td> <td> 8x</td> </tr> 
				
		<tr align="center" bgcolor="#D4C0A1">
		<td>241</td> <td> 260</td> <td> 6x</td> </tr> 
	
		<tr align="center" bgcolor="#F1E0C6">
		<td>261</td> <td> 280</td> <td> 4x</td> </tr> 
				
		<tr align="center" bgcolor="#D4C0A1">
		<td>281</td> <td> 300</td> <td> 3x</td> </tr> 
	
		<tr align="center" bgcolor="#F1E0C6">
		<td>301</td> <td></td> <td> 2x</td> </tr> 
						   
		</td></tr>
		</tbody></table></td>
		</tr></tbody></table>  </div></div>
		<div class="TableShadowContainer"> 
		<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">   
		<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>  
		<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div> 
		</div></div></td></tr>          </tbody></table>        </div>
								
							</td></tr></tbody></table>
						</div>
	<div>   </div>	
	
	
	
	
	
	<div class="TopButtonContainer">
		<div class="TopButton">
		<a href="#top">
		<img style="border:0px;" src="./layouts/tibiacom/images/content/back-to-top.gif"></a></div></div>
		<div class="TableContainer">
	<div class="CaptionContainer">
							<div class="CaptionInnerContainer"> 
								<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>							
								<div class="Text">Server Rates</div>
								<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
								<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
								<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
								<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span>
							</div>
						</div><table class="Table4" cellpadding="0" cellspacing="0">
						
						<tbody><tr>
							<td>
								
									<div class="InnerTableContainer">          
		<table style="width:100%;"><tbody><tr><td>
		<div class="TableShadowContainerRightTop">  
		<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div></div>
		<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
		<div class="TableContentContainer">    <table class="TableContent" width="100%"><tbody><tr><td><table style="width:100%;">
		<tbody>
		<tr>
                                <td><b>Skills</b></td><td>50x</td>
                        </tr>
                        <tr bgcolor="#F1E0C6">
                                <td><b>Magic</b></td><td>10x</td>
                        </tr>
                        <tr bgcolor="#D4C0A1">
                                <td><b>Loot</b></td><td>4x</td>
                        </tr>
                        <tr bgcolor="#F1E0C6">
                                <td><b>Spawn</b></td><td>1x</td>
                        </tr>
		</td></tr>
		</tbody></table></td>
		  </tr></tbody></table>  </div></div><div class="TableShadowContainer"> 
		<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">   
		<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>  
		<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div> 
		</div></div></td></tr>          </tbody></table>        </div>
								
							</td></tr></tbody></table>
						</div>
	<div>   </div>



		
	<div>   </div>					
	<div class="TableContainer">
			<div class="CaptionContainer">
				<div class="CaptionInnerContainer"> 
					<span class="CaptionEdgeLeftTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span> 
					<span class="CaptionEdgeRightTop" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span> 
					<span class="CaptionBorderTop" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
					<span class="CaptionVerticalLeft" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>
					<div class="Text">Donate System and Shop Online</div>
					<span class="CaptionVerticalRight" style="background-image:url(./layouts/tibiacom/images/content/box-frame-vertical.gif);"></span> 
					<span class="CaptionBorderBottom" style="background-image:url(./layouts/tibiacom/images/content/table-headline-border.gif);"></span> 
					<span class="CaptionEdgeLeftBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span> 
					<span class="CaptionEdgeRightBottom" style="background-image:url(./layouts/tibiacom/images/content/box-frame-edge.gif);"></span> 
				</div>
			</div>
			<table class="Table5" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<td>
							<div class="InnerTableContainer">
								<table style="width:100%;">
									<tbody><tr>
										<td>
											<div class="TableShadowContainerRightTop">
												<div class="TableShadowRightTop" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rt.gif);"></div>
											</div>
											<div class="TableContentAndRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-rm.gif);">
												<div class="TableContentContainer">
													<table class="TableContent" width="100%">
														<tbody><tr style="background-color:#D4C0A1;">
															<td>
																<strong>Understand how to use our donation system and the online shop.</strong>
																<p>We have the most common donation systems, where our users have practicality in their donations and their item purchases on the server. Thinking of making your journey in our server slightly more attractive, we developed a unique in-game shop system where you will be happy to help the server to grow.</p><br><p>You can buy '.$config['pagseguro']['produtoNome'] .' <a href="?subtopic=buypoints">here</a> and use to buy Special Items in <a href="http://www.tibiawiki.com.br/wiki/Store" target="_blank">Store</a></p>
															</td>
															<td width="30%"><img src="images/info.jpg"></td>
														</tr>
													</tbody></table>
												</div>
											</div>
											<div class="TableShadowContainer">
												<div class="TableBottomShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bm.gif);">
													<div class="TableBottomLeftShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-bl.gif);"></div>
													<div class="TableBottomRightShadow" style="background-image:url(./layouts/tibiacom/images/content/table-shadow-br.gif);"></div>
												</div>
											</div>
										</td>
									</tr>
								</tbody></table>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	';