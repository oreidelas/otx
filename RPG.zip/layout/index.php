<?php include 'layout/overall/header.php'; ?>

<h1>RPG Layout converted by HalfAway.</h1>
<p>Because ZnoteAAC is awesome.</p>

<?php include 'layout/overall/footer.php'; ?>