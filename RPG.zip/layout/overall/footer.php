						</div>
				        <p>&nbsp;</p>
				        <p>&nbsp;</p>
				    </div>
      				<div class="botcontainer"></div>
    			</div>
   				<div class="menu">
      				<div class="topmenu"></div>
     				<div class="mainmenu">
        				<div class="menuzone">
          					<p><img src="layout/images/newsmenu.png" width="250" height="55" /></p>
          					<ul>
          						<li><a href="index.php">Latest News</a></li>
								<li><a href="changelog.php">Changelog</a>
							</ul>

							<img src="layout/images/accountmenu.png" width="250" height="55" /></li>
							<ul>
							<?php if (user_logged_in() === true) { ?>
							  	<li><a href="myaccount.php">My Account</a></li>
							  	<li><a href="createcharacter.php">Create Character</a></li>
							  	<li><a href="changepassword.php">Change Password</a></li>
							  	<li><a href="settings.php">Settings</a></li>
							  	<li><a href="logout.php">Logout</a></li>
								<?php if (user_logged_in() && is_admin($user_data)) include 'layout/widgets/Wadmin.php'; ?>
							<?php } else { ?>
								<li><a href="sub.php?page=login">Login</a></li>
								<li><a href="register.php">Create Account</a></li>
								<li><a href="recovery.php">Lost Account?</a></li>
							<?php } ?>
							</ul>

							<img src="layout/images/communitymenu.png" width="250" height="55" />
							<ul>
								<li><a href="highscores.php">Highscores</a></li>
								<li><a href="forum.php">Forum</a></li>	
								<li><a href="sub.php?page=characters">Characters</a></li>
								<li><a href="guilds.php">Guilds</a></li>
								<li><a href="killers.php">Top fraggers</a></li>	
								<li><a href="houses.php">Houses</a></li>	
								<li><a href="deaths.php">Latest Deaths</a></li>	
								<li><a href="gallery.php">Gallery</a></li>	
							</ul>

							<img src="layout/images/donatemenu.png" width="250" height="55" />
							<ul>
								<li><a href="buypoints.php">Buy Points</a></li>	
								<li><a href="shop.php">Shop</a></li>
							</ul>
       					</div>
      				<div class="botmenu"></div>
    			</div>
   				<p>&nbsp;</p>
  			</div>
  		<div class="botcont"></div>
	</div>
	<div class="footer">
		<p>&copy; <?php echo $config['site_title'];?>.
		<?php 
			echo 'Server date and clock is: '. getClock(false, true) .' Page generated in '. elapsedTime() .' seconds. Q: '.$aacQueries;
		?>
  		<br/><b>Templated by</b> <a href="https://otland.net/members/lanceq.148307/" target="_blank">Lanceq</a> | <b>Converted to ZnoteAAC by</b> <a href="http://otland.net/members/halfaway.142275/" target="_blank">HalfAway</a>.<br/>
  		Engine: <a href="credits.php">Znote AAC</a></p>
	</div>
</div>
</body>
</html>
