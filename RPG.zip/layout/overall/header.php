<?php
	$time = microtime();
	$time = explode(' ', $time);
	$time = $time[1] + $time[0];
	$start = $time;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="layout/style/style.css" rel="stylesheet" type="text/css" />
	<title><?php echo $config['site_title']; ?></title>
</head>
<body>
	<div id="wrapper">
		<div id="apDiv3">
			<center>
				<div>
					<?php
					$status = true;
					if ($config['status']['status_check']) {
						@$sock = fsockopen ($config['status']['status_ip'], $config['status']['status_port'], $errno, $errstr, 1);
						if(!$sock) {
							echo "<b>Status:</b> <span style='color:red;font-weight:bold;'>Offline!</span><br/>";
							$status = false;
						}
						else {
							$info = chr(6).chr(0).chr(255).chr(255).'info';
							fwrite($sock, $info);
							$data='';
							while (!feof($sock))$data .= fgets($sock, 1024);
							fclose($sock);
							echo "<b>Status:</b> <span style='color:green;font-weight:bold;'>Online!</span><br />";
						}
					}
					if ($status) {
						?>
						<a href="onlinelist.php">Players online: 
							<?php echo user_count_online(); ?></a><br/>
						<?php
					}
					?>
					<b>Registered accounts:</b> <?php echo user_count_accounts();?>
				</div>
			</center>
		</div>
		<div class="page">
		  	<div class="header"></div>
			<div class="navbar">
			    <center>
				<?php if (user_logged_in() === true) { ?>
					<a href="myaccount.php"><img src="layout/images/account.png" /></a>
				<?php } else { ?>
					<a href="sub.php?page=login"><img src="layout/images/account.png" /></a>
				<?php } ?>
					<a href="index.php"><img src="layout/images/news.png" /></a>
					<a href="highscores.php"><img src="layout/images/highscores.png" /></a>
					<a href="onlinelist.php"><img src="layout/images/online.png" /></a>
					<a href="forum.php"><img src="layout/images/forum.png" /></a>
					<a href="buypoints.php"><img src="layout/images/donate.png" /></a>
					<img src="layout/images/loginpanel.png" />
			    </center>
			</div>
			<div class="topcont"></div>
			<div class="maincont">
			    <div class="container">
			    	<div class="topcontainer"></div>
			   		<div class="maincontainer">
			     		<div class="newsbox">