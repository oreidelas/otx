<?php
	include 'layout/widgets/charactersearch.php'; 
?>