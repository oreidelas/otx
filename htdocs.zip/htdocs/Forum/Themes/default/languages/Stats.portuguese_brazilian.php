<?php
// Version: 1.1; Stats

$txt[888] = 'M&aacute;ximo de Usu&aacute;rios Online';

$txt['smf_stats_1'] = 'Centro de Estat&iacute;sticas';
$txt['smf_stats_2'] = 'Estat&iacute;sticas Gerais';
$txt['smf_stats_3'] = 'Top 10 Membros (por Mensagens)';
$txt['smf_stats_4'] = 'Top 10 F&oacute;rum';
$txt['smf_stats_5'] = 'Hist&oacute;rico (data do F&oacute;rum)';
$txt['smf_stats_6'] = 'Data (aaaa/mm/dd)';
$txt['smf_stats_7'] = 'Novos T&oacute;picos';
$txt['smf_stats_8'] = 'Novas Mensagens';
$txt['smf_stats_9'] = 'Novos Membros';
$txt['smf_stats_10'] = 'Hits';
$txt['smf_stats_11'] = 'Top 10 T&oacute;picos (por Respostas)';
$txt['smf_stats_12'] = 'Top 10 T&oacute;picos (por Visualiza&ccedil;&otilde;es)';
$txt['smf_stats_13'] = 'Resumo mensal';
$txt['smf_stats_14'] = 'Usu&aacute;rios Online';
$txt['smf_stats_15'] = 'Quem iniciou Mais T&oacute;picos';
$txt['smf_stats_16'] = 'Quem passou Mais Tempo Online';
$txt['smf_stats_17'] = 'Alto Karma';
$txt['smf_stats_18'] = 'Baixo Karma';
$txt['stats_more_detailed'] = 'mais detalhadas &raquo;';

$txt['average_members'] = 'M&eacute;dia de Novos Membros por dia';
$txt['average_posts'] = 'M&eacute;dia de Mensagens por dia';
$txt['average_topics'] = 'M&eacute;dia de T&oacute;picos por dia';
$txt['average_online'] = 'M&eacute;dia de Usu&aacute;rios Online por dia';
$txt['users_online'] = 'Usu&aacute;rios Online';
$txt['gender_ratio'] = 'Propor&ccedil;&atilde;o Homens-Mulheres';
$txt['users_online_today'] = 'Online Hoje';
$txt['num_hits'] = 'Total de visualiza&ccedil;&otilde;es';
$txt['average_hits'] = 'M&eacute;dia de visualiza&ccedil;&otilde;es por dia';

$txt['smf_news_1'] = 'coment&aacute;rio';
$txt['smf_news_2'] = 'coment&aacute;rios';
$txt['smf_news_3'] = 'Escrever um coment&aacute;rio';
$txt['smf_news_error2'] = 'Voc&ecirc; n&atilde;o pode especificar um f&oacute;rum onde n&atilde;o s&atilde;o admitidos Visitantes. Por favor verifique a ID do f&oacute;rum antes de continuar.';
$txt['xml_rss_desc'] = 'Informa&ccedil;&atilde;o ao vivo de ' . $context['forum_name'];

?>