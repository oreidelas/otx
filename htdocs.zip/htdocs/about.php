<?PHP
// {made by Renato Ribeiro}

$main_content .= '<h2><center></center></h2><h2><center><a href="index.php?subtopic=team">Equipe</a></center></h2>
<b>Nossa equipe � formada por membros experientes, que est�o sempre a disposi��o pelo Help Channel ou pelo Forum aqui no site;Ninguem da equipe tem char no jogo,para evitar transtornos e outras imparcialidades.</b>

<h2><center></center></h2><h2><center>Sistemas</center></h2>
<b>Utilizamos os sistemas mais avan�ados em termos de OtServ,e sempre que houver atualiza��es estaremos aplicando-as para melhorar o Rpg do servidor.Todos funcionam perfeitamente.</b>

<h2><center></center></h2><h2><center>Mapa</center></h2>
<b>No momento estamos utilizando o Mapa Global Full 8.60 com todas as �reas.Todos os bugs s�o retirados assim que descobertos,caso voce ache algun,tamb�m poder� nos informar pelo Bug tracker.</b>

<h2><center></center></h2><h2><center>Updates e Resets</center></h2>
<b>Updates ocorreram de acordo com o desenvolver do jogo em geral.Jogadores ser�o sempre avisados 15 dias antes,e em casos de Reset no servidor,jogadores que obtiveram pontos antes receberam de volta e mesmo os jogadores que n�o compraram nada receberam alguma coisa em desculpas pelo acontecido.</b>

<h2><center></center></h2><h2><center>Regras</center></h2>
<b>N�s s� cobramos dos jogadores que respeitem a equipe e que obede�am as regras gerais do tibia,que podem ser vistas no Server Rules aqui no site.</b>

<h2><center></center></h2><h2><center>Doa��es</center></h2>
<b>As doa��es n�o s�o pagamentos para Jogar,e sim para aprimorar seus personagens,assim voce nos ajuda a manter o servidor online e ainda fica mais forte com seu character.</b>

<h2><center></center></h2><h2><center>Contas</center></h2>
<b>N�o nos responsabilizamos por perdas ou hack de contas.Apenas disponibizamos o Register Account,assim,caso voce perca sua conta,poder� recupera-la pela Lost Interface.Personagens inativos por muito tempo s�o deletados automaticamente.</b>'
?>