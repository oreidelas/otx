<?PHP
$ban_types = array(1 => 'IP Banishment', 2 => 'Namelock', 3 => 'Account Banishment', 4 => 'Notation', 5 => 'Until Deletion');
$ban_reason = array("Offensive Name", "Invalid Name Format", "Unsuitable Name", "Name Inciting Rule Violation", "Offensive Statement", "Spamming", "Illegal Advertising", "Off-Topic Public Statement", "Non-English Public Statement", "Inciting Rule Violation", "Bug Abuse", "Game Weakness Abuse", "Using Unofficial Software to Play", "Hacking", "Multi-Clienting", "Account Trading or Sharing", "Threatening Gamemaster", "Pretending to Have Influence on Rule Enforcer", "False Report to Gamemaster", "Destructive Behaviour", "Excessive Unjustified Player Killing", "Invalid Payment", "Spoiling Auction");
$players_banned = $SQL->query('SELECT `bans`.`type`, `bans`.`value`, `bans`.`comment`,`bans`.`admin_id`, `bans`.`expires`, `bans`.`added`, `bans`.`reason` FROM `bans`, `players` WHERE `players`.`account_id` = `bans`.`value` AND `bans`.`active` = 1 GROUP BY `bans`.`value` ORDER BY `bans`.`added` DESC')->fetchAll();
if(!$players_banned) {
$main_content .= '
<TABLE BORDER="0" CELLSPACING="1" CELLPADDING="5" WIDTH="100%">
<tr BGCOLOR="'.$config['site']['vdarkborder'].'">
<td CLASS="white"><b>Banishment Status</b></td>
</tr>
<tr BGCOLOR='.$config['site']['darkborder'].'>
<td>There is no any recently banned player.</td>
</tr>
</TABLE>';
} else{
    $number_of_players = 0;
    foreach($players_banned as $player) {
        $nick = $SQL->query("SELECT name, id, level, account_id FROM `players` WHERE account_id =".$player['value']." ORDER BY level DESC LIMIT 1")->fetch();
        $gmnick = $SQL->query("SELECT name, id FROM `players` WHERE id =".$player['admin_id']."")->fetch();

        if($player['admin_id'] >= "1")
            $banby = "<a href=index.php?subtopic=characters&name=".urlencode($gmnick['name'])."><font color ='green'>".$gmnick['name']."</font></a>";
        else
            $banby = "AutomaticSystem";

        $number_of_players++;

        if(is_int($number_of_players / 2))
            $bgcolor = $config['site']['darkborder'];
        else
            $bgcolor = $config['site']['lightborder'];
 
        if ($player['expires'] == "-1") // If the banishment is permanent
            $expires = "Permament";
        else
            $expires = date("d/m/Y, H:i", $player['expires']);


        $players_rows .= '
		<TR BGCOLOR="'.$bgcolor.'" align="center">
			<TD><A HREF="index.php?subtopic=characters&name='.$nick['name'].'">'.$nick['name'].'</A></TD>
			<TD><b>'.$ban_reason[$player['reason']].'</b></TD>
			<TD>'.$expires.'</TD>
		</TR>';
    }
    //list of players
    $main_content .= '
<TABLE BORDER="0" CELLSPACING="1" CELLPADDING=5 WIDTH="100%">
		<TR BGCOLOR="'.$config['site']['vdarkborder'].'">
			<TD CLASS=white><b><center>Penalized Player</center></b></TD>
			<TD class="white"><b><center>Reason</center></b></TD>
			<TD class="white"><b><center>Expires</center></b></TD>
		</TR>'.$players_rows.'
</TABLE>';
}
?>