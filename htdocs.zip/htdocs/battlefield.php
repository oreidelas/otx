<?php header("Content-Type: text/html; charset=ISO-8859-1", true); 
$main_content .= ' 
<center><img src="http://i.imgur.com/vWSUPA3.png"></center>
<br>
		<table cellpadding="4" cellspacing="1" width="98%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>O que � o BattleField Event?</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>� um evento onde 2 times, os Red Barbarians e os Black Assassins, ir�o se enfrentar em uma arena. O BattleFiled � autom�tico e acontecer� 3 vezes por semana <b>Ter�a, Quinta e S�bado �s 19:30 horas</b>, quando for o hor�rio um teleporte surgir� no <b>Templo de Thais</b>.</td>
			</tr>
		</table>
		<br>
		<table cellpadding="4" cellspacing="1" width="98%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Como funciona?</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>Caso voc� morra <span style="color:red;"><b>n�o perder� level, skills e nem itens</b></span> no evento. Os times s�o autom�ticamente balanceados quando os jogadores entram no teleport do evento e s� poder� entrar um numero limitado de jogadores no BattleField. O objetivo do evento � matar os jogadores do time inimigo, quando todos de um time morrer os sobreviventes do time vencedor ganhar�o um pr�mio.</td>
			</tr>
		</table>
		<br>
		<table cellpadding="4" cellspacing="1" width="98%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Quais s�o os premios?</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>O pr�mio � 100k para cada jogador sobrevivente do time vencedor.</td>
			</tr>
		</table>
<br>
<center><iframe width="420" height="315" src="http://www.youtube.com/embed/PQ8Mnw4K72o" frameborder="0" allowfullscreen></iframe></center>
<br> 
';
?>