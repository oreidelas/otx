<?php
Header ("Location: ../");
?>