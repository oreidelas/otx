<?PHP
	$main_content .= '<center>
	<table border="0" cellspacing=1 cellpadding=4 width="100%">
	<tr bgcolor="'.$config['site']['vdarkborder'].'"><br>
	<center><th width="100%"><font class=black><b><center>Calend&aacute;rio de Eventos</center></b></font></th>
	</tr>
	</table>
	<table border="0" cellspacing=1 cellpadding=4 width="100%">
	<tr>
	<center>
	<td bgcolor="'.$config['site']['darkborder'].'" witdh="2%"><center><b>War of Emperium (WoE)</center></b></td>
	<td bgcolor="'.$config['site']['darkborder'].'" witdh="2%"><center><b>BattleField Event</center></b></td>
	</tr>
	<tr>
	<td bgcolor="'.$config['site']['lightborder'].'" witdh="2%"><center><b>Segunda, Quarta e S�bado</center></b></td>
	<td bgcolor="'.$config['site']['lightborder'].'" witdh="2%"><center><b>Ter�a, Quinta e S�bado</center></b></td>
	</tr>
	<tr>
	<td bgcolor="'.$config['site']['lightborder'].'" witdh="2%"><center>�s 20:00 horas.</center></td>
	<td bgcolor="'.$config['site']['lightborder'].'" witdh="2%"><center>�s 19:30 horas.</center></td>
	</tr>
	</table>
	<table border="0" cellspacing=1 cellpadding=4 width="100%">
	<tr bgcolor="'.$config['site']['vdarkborder'].'">
	<td width="100%"></td>
	</tr>
	</table>
	<br>
	';
	
	$main_content.='
	<table border="0" cellspacing=1 cellpadding=4 width="100%">
	<tr bgcolor="'.$config['site']['vdarkborder'].'">
	<th width="100%"><font class=black><center>Observa&ccedil;&otilde;es</center></b></th>
	</tr>
	</table>
	<table border="0" cellspacing=1 cellpadding=4 width="100%">
	<tr bgcolor="'.$config['site']['darkborder'].'">
	<td width="100%"><ul><li>Assim que der o hor�rio dos eventos ser� aberto um teleport no <b>Event Room</b>, cujo o acesso fica localizado nos templos de Venore, Thais e Carlin. O teleport ficar� aberto por <b>10 minutos</b> e logo ap�s esses 10 minutos os teleports ir�o se fechar e dar� o inicio ao evento, em excess�o ao WoE que o teleport sumir� em 1 hora.</li></ul></td>
	</tr>
	<tr bgcolor="'.$config['site']['darkborder'].'">
	<td width="100%"><ul><li>Todos os eventos s�o <b>100% autom�ticos</b> sendo assim n�o dependendo dos GMs para dar inicio aos mesmos, basta seguir o horario citado acima e se divertir nos eventos. Caso aconte�a algum bug ou algo do g�nero reporte em nossa <a href="/index.php?subtopic=help">P�gina de Atendimento</a> para ser corrigido o mais rapido poss�vel!</li></ul></td>
	</tr>
	</table>
	';

?>
