<?PHP
$name = stripslashes(ucwords(strtolower(trim($_REQUEST['name']))));
if(empty($name)) {
$main_content .= '
<FORM ACTION="?subtopic=characters" METHOD=post>
<TABLE WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=4><TR>
<TD BGCOLOR="'.$config['site']['vdarkborder'].'" CLASS=white>
<B>Search Character</B>
</TD></TR><TR>
<TD BGCOLOR="'.$config['site']['darkborder'].'">
<TABLE BORDER=0 CELLPADDING=1>
<TR><TD>Name:</TD>
<TD><INPUT NAME="name" VALUE=""SIZE=29 MAXLENGTH=29></TD>
<TD><INPUT TYPE=image NAME="Submit" SRC="'.$layout_name.'/images/buttons/sbutton_submit.gif" BORDER=0 WIDTH=120 HEIGHT=18>
</TD></TR></TABLE></TD></TR></TABLE></FORM>';
}
else
{
if(check_name($name)) {
$player = $ots->createObject('Player');
$player->find($name);
if($player->isLoaded()) {
$account = $player->getAccount();
$main_content .= '<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0 WIDTH=100%><TR><TD><IMG SRC="'.$layout_name.'/images/general/blank.gif" WIDTH=0 HEIGHT=01 BORDER=0></TD><TD><TABLE BORDER=0 CELLSPACING=1 CELLPADDING=4 WIDTH=100%><TR BGCOLOR='.$config['site']['vdarkborder'].'><TD COLSPAN=2 CLASS=white><B>Character Information</B></TD></TR>';
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD WIDTH=20%>Name:</TD><TD>';
$main_content .= $player->getName();
if($player->isDeleted())
$main_content .= '&#160;<font color="red"><b>[DELETED]</b></font>';
if($player->isNameLocked())
$main_content .= '&#160;<font color="red">[NAMELOCK]</font>';
$main_content .= '</TD></TR>';

$group = $player->getGroup();
if ($group == 2){$group_name = 'Tutor';}
if ($group == 3){$group_name = 'Senior Tutor';}
if ($group == 4){$group_name = 'Gamemaster';}
if ($group == 5){$group_name = 'Community Manager';}
if ($group == 6){$group_name = 'Administrator';}

if($group != 1){
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Position:</TD><TD>'.$group_name.'</TD></TR>';
}
// END Position Showing
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Sex:</TD><TD>';
$main_content .= ($player->getSex() == 0) ? 'female' : 'male';
$main_content .= '</TD></TR>';
if($player->getMarriage()){
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Marital status:</TD><TD>';
$marriage = new OTS_Player();
$marriage->load($player->getMarriage());
if($marriage->isLoaded())
$main_content .= 'married to <a href="?subtopic=characters&name='.urlencode($marriage->getName()).'"><b>'.$marriage->getName().'</b></a></TD></TR>';
else
$main_content .= 'single</TD></TR>';
}

if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Profession:</TD><TD>'.$vocation_name[$player->getWorld()][$player->getPromotion()][$player->getVocation()].'</TD></TR>';

if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Level:</TD><TD>'.$player->getLevel().'</TD></TR>';

if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>World:</TD><TD>'.$config['site']['worlds'][$player->getWorld()].'</TD></TR>';
if(!empty($towns_list[$player->getWorld()][$player->getTownId()])){
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Residence:</TD><TD>'.$towns_list[$player->getWorld()][$player->getTownId()].'</TD></TR>';
}

$house = $SQL->query('SELECT `houses`.`name`, `houses`.`town`, `houses`.`paid` FROM `houses` WHERE `houses`.`world_id` = '.$player->getWorld().' AND `houses`.`owner` = '.$player->getId().';')->fetchAll();
if(count($house) != 0)
{
	if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
	$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>House:</TD><TD colspan="2">'.$house[0]['name'].' ('.$towns_list[$player->getWorld()][$house[0]['town']].')';
	if ($house[0]['paid']){$main_content .='&nbsp;is paid until '.date("M j Y", $house[0]['paid']);}
	$main_content .='.</TD></TR>';
}
$rank_of_player = $player->getRank();
if(!empty($rank_of_player)){
{
$guild_id = $rank_of_player->getGuild()->getId();
$guild_name = $rank_of_player->getGuild()->getName();
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Guild Membership:</TD><TD>'.$rank_of_player->getName().' of the <a href="?subtopic=guilds&action=show&guild='.$guild_id.'">'.$guild_name.'</a></TD></TR>';
}
}

if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
if($player->getLastLogin())
$main_content .= '<TR BGCOLOR='.$bgcolor.'><TD WIDTH="20%">Last login:</TD><TD>'.date("M j Y, H:i:s T", $player->getLastLogin()).'</TD></TR>';
else
$main_content .= '<TR BGCOLOR='.$bgcolor.'><TD WIDTH="20%">Last login:</TD><TD>Never logged in.</TD></TR>';
// VIP STATUS 
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Account Status:</TD><TD>';  
$main_content .= ($account->getPlayerVip_Time()) ? '<font color="green"><b>VIP Account</b></font>' : '<font color="red"><b>Not VIP Account</b></font>';
//Comment System
$comment = $player->getComment();
$newlines   = array("\r\n", "\n", "\r");
$comment_with_lines = str_replace($newlines, '<br />', $comment, $count);
if($count < 50)
$comment = $comment_with_lines;
if(!empty($comment))
{
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;  
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD VALIGN="top">Comment:</TD><TD>'.$comment.'</TD></TR>';
}
$main_content .='
</td>
</tr>
</table>
</div>
<div class="BoxFrameHorizontal" style="background-image:url('.$layout_name.'/images/content/box-frame-horizontal.gif);" />
</div>
<div class="BoxFrameEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" />
</div>
<div class="BoxFrameEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" />
</div>
</div>
</div>
</td>
</tr>
</table>
';
$deads = 0;
$player_deaths = $SQL->query('SELECT `id`, `date`, `level` FROM `player_deaths` WHERE `player_id` = '.$player->getId().' ORDER BY `date` DESC LIMIT 0,10;');
foreach($player_deaths as $death)
{
if(is_int($number_of_rows / 2))
$bgcolor = $config['site']['darkborder']; else $bgcolor = $config['site']['lightborder'];

$number_of_rows++; $deads++;
$dead_add_content .= "<tr bgcolor=\"".$bgcolor."\">
<td width=\"30%\" align=\"center\">".date("M j Y, H:i:s T", $death['date'])."</td>
<td>";
$killers = $SQL->query("SELECT environment_killers.name AS monster_name, players.name AS player_name, players.deleted AS player_exists FROM killers LEFT JOIN environment_killers ON killers.id = environment_killers.kill_id
LEFT JOIN player_killers ON killers.id = player_killers.kill_id LEFT JOIN players ON players.id = player_killers.player_id
WHERE killers.death_id = ".$SQL->quote($death['id'])." ORDER BY killers.final_hit DESC, killers.id ASC")->fetchAll();

$i = 0;
$count = count($killers);
foreach($killers as $killer)
{
$i++;
if(in_array($i, array(1, $count)))
$killer['monster_name'] = str_replace(array("an ", "a "), array("", ""), $killer['monster_name']);

if($killer['player_name'] != "")
{
if($i == 1)
$dead_add_content .= "Killed at level <b>".$death['level']."</b> by ";
else if($i == $count)
$dead_add_content .= " and by ";
else
$dead_add_content .= ", ";

if($killer['monster_name'] != "")
$dead_add_content .= $killer['monster_name']." summoned by ";

if($killer['player_exists'] == 0)
$dead_add_content .= "<a href=\"index.php?subtopic=characters&name=".urlencode($killer['player_name'])."\">";

$dead_add_content .= $killer['player_name'];
if($killer['player_exists'] == 0)
$dead_add_content .= "</a>";
}
else
{
if($i == 1)
$dead_add_content .= "Died at level <b>".$death['level']."</b> by ";
else if($i == $count)
$dead_add_content .= " and by ";
else
$dead_add_content .= ", ";

$dead_add_content .= $killer['monster_name'];
}

if($i == $count)
$dead_add_content .= "";
}

$dead_add_content .= ".</td></tr>";
}

if($deads > 0)
$main_content .= '<BR/><TABLE BORDER=0 CELLSPACING=1 CELLPADDING=4 WIDTH=100%><TR BGCOLOR='.$config['site']['vdarkborder'].'><TD COLSPAN=2 CLASS=white><B>Character Deaths</B></TD></TR>' . $dead_add_content . '</TABLE>';

//end
if(!$player->getHideChar()) {
$main_content .= '<BR /><TABLE BORDER=0><TR><TD></TD></TR></TABLE><TABLE BORDER=0 CELLSPACING=1 CELLPADDING=4 WIDTH=100%><TR BGCOLOR='.$config['site']['vdarkborder'].'><TD COLSPAN=2 CLASS=white><B>Account Information</B></TD></TR>';
if($account->getRLName())
{
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR='.$bgcolor.'><TD WIDTH=20%>Real name:</TD><TD>'.$account->getRLName().'</TD></TR>';
}
if($account->getLocation())
{
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR='.$bgcolor.'><TD WIDTH=20%>Location:</TD><TD>'.$account->getLocation().'</TD></TR>';
}
$group = $player->getGroup();
if ($group == 2){$group_name = 'Tutor';}
if ($group == 3){$group_name = 'Senior Tutor';}
if ($group == 4){$group_name = 'Gamemaster';}
if ($group == 5){$group_name = 'Community Manager';}
if ($group == 6){$group_name = 'Administrator';}

if($group != 1){
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Position:</TD><TD>'.$group_name.'</TD></TR>';
}
if($player->getCreated())
{
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Created:</TD><TD>'.date("M j Y, H:i:s T", $player->getCreated()).'</TD></TR>';
}
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
if($account->getLastLogin())
$main_content .= '<TR BGCOLOR='.$bgcolor.'><TD WIDTH="20%">Last login:</TD><TD>'.date("M j Y, H:i:s T", $account->getLastLogin()).'</TD></TR>';

if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$ban_types = array(1 => 'IP Banishment', 2 => 'Namelock', 3 => 'Account Banishment', 4 => 'Notation', 5 => 'Until Deletion');
$ban_reason = array("Offensive Name", "Invalid Name Format", "Unsuitable Name", "Name Inciting Rule Violation", "Offensive Statement", "Spamming", "Illegal Advertising", "Off-Topic Public Statement", "Non-English Public Statement", "Inciting Rule Violation", "Bug Abuse", "Game Weakness Abuse", "Using Unofficial Software to Play", "Hacking", "Multi-Clienting", "Account Trading or Sharing", "Threatening Gamemaster", "Pretending to Have Influence on Rule Enforcer", "False Report to Gamemaster", "Destructive Behaviour", "Excessive Unjustified Player Killing", "Invalid Payment", "Spoiling Auction");
$players_banned = $SQL->query('SELECT * FROM `bans` WHERE `value` = '.$account->getCustomField('id').'')->fetchAll();
foreach($players_banned as $player) {
if($account->isBanned())
if($account->getBanTime() > 0)
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Banished:</td><td><font color="red"><b>Account Banishment</b>&#160;<br /><b>Expires:</b>&nbsp;'.date("j F Y, G:i A", $account->getBanTime()).' - '.$ban_reason[$player['reason']].'</font></td></tr>';
else
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD>Banished:</td><td><font color="red"><b>Banished Forever</font></td></tr>';
}
$main_content .= '</TD></TR></TABLE>';
$main_content .= '<br /><TABLE BORDER=0><TR><TD></TD></TR></TABLE><TABLE BORDER=0 CELLSPACING=1 CELLPADDING=4 WIDTH=100%><TR BGCOLOR='.$config['site']['vdarkborder'].'><TD COLSPAN=5 CLASS=white><B>Characters</B></TD></TR>
<TR BGCOLOR='.$config['site']['darkborder'].'><TD><B>Name</B></TD><TD><B>World</B></TD><TD><B>Level</B></TD><TD><b>Status</b></TD><TD><B>&#160;</B></TD></TR>';
$account_players = $account->getPlayersList();
$account_players->orderBy('name');
$player_number = 0;
foreach($account_players as $player_list)
{
if(!$player_list->getHideChar())
{
$player_number++;
if(is_int($player_number / 2))
$bgcolor = $config['site']['darkborder'];
else
$bgcolor = $config['site']['lightborder'];
if(!$player_list->isOnline())
$player_list_status = '';
else
$player_list_status = '<b style="color:green;">online</b>';
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><TD WIDTH=52%><NOBR>'.$player_number.'.&#160;'.$player_list->getName();
$main_content .= '</NOBR></TD><TD WIDTH=15%>'.$config['site']['worlds'][$player_list->getWorld()].'</TD><TD WIDTH=25%>'.$player_list->getLevel().' '.$vocation_name[$player_list->getWorld()][$player_list->getPromotion()][$player_list->getVocation()].'</TD><TD WIDTH="8%">'.$player_list_status.'</TD><TD><TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0><FORM ACTION="?subtopic=characters" METHOD=post><TR><TD><INPUT TYPE=hidden NAME=name VALUE="'.$player_list->getName().'"><INPUT TYPE=image NAME="View '.$player_list->getName().'" ALT="View '.$player_list->getName().'" SRC="'.$layout_name.'/images/buttons/sbutton_view.gif" BORDER=0 WIDTH=120 HEIGHT=18></TD></TR></FORM></TABLE></TD></TR>';
}
}
$main_content .= '</TABLE></TD><TD><IMG SRC="'.$layout_name.'/images/general/blank.gif" WIDTH=10 HEIGHT=1 BORDER=0></TD></TR></TABLE>';
}
$main_content .= '<br /><br /><FORM ACTION="?subtopic=characters" METHOD=post><TABLE WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=4><TR><TD BGCOLOR="'.$config['site']['vdarkborder'].'" CLASS=white><B>Search Character</B></TD></TR><TR><TD BGCOLOR="'.$config['site']['darkborder'].'"><TABLE BORDER=0 CELLPADDING=1><TR><TD>Name:</TD><TD><INPUT NAME="name" VALUE=""SIZE=29 MAXLENGTH=29></TD><TD><INPUT TYPE=image NAME="Submit" SRC="'.$layout_name.'/images/buttons/sbutton_submit.gif" BORDER=0 WIDTH=120 HEIGHT=18></TD></TR></TABLE></TD></TR></TABLE></FORM>';
$main_content .= '</TABLE>';
}
else
$search_errors[] = 'Character <b>'.$name.'</b> does not exist.';
}
else
$search_errors[] = 'This name contains invalid letters. Please use only A-Z, a-z and space.';
if(!empty($search_errors))
{
$main_content .= '
<div class="SmallBox" >
<div class="MessageContainer" >
<div class="BoxFrameHorizontal" style="background-image:url('.$layout_name.'/images/content/box-frame-horizontal.gif);" /></div>
<div class="BoxFrameEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></div>
<div class="BoxFrameEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></div>
<div class="ErrorMessage" >
<div class="BoxFrameVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></div>
<div class="BoxFrameVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></div>
<div class="AttentionSign" style="background-image:url('.$layout_name.'/images/content/attentionsign.gif);" /></div>
<b>The Following Errors Have Occurred:</b><br />';
foreach($search_errors as $search_error)
$main_content .= '<li>'.$search_error;
$main_content .= '</div>
<div class="BoxFrameHorizontal" style="background-image:url('.$layout_name.'/images/content/box-frame-horizontal.gif);" /></div>
<div class="BoxFrameEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></div>
<div class="BoxFrameEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></div>
</div>
</div>
<br />';
$main_content .= '<BR /><FORM ACTION="?subtopic=characters" METHOD=post><TABLE WIDTH=100% BORDER=0 CELLSPACING=1 CELLPADDING=4><TR><TD BGCOLOR="'.$config['site']['vdarkborder'].'" CLASS=white><B>Search Character</B></TD></TR><TR><TD BGCOLOR="'.$config['site']['darkborder'].'"><TABLE BORDER=0 CELLPADDING=1><TR><TD>Name:</TD><TD><INPUT NAME="name" VALUE=""SIZE=29 MAXLENGTH=29></TD><TD><INPUT TYPE=image NAME="Submit" SRC="'.$layout_name.'/images/buttons/sbutton_submit.gif" BORDER=0 WIDTH=120 HEIGHT=18></TD></TR></TABLE></TD></TR></TABLE></FORM>';
}
}
?>