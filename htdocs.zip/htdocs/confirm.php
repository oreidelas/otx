<?PHP
$main_content .= '<center>
<table cellpadding="4" cellspacing="1" width="99%">
	<tr bgcolor="'.$config['site']['vdarkborder'].'">
		<td colspan="2"><font class="white"><b>Informa��es sobre a doa��o:</b></font></td>
	</tr>
	<tr bgcolor="'.$config['site']['darkborder'].'">
		<td>
<center><b><span style="color:red;">Se voc� for realizar uma doa��o, considere-se ciente de todas as informa��es do texto abaixo!</span></b></center>		
		</td>
	</tr>
	<tr bgcolor="'.$config['site']['lightborder'].'">
	<td>Informamos aos jogadores que o servidor n�o tem nenhum interesse financeiro. Toda a renda obtida � diretamente aplicada para a manuten��o do mesmo - isto significa que ao fazer uma doa��o, voc� est� garantindo sua qualidade e evolu��o.
<br><br>
Os points que s�o repassados aos jogadores que efetuam as doa��es n�o representam nada mais al�m de nossa gratifica��o, isto �, voc� n�o est� comprando points e sim recebendo uma gratifica��o simb�lica (em formas de points) que te beneficie dentro do jogo; voc� poder� usar os seus points da maneira que desejar.
<br><br>
O esp�rito deste sistema � simples: com o intuito de nos aproximarmos dos jogadores e fazer com que voc�s se sintam em casa, entendemos a sua doa��o como uma via de m�o dupla no quesito credibilidade. Ao acreditar que vale a pena investir na manuten��o do servidor, n�s investimos em voc�s creditando-os com points, que como j� dito anteriormente, podem ser utilizados da maneira que mais os couber.
<br><br>
Lembrando que apesar de nossa equipe estar sempre �pta a resolver os problemas n�o podemos garantir 100% de estabilidade onde estamos sujeitos � quest�es externas como ataques, falhas de redes internacionais e eventos externos que fogem o nosso controle, <b>por esse motivo N�O podemos fazer a devolu��o das doa��es recebidas por nenhum motivo.</b>
<br><br>
Cuidado com as cl�ssicas traps de Red Skull. A perda do item n�o implicar� na devolu��o do mesmo.
<br><br>
Confira as todas as <a href="index.php?subtopic=vantagens" targer="_blank">Vantagens VIP</a> e o <a href="index.php?subtopic=shopsystem">'.$config['server']['serverName'].' Shopping</a> e saiba como gastar os seus points da maneira mais proveitosa em nosso servidor.</td>
	</tr>
</table><br>

<a href="?subtopic=latestnews"><< Eu n�o aceito os termos de doa��o</a> <b>|</b> <a href="?subtopic=donate">Eu li e aceito os termos de doa��o >></a>';