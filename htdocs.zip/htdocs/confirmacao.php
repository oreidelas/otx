<?php header("Content-Type: text/html; charset=ISO-8859-1",true);
/*/by Victor Fasano Raful /*/
#Credits may cause the deleted file not working
if(isset($_POST["acao"]) && $_POST["acao"] == "enviar")
{require ("gravar.php");}
if(isset($msg))
echo "<div id=\"msg\">$msg</div>";
if($logged)
{
$main_content .= '
Nossa ferramenta de confirma��o de pagamento somente � v�lida para quem efetuou o pagamento verdadeiro, caso <b>n�o</b> tenha efetuado nenhum tipo de transa��o
e esta usando nossas ferramentas para uso indevido como mandar <b>"recadinhos"</b> o jogador poder� ser <b>punido</b> em 5 dias corridos.<br /><br />
<div class="TableContainer">
<div class="CaptionContainer">  
<div class="CaptionInnerContainer">     
<span class="CaptionEdgeLeftTop" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);">
</span>  
<span class="CaptionEdgeRightTop" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);">
</span>   
<span class="CaptionBorderTop" style="background-image: url(layouts/tibiacom/images/content/table-headline-border.gif);">
</span>  
<span class="CaptionVerticalLeft" style="background-image: url(layouts/tibiacom/images/content/box-frame-vertical.gif);">
</span> 
<div class="Text">Confirma��o de Pagamento</div>        
<span class="CaptionVerticalRight" style="background-image: url(layouts/tibiacom/images/content/box-frame-vertical.gif);">
</span> 
<span class="CaptionBorderBottom" style="background-image: url(layouts/tibiacom/images/content/table-headline-border.gif);">
</span>   
<span class="CaptionEdgeLeftBottom" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);">
</span> 
<span class="CaptionEdgeRightBottom" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>  
</div>  
</div>  
<table class="Table1" cellpadding="0" cellspacing="0">
<tbody>
<tr>  
<td>      
<div class="InnerTableContainer">  
<table style="width: 100%;">
<tbody>
<td valign="middle" width="25px;">
<form action="" method="post" enctype="multipart/form-data">
<select name="nome">';
$players_from_logged_acc = $account_logged->getPlayersList();
if(count($players_from_logged_acc) > 0) {
$players_from_logged_acc->orderBy('name');
foreach($players_from_logged_acc as $player) {
$main_content .= '<option>'.$player->getName().'</option>';
}
} else {
$main_content .= 'You don\'t have any character on your account.';
}
$main_content .='
</select><small> (Selecione um personagem) </small>
<br /><br />
<span><b>E-mail</b></span><br />
'.$account_logged->getCustomField("email").'
<input type="hidden" value="'.$account_logged->getCustomField("email").'" name="email" readonly />
<br /><br />
<span><b>Account</b></span><br />
'.$account_logged->getCustomField("name").'
<input type="hidden" value="'.$account_logged->getCustomField("name").'" name="titulo" readonly />
<br /><br />
<span><b>Hora da Doa��o</b></span>  <br />
<input type="text" name="hr" />
<br /><br />
<span><b>Valor Doado</b></span>  <br />
<input type="text" name="vl" />
<br /><br />
<span><b>Detalhes Do Comprovante</b></span>  <br />
<textarea name="mensagem" cols="30" rows="5"></textarea>
<br /><br />
<input type="hidden" name="acao" value="enviar" />                
<input type="submit" value=" Enviar Confirma��o " class="btn"/>
</form>
<small>Script by <b>VictorWebMaster</b>.</small>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</div>';
}
else
{
$main_content .='
<TABLE BORDER="0" CELLSPACING="1" CELLPADDING="5" WIDTH="100%">
<tr BGCOLOR="'.$config['site']['vdarkborder'].'">
<td CLASS="white"><b>Error</b></td>
</tr>
<tr BGCOLOR='.$config['site']['darkborder'].'>
<td><font size="5">Login first.</font><br /><br /><a href="index.php?subtopic=accountmanagement">Login</a> or <a href="index.php?subtopic=createaccount">Register</a>.</td>
</tr>
</TABLE>
';}
?>