﻿<html>
<head>
        <script language="javascript" type="text/javascript">
                function checa_formulario(email){
                if (email.nome.value == ""){
                        alert("Por Favor não deixe o seu nome em branco!!!");
                        email.nome.focus();
                return (false);
        }
                if (email.email_from.value == ""){
                        alert("Por Favor não deixe o seu email em branco!!!");
                        email.email_from.focus();
                return (false);
        }
                if (email.email.value == ""){
                        alert("não deixe o email destinatario em branco!!!");
                        email.email.focus();
                return (false);
        }
                if (email.assunto.value == ""){
                        alert("não deixe o assunto em branco!!!");
                        email.assunto.focus();
                return (false);
                }      
        }
        </script>
<title>Enviando texto</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <style type="text/css">
</style>
</head>
<body onLoad="document.email.nome.focus();">
<form onSubmit="return checa_formulario(this)" action="enviar.php" method="post" enctype="multipart/form-data" name="email">
<h1 align="center" class="style1">Confirmar doa&ccedil;&atilde;o!</h1>
<table width="32%" border="0" align="center">
        <tr>
                <td valign="top">
                        <label for="character">Character Name:</label>
                </td>
                <td valign="top">
                        <input  type="text" name="character" maxlength="50" size="30">
                </td>
        </tr>
        <tr>
                <td valign="top">
                        <label for="valordoado">Valor Doado:</label>
                </td>
                <td valign="top">
                        <input  type="text" name="valordoado" maxlength="50" size="30">
                </td>
        </tr>
        <tr>  
                <td valign="top">
                        <label for="forma">Forma de Doa&ccedil;&atilde;o:</label>
                </td>
                <td valign="top">
               <select name="forma">  
                                        <option>Selecione...</option>  
                   <option>Pagseguro</option>  
                   <option>Paypal</option>  
                   <option>Moip</option>  
                   <option>Banco do Brasil</option>  
                   <option>Caixa Enconomica</option>  
                   <option>Bradesco</option>  
                   <option>Itau</option>  
               </select>  
       </td>
        </tr>
   <tr>
                <td valign="top">
           <label for="anexo">Anexo:</label>
       </td>
       <td valign="top">
           <input type="file" name="arquivo" id="arquivo" />
       </td>
    </tr>      
        <tr>
                <td valign="top">
                        <label for="email">Email:</label>
                </td>
                <td valign="top">
                        <input  type="text" name="email" maxlength="80" size="30">
                </td>
        </tr>
        <tr>
                <td valign="top">
                        <label for="data">Data da Doa&ccedil;&atilde;o:</label>
                </td>
                <td valign="top">
                        <input  type="text" name="data" maxlength="30" size="30">
                </td>
        </tr>
        <tr>
                <td valign="top">
                        <label for="observacoes">Observa&ccedil;&otilde;es:</label>
                </td>
                <td valign="top">
                        <textarea  name="observacoes" maxlength="1000" cols="25" rows="6"></textarea>
                </td>
        </tr>
        <tr>
                <td colspan="2" style="text-align:center">
                        <input type="submit" value="Submit">
                </td>
        </tr>
</table>
</form>
</body>
</html>