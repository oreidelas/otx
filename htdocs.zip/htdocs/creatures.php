<?PHP
$ot_rate = $config['server']['rateExperience'];
if(empty($_REQUEST['creature'])) {
//SHOW MONSTERS LIST
$allowed_order_by = array('name', 'exp', 'health', 'summonable', 'convinceable', 'race');
$order = $_REQUEST['order'];
//generate sql query
if($_REQUEST['desc'] == 1) {
$desc = " DESC";
}
if($order == 'name') {
$whereandorder = ' ORDER BY name'.$desc;
}
elseif($order == 'exp') {
$whereandorder = ' ORDER BY exp'.$desc.', name';
}
elseif($order == 'health') {
$whereandorder = ' ORDER BY health'.$desc.', name';
}
elseif($order == 'summonable') {
$whereandorder = ' AND summonable = 1 ORDER BY mana'.$desc;
}
elseif($order == 'convinceable') {
$whereandorder = ' AND convinceable = 1 ORDER BY mana'.$desc;
}
elseif($order == 'race') {
$whereandorder = ' ORDER BY race'.$desc.', name';
}
else
{
$whereandorder = ' ORDER BY name';
}
//send query to database
$monsters = $SQL->query('SELECT * FROM '.$SQL->tableName('z_monsters').' WHERE hide_creature != 1'.$whereandorder);
$main_content .= '
<TABLE BORDER="0" CELLSPACING="1" CELLPADDING="5" WIDTH="100%">
<tr BGCOLOR="'.$config['site']['vdarkborder'].'">
<td CLASS="white"><b>Creature Search</b></td>
</tr>
<tr BGCOLOR='.$config['site']['darkborder'].'>
<td>
<b>Creature Name:</b><br />
<form action="index.php" method="get">
<input type="hidden" name="subtopic" value="creatures">
<input type="text" name="creature" />
<input type="submit" value="Search" />
</form>
</td>
</tr>
</TABLE>
<br />
<table border="0" cellspacing="1" cellpadding="3" width="100%">
<TR BGCOLOR='.$config['site']['vdarkborder'].'>
<td style="color: #FFF;" width="10%"></td>
<td style="color: #FFF;"><b>Name</b></td>
<td style="color: #FFF;" align="center"><b>Health</b></td>
<td style="color: #FFF;" align="center"><b>Experience</b></td>
<td style="color: #FFF;" align="center"><b>Mana<br />Summon</b></td>
<td style="color: #FFF;" align="center"><b>Mana<br />Convince ' . $victorList[(int)$creature['name']] . '</b></td>
';
foreach($monsters as $monster) {
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['lightborder']; } else { $bgcolor = $config['site']['darkborder']; } $number_of_rows++;
$main_content .= '<TR BGCOLOR="'.$bgcolor.'"><td width="5%" align="center">';
if(file_exists('images/monsters/'.$monster['gfx_name'])) {
$main_content .= '<img src="images/monsters/'.$monster['gfx_name'].'" height="32" width="32" border="0" />';
} else {
$main_content .= '<img src="images/monsters/nophoto.png" height="32" width="32">';
}
$main_content .='</td><TD><a href="?subtopic=creatures&creature='.urlencode($monster['name']).'">'.$monster['name'].'</a></TD><TD>'.$monster['health'].'</TD><TD>';
$main_content .= $monster['exp'] * $ot_rate;
$main_content .='</TD>';
if($monster['summonable']) {
$main_content .= '<TD>'.$monster['mana'].'</TD>';
}
else
{
$main_content .= '<TD>---</TD>';
}
if($monster['convinceable']) {
$main_content .= '<TD>'.$monster['mana'].'</TD>';
}
else
{
$main_content .= '<TD>---</TD>';
}
}

$main_content .= '</TABLE>';
}
else
//SHOW INFORMATION ABOUT MONSTER
{
$monster_name = stripslashes(trim(ucwords($_REQUEST['creature'])));
$monster = $SQL->query('SELECT * FROM '.$SQL->tableName('z_monsters').' WHERE '.$SQL->fieldName('hide_creature').' != 1 AND '.$SQL->fieldName('name').' = '.$SQL->quote($monster_name).';')->fetch();
if(isset($monster['name'])) {
$main_content .='
<table border="0" cellspacing="1" cellpadding="5" WIDTH="100%">
<tr bgcolor="'.$config['site']['vdarkborder'].'">
<td width="50%" colspan="2">&nbsp;<b style="color: #FFF;">Creature</b></td>
</tr>';
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<tr bgcolor="'.$bgcolor.'"><td width="30%" align="right">';
if(file_exists('images/monsters/'.$monster['gfx_name'])) {
$main_content .= '<img src="images/monsters/'.$monster['gfx_name'].'">';
} else {
$main_content .= '<img src="images/monsters/nophoto.png" height="32" width="32">';
}
$main_content .='</td><td><font style="font-size:16px; font-weight:bold;">'.$monster['name'].'</font><br />'.$monster['health'].' Hit points<br />';
$main_content .= $monster['exp'] * $ot_rate;
$main_content .='&nbsp;Experience points per kill</td></tr>';
$main_content .='</td></tr>';

if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<tr bgcolor="'.$bgcolor.'"><td width="100"><b>Summon / Convince </b></td><td>';
if($monster['convinceable'] == 1) {
$main_content .= $monster['mana'].'&#160;/&#160;'.$monster['mana'];
}
else
$main_content .='-&#160;/&#160;-';
if(!empty($monster['immunities'])) {
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<tr bgcolor="'.$bgcolor.'"><td width="100"><b>Immunities: </b></td><td width="100%">'.$monster['immunities'].'</td></tr>';
}
if(!empty($monster['voices'])) {
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<tr bgcolor="'.$bgcolor.'"><td width="100"><b>Voices: </b></td><td width="100%"><font style="color:#d14703; font-weight:bold;">'.$monster['voices'].'.</font></td></tr>';
}
/* Loot */
if(!empty($monster['loot'])) {
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .= '<tr bgcolor="'.$bgcolor.'"><td width="100"><b>Loot: </b></td><td width="100%">'.$monster['loot'].'</td></tr>';
}
else
{
if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .='<tr bgcolor="'.$bgcolor.'"><td width="100"><b>Loot: </b></td><td width="100%"><i>No have loot drop</i></td></tr>';}
$main_content .='</table>';
$main_content .='<br />&#160;<form action="index.php?subtopic=creatures" method="post"><input type="image" src="'.$layout_name.'/images/buttons/sbutton_back.gif" /></form>';
}
else
{
$main_content .= '<div class="error">Monster with name <b>'.$monster_name.'</b> doesn\'t exist.<br/></div></br><center><form action="?subtopic=creatures" METHOD=post><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)" ><div onMouseOver="MouseOverBigButton(this);" onMouseOut="MouseOutBigButton(this);" ><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);" ></div><input class="ButtonText" type="image" name="Back" alt="Back" src="'.$layout_name.'/images/buttons/_sbutton_back.gif" ></div></div></form></center>';
}
}
?>