<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.style7 {font-size: 16px; }
.style8 {
	font-size: 14;
	font-weight: bold;
}
.style9 {font-size: 16px; font-weight: bold; }
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: bold; }
-->
</style>
<form name="form1" method="post" action="donate/gravar.php">
</SCRIPT>

<FIELDSET id=fieldcontato><LEGEND><STRONG>Formul&#225;rio</STRONG> </LEGEND>
<FORM id=form1 method=post name=form1>
<TABLE border=0 cellSpacing=3 cellPadding=3 width=500>
<TBODY>
<TR>
<TD width="29%"><STRONG>Assunto</STRONG></TD>
<TD width="71%"><LABEL><SELECT id=assunto name=assunto> <OPTION selected>Doa&#231;&#227;o por Pagseguro (Boleto, Cart&#227;o de Credito e etc)</OPTION></SELECT> </LABEL></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR>
<TD><STRONG>Nome</STRONG></TD>
<TD><SPAN id=nome><LABEL><INPUT id=nome maxLength=40 size=25 name=nome> </LABEL><SPAN class=textfieldRequiredMsg><FONT size=1>Digite seu nome completo.</FONT></SPAN></SPAN></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR>
<TD><STRONG>Email da sua Account</STRONG></TD>
<TD><SPAN id=email><LABEL><INPUT id=email size=25 name=email> </LABEL><SPAN class=textfieldRequiredMsg><FONT size=1>Digite o email da sua conta.</FONT></SPAN><SPAN class=textfieldInvalidFormatMsg></SPAN></SPAN></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR>
<TD><STRONG>Sua Account</STRONG></TD>
<TD><SPAN id=conta><LABEL><INPUT id=account maxLength=25 size=25 name=account> </LABEL><SPAN class=textfieldRequiredMsg><FONT size=1>Digite sua conta.</FONT></SPAN><SPAN class=textfieldInvalidFormatMsg></SPAN></SPAN></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR>
<TD><STRONG>Personagem</STRONG></TD>
<TD><SPAN id=personagem><LABEL><INPUT id=personagem size=25 name=personagem> </LABEL><SPAN class=textfieldRequiredMsg><FONT size=1>Digite seu personagem.</FONT></SPAN></SPAN></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR></TR>
<TR>
<TD><STRONG>Valor da doa&#231;&#227;o</STRONG></TD>
<TD><SPAN id=valor><LABEL><INPUT id=valor maxLength=3 size=25 name=valor> <SPAN class=textfieldRequiredMsg><FONT size=1>Exemplo: 40</FONT></SPAN></SPAN></LABEL></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></LABEL></TR>
<TR>
<TD><STRONG>Data do dep&#243;sito</STRONG></TD>
<TD><SPAN id=data><LABEL><INPUT id=data maxLength=10 size=25 name=data> </LABEL><SPAN class=textfieldRequiredMsg><FONT size=1>Exemplo: 15/07/2009</FONT></SPAN><SPAN class=textfieldInvalidFormatMsg></SPAN></SPAN></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR>
<TD><STRONG>Hora do dep&#243;sito</STRONG></TD>
<TD><SPAN id=hora><LABEL><INPUT id=hora maxLength=5 size=25 name=hora> </LABEL><SPAN class=textfieldRequiredMsg><FONT size=1>Exemplo: 14:20</FONT></SPAN><SPAN class=textfieldInvalidFormatMsg></SPAN></SPAN></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR>
<TD><STRONG>Imagem do comprovante</STRONG><BR><FONT color=red>(Apenas por Deposito)</FONT></TD>
<TD><LABEL><INPUT id=imagem size=25 name=imagem> <BR>
<H5>Hospede a foto do seu comprovante no <A href="http://www.imageshack.us" target=_blank>ImageShack</A></H5></LABEL></TD></TR>
<TR></TD>
<TD height=20 vAlign=center colSpan=2>
<HR color=#c0c0c0 noShade>
</TD></TR>
<TR>
<TD>&nbsp;</TD></TR></TBODY></TABLE>
<P><INPUT value=Enviar type=submit name=enviar> <INPUT value=Limpar type=reset name=limpar></P></FORM></FIELDSET><BR>
<H3>D&#250;vidas.</H3><FONT color=red>Aten&#231;&#227;o se voc&#234; fez uma doa&#231;&#227;o no dia 01 se tem que confirma no maximo at&#233; dia 03( Seu comprovante vale por 48 horas ), caso contr&#225;rio sua doa&#231;&#227;o n&#227;o &#233; mas valida ou seja no momento que voc&#234; faz uma doa&#231;&#227;o se tem que confirma rapidamente! Para n&#227;o ocorrer atrasos.<BR></FONT>
<P><STRONG>1) Fiz meu dep&#243;sito e confirmei quantos dias devo esperar antes de enviar uma nova confirma&#231;&#227;o?</STRONG><BR><STRONG>R:</STRONG> Sua doa&#231;&#227;o ser&#225; liberada em at&#233; 24hrs ap&#243;s o envio da confirma&#231;&#227;o. Se em 24 horas voc&#234; ainda n&#227;o recebeu sua Doa&#231;&#227;o, envie uma nova confirma&#231;&#227;o.</P>
<P><STRONG>3) O que &#233; imagem do comprovante, como consigo uma? </STRONG><BR><STRONG>R:</STRONG> Esta op&#231;&#227;o serve para agiilizar a ativa&#231;&#227;o de sua Doa&#231;&#227;o. Ap&#243;s escanear o seu comprovante ou tirar uma foto voc&#234; deve hospedar no site citado e enviar o link para n&#243;s usando o campo imagem.</P><FONT color=red>OBS: S&#243; &#233; obrigatorio por Deposito pelo Banco Real.<BR></FONT>
<SCRIPT type=text/javascript>
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("nome", "none", {validateOn:["blur", "change"]});
var sprytextfield2 = new Spry.Widget.ValidationTextField("email", "email", {validateOn:["blur", "change"]});
var sprytextarea1 = new Spry.Widget.ValidationTextarea("dados", {validateOn:["blur", "change"]});
var sprytextfield3 = new Spry.Widget.ValidationTextField("conta", "integer", {validateOn:["blur", "change"]});
var sprytextfield4 = new Spry.Widget.ValidationTextField("personagem", "none", {validateOn:["blur", "change"]});
var sprytextfield5 = new Spry.Widget.ValidationTextField("data", "date", {format:"dd/mm/yyyy", validateOn:["blur"]});
var sprytextfield6 = new Spry.Widget.ValidationTextField("valor", "integer", {validateOn:["blur", "change"]});
var sprytextfield7 = new Spry.Widget.ValidationTextField("hora", "time", {validateOn:["blur", "change"]});
//-->
  </SCRIPT>
<BR><BR></TD></TABLE>
<CENTER></CENTER></TD></TABLE></DIV>
