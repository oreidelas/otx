<?PHP
$main_content .= '<br /><center>
		<table border="0" cellpadding="4" cellspacing="1" width="99%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Downloads</b></font></td>
			</tr>
			<b><h3><font color="red">OBs : Recomendamos baixar nosso Cliente para que possa enxergar nossos Itens</font></h3></b>
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td width="50%"><font class="white">File</font></td><td><font class="white">Link</font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>'.$config['server']['serverName'].' Client 8.60</td><td><a href="https://mega.co.nz/#!GxVEUCiR!ccH5PotRR7Ut4g_pfvkPj2buESVCy1UU8Qsq6DzsRLQ"target="_blank">Download here!</a> (22,8MB)</td>
			</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
				<td>MageBot 8.60 (Bot for Tibia)</td><td><a href="http://tibiadb.com/MagebotSetupvT860.exe" target="_blank">Download here!</a> (623KB)</td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>Hyper Cam (Record your videos)</td><td><a href="http://www.baixaki.com.br/download/hypercam.htm" target="_blank">Download here!</a> (15MB)</td>
			</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
				<td>Team Speak (Speak with your friends)</td><td><a href="http://teamspeak.com/" target="_blank">Download here!</a> (30MB)</td>
			</tr>
		</table><br />
		<table cellpadding="4" cellspacing="1" width="99%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Como usar o '.$config['server']['serverName'].' Client</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>� bem simples! Basta voc� baixar o '.$config['server']['serverName'].' Client, descompactar a pasta, abrir o arquivo "Rivals Client", logar em sua conta e jogar bastante.</td>
			</tr>
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Como usar o Tibia + IP-Changer</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>Para usar o clite do Tibia normal, basta voc� fazer o donwload do Tibia e do IP-Changer, ap�s ter instalado os dois arquivos, abra o Tibia e o IP-Changer, no IP-Changer voc� vai botar o IP do '.$config['server']['serverName'].', selecione o client 8.60 e clique em "IP Changer", pronto, agora � s� fazer o login no client do Tibia.</td>
			</tr>
		</table>
		<br />';
