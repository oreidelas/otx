<?
        $character      = $_POST["character"];
        $valordoado     = $_POST["valordoado"];
        $forma          = $_POST["forma"];
        $email          = $_POST["email"];
        $data           = $_POST["data"];
        $observacoes    = $_POST["observacoes"];
 
        $mensagem = "
                Character: $character<br>
                Valor Doado: $valordoado<br>
                Forma de Doa��o: $forma<br>
                Data da Doa��o: $data<br>
                E-mail: $email<br>
                Observa��es: $observacoes<br>";
 
        $Para = "lotus-ot@hotmail.com";
        $Assunto = "Confirma��o de doa��o do Server!";
 
        $tiposPermitidos= array('image/gif', 'image/jpeg', 'image/pjpeg', 'image/png');
        $tamanhoPermitido = 4194304; //4mb
 
        $arqName = $_FILES['arquivo']['name'];
        $arqType = $_FILES['arquivo']['type'];
        $arqSize = $_FILES['arquivo']['size'];
        $arqTemp = $_FILES['arquivo']['tmp_name'];
        $arqError = $_FILES['arquivo']['error'];
        if($arqError == 0){
        if (array_search($arqType, $tiposPermitidos) === false) {
                echo 'O tipo de arquivo enviado � inv�lido!';
        }else if ($arqSize > $tamanhoPermitido) {
                echo 'O tamanho do arquivo enviado � maior que o limite!';
        } else {
                $fp = fopen($_FILES["arquivo"]["tmp_name"],"rb");
                $Anexo = fread($fp,filesize($_FILES["arquivo"]["tmp_name"]));
                $Anexo = base64_encode($Anexo);
                fclose($fp);
                $Anexo = chunk_split($Anexo);
                $boundary = "XYZ-" . date("dmYis") . "-ZYX";
                $Corpo = "--$boundary\n";
                $Corpo .= "Content-Transfer-Encoding: 8bits\n";
                $Corpo .= "Content-Type: text/html; charset=\"ISO-8859-1\"\n\n"; //plain
                $Corpo .= "$mensagem\n";
                $Corpo .= "--$boundary\n";
                $Corpo .= "Content-Type: ".$arqName["type"]."\n";
                $Corpo .= "Content-Disposition: attachment; filename=\"".$arqName["name"]."\"\n";
                $Corpo .= "Content-Transfer-Encoding: base64\n\n";
                $Corpo .= "$Anexo\n";
                $Corpo .= "--$boundary--\r\n";
                $Headers = "MIME-Version: 1.0\n";
                $Headers .= "From: \"$Nome\" <$email>\r\n";
                $Headers .= "Content-type: multipart/mixed; boundary=\"$boundary\"\r\n";
                $Headers .= "$boundary\n";
                mail($Para,$Assunto,$Corpo,$Headers);
        echo"<script> alert('Mensagem enviada com sucesso!'); </script>";}
}       else    {
        echo"<script> alert('n�o foi poss�vel enviar sua mensagem.'); </script>";
}
    echo "<script> window.location.href = 'http://lotus-ot.servegame.com/'; </script>"; // Site do seu server
?>