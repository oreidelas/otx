<?php
if ($action == ""){
$main_content .='
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="middle"><h1>Erro</h1>
    <p>Pagina requisitada n�o pode ser encontrada, por favor contacte o administrador do website ou tente novamente mais tarde.</p></td>
  </tr>
</table>';}
if ($logged){
$pagseguro_query = $SQL->query("SELECT COUNT(*) FROM `pagsegurotransacoes` WHERE Referencia = '".$account_logged->getCustomField("name")."' LIMIT 1;")->fetch();
}
if ($pagseguro_query[0] >= 3){
if ($action == "error_shop"){
$pagseguro_qry = $SQL->query('SELECT * FROM `pagsegurotransacoes` WHERE '.$SQL->fieldName('referencia').' = '.$SQL->quote($account_logged->getCustomField("name")).';');
$main_content .='
<TABLE BORDER="0" CELLSPACING="1" CELLPADDING="5" WIDTH="100%">
<tr BGCOLOR="'.$config['site']['vdarkborder'].'">
<td CLASS="white"><b style="color: red;">Critical Error !</b></td>
</tr>
<tr BGCOLOR='.$config['site']['darkborder'].'>
<td>Voc� possui mais de <b>3</b> pagamentos em aberto por falta de pagamento.<br />
<br /><u>Deixamos bem claro que nossas ferramentas de doa��es ou compra de points s�o unicas e exclusivamente para o mesmo.</u><br /><br />
Identificamos este ato como uma fraude em nosso sistema.<br />
Selecione os pagamentos que <b>N�O</b> ser�o feitos.
<br /><br />
<form action="index.php?subtopic=error&action=error_shop_" method="post">';
foreach($pagseguro_qry as $pagamentos) {
if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['lightborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .='
<input type="hidden" value="'.$pagamentos['TransacaoID'].'" name="pagamentosTransacaoID" />
<div style="background: '.$bgcolor.'; border: 1px solid #000; padding: 5px;">
<b>Transa��o ID:</b> '.$pagamentos['TransacaoID'].'&#160;-&#160;';
#if ($pagamentos['StatusTransacao'] == "Cancelado"){
$main_content .='
<input type="submit" value="Deletar" />';
#}
$main_content .='
<br /><b>Valor:</b> '.$pagamentos['NumItens'].'<br />
<b>Data:</b> '.$pagamentos['Data'].'<br />
<b>Forma de Pagamento:</b> '.$pagamentos['TipoPagamento'].'<br />
<b>Status:</b> '.$pagamentos['StatusTransacao'].'<br />
</div>
<br />
';
}
$main_content .='
</form>
<b>Delete alguns dos pagamentos para que possamos registrar um novo em sua account.<br />Apenas clique em deletar que o sistema j� ir� liberar sua conta.</b></td>
</tr>
</TABLE>
';}
if ($action == "error_shop_"){
$SQL->query('DELETE FROM `pagsegurotransacoes` WHERE `TransacaoID` = '.$pagamentosTransacaoID.' LIMIT 1;');
$SQL->query('OPTIMIZE TABLE  `pagsegurotransacoes`');
echo '<script type="text/javascript">
location.href=\'index.php?subtopic=donate\';
</script>';
}}
?>