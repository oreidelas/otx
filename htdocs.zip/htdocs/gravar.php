<?php header("Content-Type: text/html; charset=ISO-8859-1",true);
$nome	 = strip_tags(trim($_POST[nome]));
$email	= strip_tags(trim($_POST[email]));
$titulo = strip_tags(trim($_POST[titulo]));
$vl = strip_tags(trim($_POST[vl]));
$hr = strip_tags(trim($_POST[hr]));
$mensagem = strip_tags(trim($_POST[mensagem]));

{
require('phpmailer/class.phpmailer.php');

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true;
$mail->Port = '587'; /*/ Do not change without knowing what it is /*/
$mail->Host = 'smtp.gmail.com';
$mail->Username = '@gmail.com';
$mail->Password = '';
$mail->SetFrom('@live.com', 'Conta '.$titulo.' fez pagamento');
$mail->AddAddress('@live.com', 'Confirma��o NOME DO OT');
$mail->Subject = 'Confirma��o - '.$titulo;

$body = "
<font face='verdana, arial'>
<strong>Character : </strong>{$nome} <br />
<strong>E-mail : </strong>{$email} <br />
<strong>Account : </strong>{$titulo} <br />
<strong>Hora da Doa��o : </strong>{$hr} <br />
<strong>Valor Doado : </strong>{$vl} <br />
<strong>Detalhes Do Comprovante:<br /></strong>{$mensagem} <br />
</font>
";

$mail->MsgHTML($body);

if($mail->Send())
$msg = '
<SCRIPT LANGUAGE="JavaScript">
<!--
window.alert("Confirmation sent successfully !\n\n Wait 24 hours for them to drop their points in your account"); location.href=\'index.php?subtopic=latestnews\';
// -->
</SCRIPT>
';
else
$msg = '<SCRIPT LANGUAGE="JavaScript">
<!--
window.alert("Your message was not sent, try again")
// -->
</SCRIPT>';

};
?>