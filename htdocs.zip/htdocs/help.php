<?PHP
$main_content .= '<center><img src="http://2.imgland.net/1MBxyW.png"><br><br><table cellpadding="4" cellspacing="1" width="97%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Atendimento no '.$config['server']['serverName'].'</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>Ol� caro jogador, aqui � o lugar que voc� poder� entrar em contato diretamente com a equipe do '.$config['server']['serverName'].', aqui voc� poder� tirar suas <b>d�vidas</b>, dar <b>sugest�es</b>, reportar <b>bugs</b>, confirmar <b>doa��es</b>, etc...<br><br> Se voc� for confirmar seus points voc� deve nos enviar o <span style="color:red;"><b>c�digo de transa��o</b></span> da sua compra cedido pelo PagSeguro, ele pode ser encontrado no seu e-mail ou em sua conta do PagSeguro!<br><br>Voc� tem o limite de 1 chamado aberto por vez, portanto voc� deve esperar seu chamado ser respondido para poder abrir outro. <br><br>Os tempo de resposta dos chamados variam de 10 minutos ou at� no m�ximo 48 horas para serem respondidos por nossa equipe. <br><br><a href="?subtopic=helpdesk">>> Clique aqui para realizar e averiguar seus chamados.</a></td>
			</tr>
		</table>
		<br>';
