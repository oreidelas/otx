<?php
if(!$logged && $action == ''){
$main_content .= '
<div class="TableContainer" >
<table class="Table1" cellpadding="0" cellspacing="0" > 
<div class="CaptionContainer" >
<div class="CaptionInnerContainer" >
<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>
<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>
<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);" ></span>
<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></span>   
<div class="Text" >History Erro</div>
<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></span>
<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif)></span>
<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>
<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>       
</div></div><tr><td>
<div class="InnerTableContainer" >
<table style="width:100%;" ><tr><td>
<b style="color: red">You need to login first.</b>
</td>
</tr></table></div></table></div></td></tr><br />';
$link = "index.php?subtopic=history";
include ("login.php");
}
if(!$logged){
}else{
$items_history_received = $SQL->query('SELECT * FROM '.$SQL->tableName('z_shop_history_item').' WHERE '.$SQL->fieldName('to_account').' = '.$SQL->quote($account_logged->getId()).' OR '.$SQL->fieldName('from_account').' = '.$SQL->quote($account_logged->getId()).';');
	if(is_object($items_history_received)) {
	foreach($items_history_received as $item_received) {
	if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
		$items_received_text .= '
		<tr bgcolor="'.$bgcolor.'">
			<td style="padding: 5px;">'.$item_received['to_name'].'</td>
			<td>'.$item_received['price'].' Points</td>
			<td>'.date("j F Y, H:i:s", $item_received['trans_start']).'</td>';	
	if($item_received['trans_real'] > 0)
		$items_received_text .= '<td>'.date("j F Y, H:i:s", $item_received['trans_real']).'</td>';
	else
		$items_received_text .= '<td><b><font color="red">Undelivered</font></b></td>';
		$items_received_text .= '</tr>';
	}}
		$paccs_history_received = $SQL->query('SELECT * FROM '.$SQL->tableName('z_shop_history_pacc').' WHERE '.$SQL->fieldName('to_account').' = '.$SQL->quote($account_logged->getId()).' OR '.$SQL->fieldName('from_account').' = '.$SQL->quote($account_logged->getId()).';');
	if(is_object($paccs_history_received)) {
	foreach($paccs_history_received as $pacc_received) {
	if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['lightborder']; } else { $bgcolor = $config['site']['darkborder']; } $number_of_rows++;
		$paccs_received_text .= '
		<tr bgcolor="'.$bgcolor.'">
			<td style="padding: 5px;">'.$pacc_received['to_name'].'</td>
			<td>'.$pacc_received['pacc_days'].' days</td>
			<td>'.$pacc_received['price'].' Points</td>
			<td>'.date("j F Y, H:i:s", $pacc_received['trans_real']).'</td>
		</tr>';
	}}
	$pagseguro_history_received = $SQL->query('SELECT * FROM `pagsegurotransacoes` WHERE '.$SQL->fieldName('referencia').' = '.$SQL->quote($account_logged->getCustomField("name")).';');
	if(is_object($pagseguro_history_received)) {
	foreach($pagseguro_history_received as $pagseguro_received) {
		if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
		$pagseguro_received_text .= '<tr bgcolor="'.$bgcolor.'"><td>'.$pagseguro_received['TransacaoID'].'</td><td>';
		$pagseguro_received_text .= $pagseguro_received['TipoPagamento'];
		$pagseguro_received_text .= '</td><td>R$'.$pagseguro_received['NumItens'].',00</td><td><b style="color:red;">'.$pagseguro_received['StatusTransacao'].'</b></td></tr>';
	}
	}
	$main_content .= '<center><h1>Transactions History</h1></center>';
	if(!empty($items_received_text)) 
		$main_content .= '
		<div class="TableContainer">
		<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
		<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
		<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<div class="Text">Items Transactions</div>
		<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
		<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		</div></div>
		<table class="Table5" cellpadding="0" cellspacing="0">
		<tbody><tr><td>
		<div class="InnerTableContainer">
		<table style="width:100%;">
		<tbody><tr><td>
		<div class="TableShadowContainerRightTop">
		<div class="TableShadowRightTop" style="background-image:url('.$layout_name.'/images/content/table-shadow-rt.gif);">
		</div></div>
		<div class="TableContentAndRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-rm.gif);">
		<div class="TableContentContainer">
		<table width="100%" border="0" cellpadding="2" cellspacing="2" class="TableContent" style="border:1px solid #faf0d7;" ><tbody><tr>	
		<center>
		<tr bgcolor="#D4C0A1">
		<td><b>Player:</b></td>
		<td><b>Cost:</b></td>
		<td><b>Bought on page:</b></td>
		<td><b>
		Received on '.$config['server']['serverName'].'</b></td></tr>'.$items_received_text.'
		</td></tr></td></tr></tbody></table></div></div>
		<div class="TableShadowContainer">
		<div class="TableBottomShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bm.gif);">
		<div class="TableBottomLeftShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bl.gif);"></div>
		<div class="TableBottomRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-br.gif);"></div>
		</div>
		</div>
		</td>
		</tr>
		</tbody>
		</table>
		</div>
		</td>
		</tr>
		</tbody>
		</table>
		</div>
		</strong>
		<br/>
		</form>';
			
	if(!empty($paccs_received_text))
	$main_content .= '
		<div class="TableContainer">
		<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
		<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
		<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<div class="Text">Pacc Transactions</div>
		<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
		<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		</div>
		</div>
		<table class="Table5" cellpadding="0" cellspacing="0">
		<tbody>
		<tr>
		<td>
		<div class="InnerTableContainer">
		<table style="width:100%;">
		<tbody>
		<tr>
		<td>
		<div class="TableShadowContainerRightTop">
		<div class="TableShadowRightTop" style="background-image:url('.$layout_name.'/images/content/table-shadow-rt.gif);">
		</div>
		</div>
		<div class="TableContentAndRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-rm.gif);">
		<div class="TableContentContainer">
		<table width="100%" border="0" cellpadding="2" cellspacing="2" class="TableContent" style="border:1px solid #faf0d7;" ><tbody><tr>	
		<tr bgcolor="#D4C0A1">
		<td><b>To:</b></td>
		<td><b>Duration:</b></td>
		<td><b>Cost:</b></td><td>
		<b>Added:</b></td></tr>
		'.$paccs_received_text.'
		</td>
		</tr>
		</td>
		</tr>
		</tbody>
		</table>
		</div>
		</div>
		<div class="TableShadowContainer">
		<div class="TableBottomShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bm.gif);">
		<div class="TableBottomLeftShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bl.gif);"></div>
		<div class="TableBottomRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-br.gif);"></div>
		</div>
		</div>
		</td>
		</tr>
		</tbody>
		</table>
		</div>
		</td>
		</tr>
		</tbody>
		</table>
		</div>
		</strong>
		<br/>
		</form>';
				
	if(!empty($pagseguro_received_text))
	$main_content .= '
		<div class="TableContainer">
		<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
		<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
		<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<div class="Text">PagSeguro Donations</div>
		<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
		<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		</div></div>
		<table class="Table5" cellpadding="0" cellspacing="0">
		<tbody><tr><td>
		<div class="InnerTableContainer">
		<table style="width:100%;">
		<tbody><tr><td>
		<div class="TableShadowContainerRightTop">
		<div class="TableShadowRightTop" style="background-image:url('.$layout_name.'/images/content/table-shadow-rt.gif);">
		</div></div>
		<div class="TableContentAndRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-rm.gif);">
		<div class="TableContentContainer">
		<table width="100%" border="0" cellpadding="2" cellspacing="2" class="TableContent" style="border:1px solid #faf0d7;" ><tbody><tr>	
		<tr bgcolor="#D4C0A1">
		<td><b>ID:</b></td>
		<td><b>Tipo</b></td>
		<td><b>Custo</b></td>
		<td><b>Status</b></td>
		</tr>'.$pagseguro_received_text.'
		</td></tr></td></tr></tbody></table></div></div>
		<div class="TableShadowContainer">
		<div class="TableBottomShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bm.gif);">
		<div class="TableBottomLeftShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-bl.gif);"></div>
		<div class="TableBottomRightShadow" style="background-image:url('.$layout_name.'/images/content/table-shadow-br.gif);"></div>
		</div></div></td></tr></tbody></table></div></td></tr></tbody></table></div></strong><br/></form>';

	if(empty($paccs_received_text) && empty($items_received_text) && empty($pagseguro_received_text))
		$main_content .= '
		<div class="TableContainer" >
		<table class="Table1" cellpadding="0" cellspacing="0" > 
		<div class="CaptionContainer" >
		<div class="CaptionInnerContainer" >
		<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>
		<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>
		<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);" ></span>
		<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
		<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></span>   
		<div class="Text" >Historic Purchase</div>
		<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></span>
		<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif)></span>
		<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>
		<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>       
		</div></div><tr><td>
		<div class="InnerTableContainer" >
		<table style="width:100%;" ><tr><td>
		You do not have historic purchase, go to <a href="?subtopic=shopsystem">shop</a>.
		</td>
		</tr></table></div></table></div></td></tr>';
	}
?>