<?php
header ("Location: ../");
?>