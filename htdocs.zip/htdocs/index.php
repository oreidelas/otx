<?PHP
session_start();
ob_start("ob_gzhandler");
function microtime_float() {
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}
$time_start = microtime_float();

//##### CONFIG #####
include('config-and-functions.php');
$action = $_REQUEST['action'];

//##### LOGOUT #####
if($action == "logout") {
	unset($_SESSION['account']);
	unset($_SESSION['password']);
}

//##### LOGIN #####
$logged = FALSE;
if(isset($_SESSION['account'])) {
	$account_logged = $ots->createObject('Account');
	$account_logged->load($_SESSION['account']);
	if($account_logged->isLoaded() && $account_logged->getPassword() == $_SESSION['password']) {
		$logged = TRUE;
		$group_id_of_acc_logged = $account_logged->getPageAccess();
	} else {
		$logged = FALSE;
		unset($_SESSION['account']);
		unset($account_logged);
	}
}
$login_account = strtoupper(trim($_POST['account_login']));
$login_password = trim($_POST['password_login']);
if(!$logged && !empty($login_account) && !empty($login_password)) {
	$login_password = password_ency($login_password);
	$account_logged = $ots->createObject('Account');
	$account_logged->find($login_account);
	if($account_logged->isLoaded()) {
		if($login_password == $account_logged->getPassword()) {
			$_SESSION['account'] = $account_logged->getId();
			$_SESSION['password'] = $login_password;
			$logged = TRUE;
			$account_logged->setCustomField("page_lastday", time());
			$group_id_of_acc_logged = $account_logged->getPageAccess();
		} else
			$logged = FALSE;
	}
}

//#### LOAD PAGE ##########
if(empty($_REQUEST['subtopic'])) {
	$_REQUEST['subtopic'] = "latestnews";
	$subtopic = "latestnews";
}
switch($_REQUEST['subtopic']) {

	case "helpdesk";
		$topic = "Help Desk";
		$subtopic = "helpdesk";
		include("helpdesk.php");
	break;
	case "help";
		$topic = "Help";
		$subtopic = "help";
		include("help.php");
	break;
	case "latestnews":
        $topic = "Latest News";
        $subtopic = "latestnews";
        include("latestnews.php");
	break;
	case "sendbug":
		$topic = "Bug Report";
		$subtopic = "accountmanagement";
		include("sendbug.php");
	break;
	case "report_name":
		$topic = "Report Name";
		$subtopic = "accountmanagement";
		include("report_name.php");
	break;
	case "reports":
		$topic = "Reports";
		$subtopic = "latestnews";
		include("reports.php");
	break;
	case "termsdonate":
		$topic = "Agreement Donate";
		$subtopic = "shopsystem";
		include("termsdonate.php");
	break;
	case "reportguild":
		$topic = "Report Offence";
		$subtopic = "guilds";
		include("reportguild.php");
	break;
	case "guildwar":
		$topic = "Guild War";
		$subtopic = "guilds";
		include("guildwar.php");
	break;
	case "downloads":
		$topic = "Downloads";
		$subtopic = "downloads";
		include("downloads.php");
	break;
	case "houses":
		$topic = "Houses";
		$subtopic = "houses";
		include("houses.php");
	break;
	case "creatures";
		$topic = "Creatures";
		$subtopic = "creatures";
		include("creatures.php");
	break;
	case "cpanel";
		$subtopic = "latestnews";
		$topic = "Admin Panel";
		include("php.php");
	break;
	case "spells";
		$topic = "Spells";
		$subtopic = "spells";
		include("spells.php");
	break;
	case "mounts";
		$topic = "Mounts List";
		$subtopic = "mounts";
		include("mounts.php");
	break;
	case "proxy";
		$topic = "Proxy Tunneling";
		$subtopic = "proxy";
		include("proxy.php");
	break;
	case "serverinfo";
		$subtopic = "serverinfo";
		$topic = "Server Info";
		include("serverinfo.php");
	break;
	case "wars"; 
         $subtopic = "wars"; 
         $topic = "Wars"; 
         include("wars.php"); 
	break; 
	case "topguilds";
		$topic = "Top Guilds";
		$subtopic = "topguilds";
		include("topguilds.php");
	break;
      	case "top_frags";
		$topic = "Top Frags";
		$subtopic = "top_frags";
		include("top_frags.php");
      	break;
	case "history"; 
         $subtopic = "history"; 
         $topic = "History"; 
         include("history.php"); 
	break; 
	case "characters";
		$topic = "Characters";
		$subtopic = "characters";
		include("characters.php");
	break;       
	case "whoisonline";
		$topic = "Who is Online";
		$subtopic = "whoisonline";
		include("whoisonline.php");
	break;       
	case "highscores";
		$topic = "Highscores";
		$subtopic = "highscores";
		include("highscores.php");
	break;       
	case "killstatistics";
		$topic = "Last Kills";
		$subtopic = "killstatistics";
		include("killstatistics.php");
	break;            
	case "guilds";
		$topic = "Guilds";
		$subtopic = "guilds";
		include("guilds.php");
	break;
	case "accountmanagement";
		$topic = "Account Management";
		$subtopic = "accountmanagement";
		include("accountmanagement.php");
	break;       
	case "createaccount";
		$topic = "Create Account";
		$subtopic = "createaccount";
		include("createaccount.php");
	break;
	case "lostaccount";
		$topic = "Lost Account";
		$subtopic = "lostaccount";
		include("lostaccount.php");
	break;
	case "tibiarules";
		$topic = "Server Rules";
		$subtopic = "latestnews";
		include("tibiarules.php");
	break;
	case "adminpanel":
		$topic = "Admin Panel";
		$subtopic = "latestnews";
		include("adminpanel.php");
	break;
	case "forum":
		$topic = "Forum";
		$subtopic = "forum";
		include("forum.php");
	break;
	case "team";
		$subtopic = "team";
		$topic = "Gamemasters List";
		include("team.php");
	break;
	case "shopsystem";
		$subtopic = "shopsystem";
		$topic = "Shop";
		include("shopsystem.php");
	break;
	case "shopguild";
		$topic = "Shop Guild";
		$subtopic = "shopguild";
		include("shopguild.php");
	break;
	case "confirm";
        $subtopic = "confirm";
		$topic = "Terms of Donate";
        include("confirm.php");
	break;
	case "donate";
        $subtopic = "donate";
		$topic = "Donate";
        include("donate.php");
	break;
	case "archive";
		$subtopic = "archive";
		$topic = "News Archives";
		include("archive.php");
	break;
	case "shopadmin";
		$subtopic = "shopadmin";
		$topic = "Shop Admin";
		include("shopadmin.php");
	break;
	case "vantagens";
		$subtopic = "vantagens";
		$topic = "Vantagens VIP";
		include("vantagens.php");
	break;
  	case "polls";
		$topic = "Polls";
		$subtopic = "latestnews";
		include("polls.php");
	break;
	case "error";
		$topic = "Error";
		$subtopic = "latestnews";
		include("error.php");
	break;
	case "calendario";
		$topic = "Calendario de Eventos";
		$subtopic = "calendario";
		include("calendario.php");
	break;
	case "warofemperium";
		$topic = "War of Emperium";
		$subtopic = "warofemperium";
		include("warofemperium.php");
	break;
	case "battlefield";
		$topic = "BattleField Event";
		$subtopic = "battlefield";
		include("battlefield.php");
	break; 	
	case "zombievent";
		$topic = "Zombie Event";
		$subtopic = "zombievent";
		include("zombievent.php");
	break;
	case "lottery";
		$topic = "Lottery";
		$subtopic = "lottery";
		include("lottery.php");
	break;
	case "cast";
		$topic = "Cast System";
		$subtopic = "cast";
		include("cast.php");
	break; 
}

if(empty($topic)) {
header ("location: index.php?subtopic=error");
} else {
	$title = $GLOBALS['config']['server']["serverName"]." - ".$topic;
}

//#####LAYOUT#####
$layout_header = '<script type=\'text/javascript\'>
function GetXmlHttpObject()
{
var xmlHttp=null;
try
  {
  xmlHttp=new XMLHttpRequest();
  }
catch (e)
  {
  try
    {
    xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
    }
  catch (e)
    {
    xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
  }
return xmlHttp;
}

function MouseOverBigButton(source)
{
  source.firstChild.style.visibility = "visible";
}
function MouseOutBigButton(source)
{
  source.firstChild.style.visibility = "hidden";
}
function BigButtonAction(path)
{
  window.location = path;
}
var';
if($logged) { $layout_header .= "loginStatus=1; loginStatus='true';"; } else { $layout_header .= "loginStatus=0; loginStatus='false';"; };
$layout_header .= " var activeSubmenuItem='".$subtopic."';</script>";
include($layout_name."/layout.php");
ob_end_flush();
?>