<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
$update_interval = 10;if(!isset($world_id)){$world_id = 0;$world_name = $config['server']['serverName'];}$order = $_REQUEST['order'];if($order == 'level')$orderby = 'level';elseif($order == 'vocation')$orderby = 'vocation';if(empty($orderby))$orderby = 'name';$tmp_file_name = 'cache/whoisonline-'.$orderby.'-'.$world_id.'.tmp';
if(file_exists($tmp_file_name) && filemtime($tmp_file_name) > (time() - $update_interval)){$tmp_file_content = explode(",", file_get_contents($tmp_file_name));$number_of_players_online = $tmp_file_content[0];$players_rows = $tmp_file_content[1];}
else{$players_online_data = $SQL->query('SELECT * FROM players WHERE world_id = '.(int) $world_id.' AND online > 0 ORDER BY '.$orderby);$number_of_players_online = 0;
foreach($players_online_data as $player){$number_of_players_online++;$acc = $SQL->query('SELECT * FROM '.$SQL->tableName('accounts').' WHERE '.$SQL->fieldName('id').' = '.$player['account_id'].'')->fetch();if(is_int($number_of_players_online / 2))$bgcolor = $config['site']['darkborder'];else$bgcolor = $config['site']['lightborder'];$rs = "";if ($player['skulltime'] > 0 && $player['skull'] == 3)$rs = "<img style='border: 0;' src='./images/whiteskull.gif'/>";elseif ($player['skulltime'] =  $player['skull'] == 4)$rs = "<img style='border: 0;' src='./images/redskull.gif'/>";elseif ($player['skulltime'] =  $player['skull'] == 5)$rs = "<img style='border: 0;' src='./images/blackskull.gif'/>";$players_rows .= '<TR BGCOLOR='.$bgcolor.'><TD WIDTH=10%><image src="images/flags/'.$acc['flag'].'.png"/></TD><TD WIDTH=70%><A HREF="?subtopic=characters&name='.urlencode($player['name']).'">'.$player['name'].$rs.'</A></TD><TD WIDTH=10%>'.$player['level'].'</TD><TD WIDTH=20%>'.$vocation_name[$world_id][$player['promotion']][$player['vocation']].'</TD></TR>';}}

function anti_injection($sql){
// remove palavras que contenham sintaxe sql
$sql = preg_replace(sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$sql);
$sql = trim($sql);//limpa espa�os vazio
$sql = strip_tags($sql);//tira tags html e php
$sql = addslashes($sql);//Adiciona barras invertidas a uma string
return $sql;
}
?>
  <title><?PHP echo "$title"; ?></title>
  <meta name="description" content="Tibia is a free massive multiplayer online role playing game (MMORPG)." />
  <meta name="author" content="Victor Fasano Raful" />
  <meta http-equiv="content-language" content="pt-br" />
  <meta http-equiv="content-type" content="text/html; charset=iso-8859-1"/>
  <meta name="keywords" content="free online game, free multiplayer game, ots, open tibia server" />
  <link rel="shortcut icon" href="images/monsters/braindeath.gif" type="image/x-icon" />
  <link rel="icon" href="images/monsters/braindeath.gif" type="image/x-icon" />
  <?PHP echo "$layout_header"; ?>
  <link href="<?PHP echo "$layout_name"; ?>/basic.css" rel="stylesheet" type="text/css">
  <script type='text/javascript'> var IMAGES=0; IMAGES='<?PHP echo "$layout_name"; ?>/images'; var g_FormField='';  var LINK_ACCOUNT=0; LINK_ACCOUNT='';</script>
  <script type="text/javascript" src="<?PHP echo "$layout_name"; ?>/initialize.js"></script>
  <script type="text/javascript" src="<?PHP echo "$layout_name"; ?>/ajaxcip.js"></script>
	<script type="text/javascript" src="<?PHP echo "$layout_name"; ?>/generic.js"></script>
	<script type="text/javascript" src="<?PHP echo "$layout_name"; ?>/ga.js"></script>
	<script type="text/javascript" src="<?PHP echo "$layout_name"; ?>/jquery.js"></script>
	
<SCRIPT TYPE="text/javascript">
  <!-- // Framekiller
  setTimeout ("changePage()", 6000);
  function changePage()
  {
    if (parent.frames.length > 2) {
      if (browserTyp == "ie") {
        parent.location=document.location;
      } else {
        self.top.location=document.location;
      }
    }
  }
  // -->
</SCRIPT>
</head>
<body onBeforeUnLoad="SaveMenu();" onUnload="SaveMenu();">
<a name="top"></a>
<div id="HeaderArtworkDiv" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/maintenance.jpg);"></div>
<div id="Bodycontainer">
<div id="ContentRow" style="margin-top: 30px;">
<div id="MenuColumn">
<div id="LeftArtwork">
<img src="<?PHP echo "$layout_name"; ?>/images/header/tibia-logo-artwork-top.gif" alt="logoartwork" name="TibiaLogoArtworkTop" id="TibiaLogoArtworkTop" onClick="window.location = 'index.php?subtopic=latestnews';" />
</div>
<div id="Loginbox" >
<div id="LoginTop" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/box-top.gif)" ></div>
<div id="BorderLeft" class="LoginBorder" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/chain.gif)" ></div>
<div id="LoginButtonContainer" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/loginbox/loginbox-textfield-background.gif)" >
<div id="PlayNowContainer" ><input type="hidden" name="page" value="overview" ><div class="MediumButtonBackground" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/buttons/mediumbutton.gif)" onMouseOver="MouseOverMediumButton(this);" onMouseOut="MouseOutMediumButton(this);" ><div class="MediumButtonOver" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/buttons/mediumbutton-over.gif)" onMouseOver="MouseOverMediumButton(this);" onMouseOut="MouseOutMediumButton(this);" ></div><input class="MediumButtonText" type="image" name="Play Now" alt="Play Now" src="<?PHP echo "$layout_name"; ?>/images/buttons/mediumbutton_playnow.png" /></div></div>
</div>
<div class="Loginstatus" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/loginbox/loginbox-textfield-background.gif)" >
<div id="LoginstatusText_1" onClick="LoginstatusTextAction(this);" onMouseOver="MouseOverLoginBoxText(this);" onMouseOut="MouseOutLoginBoxText(this);" ><div id="LoginstatusText_1_1" name="LoginstatusText_1" class="LoginstatusText" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/loginbox/loginbox-font-create-account.gif)" ></div><div id="LoginstatusText_2" class="LoginstatusText" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/loginbox/loginbox-font-create-account-over.gif)" ></div></div>        <div id="ButtonText" ></div>
</div>
<div id="BorderRight" class="LoginBorder" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/chain.gif)" ></div>
<div id="LoginBottom" class="Loginstatus" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/box-bottom.gif)" ></div>
</div>
<div id="SocialLinkup" class="Submenu" >
  <a target="_blank" href="https://www.facebook.com/tibia" alt="Tibia Facebook Page" >
    <div onmouseout="MouseOutSubmenuItem(this)" onmouseover="MouseOverSubmenuItem(this)" class="Submenuitem" >
      <div style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/chain.gif);" class="LeftChain" ></div>
      <img class="SocialLinkupLogo" src="images/social-network_mini_facebook.png" />
      <div class="SubmenuitemLabel" id="ActiveSubmenuItemLabel_latestnews" ><?php echo $config['server']['serverName']; ?> Facebook</div>
      <div style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/chain.gif);" class="RightChain" ></div>
    </div>
  </a>
  <a target="_blank" href="https://twitter.com/Tibia" alt="Tibia Tweet" >
    <div onmouseout="MouseOutSubmenuItem(this)" onmouseover="MouseOverSubmenuItem(this)" class="Submenuitem" >
      <div style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/chain.gif);" class="LeftChain" ></div>
      <img class="SocialLinkupLogo" src="images/social-network_mini_twitter.png" />
      <div class="SubmenuitemLabel" id="ActiveSubmenuItemLabel_newsarchive" >Follow <?php echo $config['server']['serverName']; ?></div>
      <div style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/chain.gif);" class="RightChain" ></div>
    </div>
  </a>
</div>
<div id='Menu'>
<div id='MenuTop' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/general/box-top.gif);'></div>
<div id='news' class='menuitem'>
<span onClick="MenuItemAction('news')">
  <div class='MenuButton' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background.gif);'>
    <div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background-over.gif);'></div>
      <div id='news_Icon' class='Icon' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/icon-news.gif);'></div>
      <div id='news_Label' class='Label' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/label-news.gif);'></div>
    </div>
  </div>
</span>
<div id='news_Submenu' class='Submenu'>
</div>
</div>
<div id='account' class='menuitem'>
<span onClick="MenuItemAction('account')">
  <div class='MenuButton' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background.gif);'>
    <div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background-over.gif);'></div>
	<div id='account_Icon' class='Icon' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/icon-account.gif);'></div>
	<div id='account_Label' class='Label' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/label-account.gif);'></div>      
    </div>
  </div>
</span>
<div id='account_Submenu' class='Submenu'>
</div>
</div>

<div id='community' class='menuitem'>
<span onClick="MenuItemAction('community')">
  <div class='MenuButton' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background.gif);'>
    <div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background-over.gif);'></div>    
	<div id='community_Icon' class='Icon' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/icon-community.gif);'></div>
	<div id='community_Label' class='Label' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/label-community.gif);'></div>
    </div>
  </div>
</span>
<div id='community_Submenu' class='Submenu'>
</div>
</div>

<?PHP
echo "
<div id='forum' class='menuitem'>
<span onClick=\"MenuItemAction('forum')\">
<div class='MenuButton' style='background-image:url(".$layout_name."/images/menu/button-background.gif);'>
<div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(".$layout_name."/images/menu/button-background-over.gif);'></div>
<div id='forum_Icon' class='Icon' style='background-image:url(".$layout_name."/images/menu/icon-forum.gif);'></div>
<div id='forum_Label' class='Label' style='background-image:url(".$layout_name."/images/menu/label-forum.gif);'></div>
</div>
</div>
</span>
<div id='forum_Submenu' class='Submenu'>

</div>  
</div>";
?>
<div id='library' class='menuitem'>
<span onClick="MenuItemAction('library')">
  <div class='MenuButton' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background.gif);'>
    <div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/button-background-over.gif);'></div>
	<div id='library_Icon' class='Icon' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/icon-library.gif);'></div>
	<div id='library_Label' class='Label' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/menu/label-library.gif);'></div>
    </div>
  </div>
</span>
<div id='library_Submenu' class='Submenu'>
</div>
</div>

<?PHP
if ($logged){
$pagseguro_query = $SQL->query("SELECT COUNT(*) FROM `pagsegurotransacoes` WHERE Referencia = '".$account_logged->getCustomField("name")."' LIMIT 1;")->fetch();
}
echo "<div id='shops' class='menuitem'>
<span onClick=\"MenuItemAction('shops')\">
  <div class='MenuButton' style='background-image:url(".$layout_name."/images/menu/button-background.gif);'>
    <div onMouseOver='MouseOverMenuItem(this);' onMouseOut='MouseOutMenuItem(this);'><div class='Button' style='background-image:url(".$layout_name."/images/menu/button-background-over.gif);'></div>
	<div id='shops_Icon' class='Icon' style='background-image:url(".$layout_name."/images/menu/icon-shops.gif);'></div>
	<div id='shops_Label' class='Label' style='background-image:url(".$layout_name."/images/menu/label-shops.gif);'></div>
    </div>
  </div>
</span>
</div>
<div id='shops_Submenu' class='Submenu'>
</div>";
?>
<div id='MenuBottom' style='background-image:url(<?PHP echo "$layout_name"; ?>/images/general/box-bottom.gif);'></div>
</div>
<script type='text/javascript'>InitializePage();</script></div>
<div id="ContentColumn">
<div class="Content">
<div id="ContentHelper">
<div id="<?PHP echo "$subtopic"; ?>" class="Box">
<div class="Corner-tl" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/corner-tl.gif);"></div>
<div class="Corner-tr" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/corner-tr.gif);"></div>
<div class="Border_1" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/border-1.gif);"></div>
<div class="BorderTitleText" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/title-background-green.gif);"></div>
<img class="Title" src="headline.php?text=Maintenance" alt="Contentbox headline" />
<div class="Border_2">
<div class="Border_3">
<div class="BoxContent" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/scroll.gif);">
<div class="NewsHeadline">
<div class="NewsHeadlineBackground" style="background-image:url(<?php echo $layout_name; ?>/images/news/newsheadline_background.gif)">
<img src="<?php echo $layout_name; ?>/images/news/icon_1_big.gif" class="NewsHeadlineIcon" />
<div class="NewsHeadlineDate"><?php echo date('j M Y'); ?> - </div>
<div class="NewsHeadlineText">Manuten��o Automatizada</div>
</div>
</div>
<img src="images/letters/N.gif" />ossos servidores detectaram uma suspeita a��o de alguns IPs tentando penetrar por <b>FTP</b> <i>(File Transfer Protocol)</i> em nossos servidores, ou seja, invas�o do mesmo.<br />
<br /><b>C</b>ertificamos que nosso website tem a capacidade de n�o deixar nenhum lammer invadir, por isto entramos automaticamente em modo de seguran�a, para preven��o de invas�o.<br />
<br /><b>D</b>entro de alguns minutos ser� bloqueado todos os IPs que est�o com ping maior do normal(invas�es e acessos ao servidor).
<br /><br />Atenciosamente, Equipe.
</div>
</div>
</div>
    <div class="Border_1" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/border-1.gif);"></div>

    <div class="CornerWrapper-b"><div class="Corner-bl" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/corner-bl.gif);"></div></div>
    <div class="CornerWrapper-b"><div class="Corner-br" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/content/corner-br.gif);"></div></div>
  
</div>
</div>
</div>
<div id="Footer">
Created by Gesior.pl <b>Fixed by <a href="mailto:victorfasanoraful@live.com">Victor Fasano Raful</a>&nbsp;V<font color="#FF0000"><?=$v;?></font></b><br />Layout created by <a href="http://www.cipsoft.com" target="_new"><b>CipSoft GmbH</b></a><br />
All rights reserveds
</div>
</div>
<div id="ThemeboxesColumn">

<div id="RightArtwork">
<img id="Monster" src="images/monsters/<?PHP echo logo_monster() ?>.gif" />
<img id="PedestalAndOnline" src="<?PHP echo "$layout_name"; ?>/images/header/pedestal-and-online.gif" alt="Monster Pedestal and Players Online Box"/>
<?PHP
if(count($config['site']['worlds']) > 1)
$whoisonlineworld = 'index.php?subtopic=whoisonline'; 
else
$whoisonlineworld = 'index.php?subtopic=whoisonline&world=0';
?>
<div id="PlayersOnline">
<?PHP
if($config['status']['serverStatus_online'] == 1)
echo ''.$number_of_players_online.'<br />Players Online';
else
echo 'Server<br /><font color="red">OFFLINE</font>';
?></div>
</div>
<div id="Themeboxes">
<div id="NewcomerBox" class="Themebox" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/themeboxes/newcomer/newcomerbox.gif);">
	<div class="ThemeboxButton" onMouseOver="MouseOverBigButton(this);" onMouseOut="MouseOutBigButton(this);" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/buttons/sbutton.gif);"><div class="BigButtonOver" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/buttons/sbutton_over.gif);"></div>
	<div class="ButtonText" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/buttons/_sbutton_jointibia.gif);"></div>
	</div>
	<div class="Bottom" style="background-image:url(<?PHP echo "$layout_name"; ?>/images/general/box-bottom.gif);"></div>
</div>
<?PHP
$time = time();
$viewpoll = $SQL->query('SELECT * FROM z_polls where end > '.$time.' ORDER BY id DESC LIMIT 1');
foreach($viewpoll as $p)
$polls .= '<center>'.$p['question'].'</center>';
    if(count($p['id']) > 0)
     echo '<div id="CurrentPollBox" class="Themebox" style="background-image:url('.$layout_name.'/images/themeboxes/current-poll/currentpollbox.gif);">
      <div id="CurrentPollText">'.$polls.'</div>
      <a class="ThemeboxButton" href="index.php?subtopic=polls&id= '.$p['id'].'" onMouseOver="MouseOverBigButton(this);" onMouseOut="MouseOutBigButton(this);" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
        <div class="ButtonText" style="background-image:url('.$layout_name.'/images/buttons/_sbutton_votenow.gif);"></div>
      </a>
    <div class="Bottom" style="background-image:url('.$layout_name.'/images/general/box-bottom.gif);"></div>
    </div>';
?>
<?PHP
if($group_id_of_acc_logged >= $config['site']['access_admin_panel']){
$count_reports = $SQL->query("SELECT COUNT(*) FROM `reports`")->fetch();
echo '
<div id="CurrentPollBox" class="Themebox" style="background-image:url('.$layout_name.'/images/themeboxes/admin/admin.gif);">
<div id="CurrentPollText">
<input type="button" value="Admin Painel" onclick="location.href=\'index.php?subtopic=cpanel\'" /><br />
<input type="button" value="Manage Polls" onclick="location.href=\'index.php?subtopic=polls\'" /><br />
<input type="button" value="Shop Admin" onclick="location.href=\'index.php?subtopic=shopadmin\'" /><br />
<input type="button" value="Reports ['.$count_reports[0].']" onclick="location.href=\'index.php?subtopic=reports\'" /><br />
</div>
<div class="Bottom" style="background-image:url('.$layout_name.'/images/general/box-bottom.gif);"></div>
</div>';
}
?>
</div>
</div>
</div>
</div>
</div>
</body>