<?php
$players = $SQL->query('SELECT COUNT(*) FROM `players` WHERE `id`>0;')->fetch();
		$main_content .= '
		<form action="'.$link.'" method="post">
		<div class="TableContainer">
		<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
		<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
		<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<div class="Text">Account Login</div>
		<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
		<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		</div>
		</div>
		<table class="Table1" cellpadding="0" cellspacing="0">
		<tbody><tr><td>
		<div class="InnerTableContainer">
		<table style="width:100%;">
		<tbody><tr><td class="LabelV">
		<span>Account Name:</span>
		</td><td>
		<input name="account_login" size="35" maxlength="30" type="password">
		</td>
		<td style="width:100%;padding-left:5px;" rowspan="2">
		</td></tr><tr>
		<td class="LabelV">
		<span>Password:</span>
		</td><td>
		<input name="password_login" size="35" maxlength="29" type="password">
		</td></tr></tbody></table></div></td></tr></tbody></table></div><br>
		<table width="100%"><tbody><tr align="center"><td><input name="page" value="overview" type="hidden">
		<div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)">
		<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url(&quot;'.$layout_name.'/images/buttons/sbutton_over.gif&quot;); visibility: hidden;">
		</div><input class="ButtonText" name="Submit" alt="Submit" src="'.$layout_name.'/images/buttons/_sbutton_submit.gif" type="image">
		</form></div></div></td><td>
		<form action="?subtopic=lostaccount" method="post" style="padding:0px;margin:0px;">
		<div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)">
		<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url(&quot;'.$layout_name.'/images/buttons/sbutton_over.gif&quot;); visibility: hidden;"></div>
		<input class="ButtonText" name="Account lost?" alt="Account lost?" src="'.$layout_name.'/images/buttons/_sbutton_accountlost.gif" type="image">
		</div></div>
		</form></td></tr></tbody></table><br><br><center>
		<h1>New to Tibia?</h1>
		</center>
		<div class="TableContainer">
		<div class="CaptionContainer">
		<div class="CaptionInnerContainer">
		<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
		<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<div class="Text">New Player</div>
		<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
		<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
		<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
		</div></div>
		<table class="Table1" cellpadding="0" cellspacing="0">
		<tbody><tr><td>
		<div class="InnerTableContainer">
		<table style="width:100%;">
		<tbody>
		<tr style="text-align:center;">
		<td>Free to play</td>
		<td rowspan="3" style="vertical-align:middle;text-align:center;">
		<center>
		<form class="MediumButtonForm" action="?subtopic=createaccount" method="post">
		<div class="MediumButtonBackground" style="background-image:url('.$layout_name.'/images/buttons/mediumbutton.gif)" onmouseover="MouseOverMediumButton(this);" onmouseout="MouseOutMediumButton(this);"><div class="MediumButtonOver" style="background-image: url(&quot;'.$layout_name.'/images/buttons/mediumbutton-over.gif&quot;); visibility: hidden;" onmouseover="MouseOverMediumButton(this);" onmouseout="MouseOutMediumButton(this);"></div>
		<input class="MediumButtonText" name="Join Now" alt="Join Now" src="'.$layout_name.'/images/buttons/mediumbutton_joinnow.png" type="image">
		</div>
		</form></center></td>
		<td>Huge game world</td>
		</tr>
		<tr style="text-align:center;">
		<td>Easy access</td>
		<td>Large variety of monsters</td></tr>
		<tr style="text-align:center;">
		<td>'.$players[0].' active players</td>
		<td>Regular content updates</td></tr>
		</tbody></table></div></td></tr></tbody></table></div>';
?>