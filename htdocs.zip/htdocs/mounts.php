 <?PHP
        $main_content .= "<center><br><span style='font-size:x-large;'>Mounts FREE</span><br/>Montarias livres para todos.<br><br></center>";
        $main_content .= "<style type=\"text/css\">
        .bordafina {
        border-collapse : collapse;
        }
        </style>";

        $main_content .= "<div align=\"center\">";
          $main_content .= "<table width=\"600\" class=\"bordafina\" border=\"1\" >
                <tr>
                  <th width=\"\" bordercolor=\"#0033FF\" scope=\"col\"><div align=\"center\">Mounts</div></th>
                  <th width=\"220\" scope=\"col\"><div align=\"center\">Items Needed</div></th>
                  <th width=\"389\" scope=\"col\"><div align=\"center\">Monsters that drop</div></th>
                </tr>
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/3/36/Widow_Queen.gif\" width=\"50\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/d/df/Sweet_Smelling_Bait.gif\" width=\"32\" height=\"32\">1 Sweet Smelling Bait</div></td>
                  <td><div align=\"center\">Banshee, The Old Widow.</div></td>
                </tr>
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/1/14/Black_Sheep_%28Mount%29.gif\" width=\"32\" height=\"32\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/9/91/Reins.gif\">1 Reins</div></td>
                  <td><div align=\"center\">Dark Apprentice, Dark Magician.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/b/b5/Draptor_%28Mount%29.gif\" width=\"54\" height=\"54\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/2/25/Harness.gif\" width=\"32\" height=\"32\">1 Harness</div></td>
                  <td><div align=\"center\">Draken Spellweaver, Draken Abomination</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/1/1f/Midnight_Panther_%28Mount%29.gif\" width=\"32\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/4/44/Leather_Whip.gif\" width=\"32\" height=\"32\">1 Leather Whip</div></td>
                  <td><div align=\"center\">Vampire Bride.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/d/d1/Racing_Bird.gif\" width=\"48\" height=\"48\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/b/b7/Carrot_on_a_Stick.gif\" width=\"32\" height=\"32\">1 Carrot on a Stick</div></td>
                  <td><div align=\"center\">Carniphila e Tiquandas Revenge.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/9/9e/Rapid_Boar.gif\" width=\"32\" height=\"46\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/e/e7/Hunting_Horn.gif\">1 Hunting Horn</div></td>
                  <td><div align=\"center\">Hydra</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/c/c2/Tin_Lizzard.gif\" width=\"45\" height=\"65\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/f/fe/Tin_Key.gif\">1 Tim Key</div></td>
                  <td><div align=\"center\">War Golem.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/3/32/Titanica.gif\" width=\"56\" height=\"56\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/b/b6/Giant_Shrimp.gif\">1 Giant Shrimp</div></td>
                  <td><div align=\"center\">Quaras.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/8/86/Undead_Cavebear_%28Mount%29.gif\" width=\"54\" height=\"54\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/2/25/Maxilla_Maximus.gif\">1 Maxilla Maximus</div></td>
                  <td><div align=\"center\">Undead Dragon, Lich.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/e/e5/War_Bear.gif\" width=\"32\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/0/0b/Slingshot.gif\">1 Slingshot</div></td>
                  <td><div align=\"center\">Hunter e Poacher.</div></td>
                </tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/2/24/Donkey.gif\" width=\"50\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/4/44/Bag_of_Apple_Slices.gif\">1 Bag of Apple Slices</div></td>
                  <td><div align=\"center\">Witch</div></td>
                </tr>                
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/0/07/Kingly_Deer.gif\" width=\"60\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/8/8d/Golden_Fir_Cone.gif\">1 Golden Fir Cone</div></td>
                  <td><div align=\"center\">Frost Dragon</div></td>
                </tr>                
				 <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/4/45/Scorpion_King.gif\" width=\"40\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/e/eb/Scorpion_Sceptre.gif\">1 Scorpion Sceptre</div></td>
                  <td><div align=\"center\">Tomb Servant ,Ferumbras</div></td>
                </tr>
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/6/62/Tamed_Panda.gif\" width=\"40\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/2/24/Bamboo_Leaves.gif\">1 Bamboo Leaves</div></td>
                  <td><div align=\"center\">Draken Spellwaver</div></td>
                </tr>
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/f/f1/Inoperative_Uniwheel.gif\" width=\"35\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/e/e1/Golden_Can_of_Oil.gif\">1 Golden can of Oil</div></td>
                  <td><div align=\"center\">Golden Servant, Diamond servant</div></td>
                </tr>  
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/f/f2/Crystal_Wolf_%28Mount%29.gif\" width=\"32\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/4/43/Diapason.gif\">1 Diapason</div></td>
                  <td><div align=\"center\">Worken Golem</div></td>
                </tr>
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/8/8f/Wild_Horse.gif\" width=\"50\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/b/b4/Sugar_Oat.gif\">1 Sugar Oat</div></td>
                  <td><div align=\"center\">Dromedary</div></td>
                </tr>
                 <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/f/f4/Dromedary_%28Mount%29.gif\" width=\"50\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/5/50/Fist_on_a_Stick.gif\"> 1 Fist on a Stick</div></td>
                  <td><div align=\"center\">Tomb Servant</div></td>
                </tr> 
                 <tr>
                  <td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/7/71/Lady_Bug_%28Mount%29.gif\" width=\"30\" height=\"45\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/a/af/Four-Leaf_Clover.gif\"> 1 Four-Leaf Clover</div></td>
                  <td><div align=\"center\">Ao usar um Gooey Mass</div></td>
                </tr> 
                 <tr>
                  <td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/2/22/Manta_Ray_%28Mount%29.gif\" width=\"55\" height=\"55\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/1/16/Foxtail.gif\"> 1 Foxtail</div></td>
                  <td><div align=\"center\">Deepling Guard e Deepling Tyrant</div></td>
                </tr> 

				</table></div><center><br><span style='font-size:x-large;'>Mounts VIP</span><br>Montarias exclusivas para quem possui um Mount Doll.<br><br></center>
		    </style>";
        $main_content .= "<div align=\"center\">";
          $main_content .= "<table width=\"600\" class=\"bordafina\" border=\"1\" >
                <tr>
                  <th width=\"\" bordercolor=\"#0033FF\" scope=\"col\"><div align=\"center\">Mounts</div></th>
                  <th width=\"220\" scope=\"col\"><div align=\"center\">Items Needed</div></th>
                  <th width=\"389\" scope=\"col\"><div align=\"center\">Monsters that drop</div></th>
				<tr>
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/6/68/Iron_Blight_%28Mount%29.gif\" width=\"64\" height=\"64\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount iron blight</div></td>
                </tr> 
                 <tr>
                  <td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/2/26/Magma_Crawler_%28Mount%29.gif\" width=\"64\" height=\"64\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount magma crawler</div></td>
                </tr> 
				<tr>
                  <td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/d/d6/Water_Buffalo_%28Mount%29.gif\" width=\"64\" height=\"64\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount water buffalo</div></td>
                </tr>
				<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/a/a0/Stampor_%28Mount%29.gif\" width=\"44\" height=\"44\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount stampor</div></td>
                </tr>
                  <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/e/ea/Blazebringer.gif\" width=\"40\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount blazebringer</div></td>
                </tr>
				           <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/4/4e/Shadow_Draptor.gif\" width=\"55\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount shadow draptor</div></td>
                </tr>
							<tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/c/cc/Tiger_Slug.gif\" width=\"40\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount tiger slug</div></td>
                </tr>

				           <tr>
                  <td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/3/36/Widow_Queen.gif\" width=\"55\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount widow queen</div></td>
                </tr>
				           <tr>
                  <td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/b/be/Steelbeak.gif\" width=\"55\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
                  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount steelbeak</div></td>
                </tr>
				                 <tr>
                  <td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/c/cd/Gnarlhound_%28Mount%29.gif\" width=\"64\" height=\"64\"></div></td>
				  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
				  <td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount gnarlhound</div></td>
                </tr> 
					<tr>
					<td><div align=\"center\"><img src=\"http://tibiawiki.com.br/images/5/51/Dragonling_%28Mount%29.gif\" width=\"64\" height=\"64\"></div></td>
					<td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/5/5c/Draken_Doll.gif\" width=\"32\" height=\"32\"> 1 Mount Doll</div></td>
					<td><div align=\"center\"><b><a href=\"/?subtopic=shopsystem\">Shopping</a></b><br>!mount dragonling</div></td>
                </tr> 
                </tr>
          </table>";
        $main_content .= "</div>";
        ?>