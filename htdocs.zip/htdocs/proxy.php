<?php header("Content-Type: text/html; charset=ISO-8859-1", true); 
$main_content .= ' 
<center><img src="http://i.imgur.com/cAobgiS.png"><br><i>Proxy Tunneling</i></center>
<br>
		<table cellpadding="4" cellspacing="1" width="98%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>O que � o Direct IP - Proxy Tunneling?</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td><font color="red"><b><center>O Direct IP � um software que diminui o lag em seus jogos online em at� 70%!</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
				<td>
				O Direct IP usa uma basicamente uma tecnologia chamada "tunnelling" com essa tecnologia, pode-se criar uma conex�o entre dois computadores, intermediada por um servidor remoto, fornecendo a capacidade de redirecionar pacotes de dados.<br><br>
				Em outras palavras a Direct IP faz com que o pacote de informa��o que sai do seu computador em dire��o ao servidor do seu jogo favorito passe pelo m�nimo poss�vel de roteadores permitindo assim uma melhor lat�ncia.<br><br>
				E para facilitar ao jogador, o usu�rio do Direct IP n�o precisa baixar e instalar v�rios programas e quebrar a cabe�a lendo tutoriais. Est� a disposi��o desse usu�rio um software f�cil com uma interface amig�vel que ajuda a tornar a experi�ncia de de jogar o seu jogo online favorito em algo muito mais prazeroso.<br>
				<ul><li><a href="https://mega.co.nz/#!UtBUjKJZ!rlaz3PBpFQIZwEjdw3SSpmSLJ-vZDe6RttcJ4eeEZ4Q">DOWNLOAD DIRECT IP - PROXY TUNNELING</a></li>
				<li><a href="http://www.microsoft.com/en-us/download/details.aspx?id=17718">.NET FRAMEWORK 4.0 DOWNLOAD</a></li>
				</ul>
				</td>
			</tr>
		</table>
<center><b><h3>Video tutorial:<h3></b><iframe width="530" height="360" src="http://www.youtube.com/embed/IUFWzTn3i5E" frameborder="0" allowfullscreen></iframe></center>
<br> 
';
?>