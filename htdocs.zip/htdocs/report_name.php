<?php
if (!$logged){include("login.php"); $link = "index.php?subtopic=characters";}
if ($logged)
if ($action == ""){
$main_content .='
<script type="text/javascript">var Reasons = new Array(); Reasons[""] = "";Reasons["insulting"] = "Names can be reported if they contain very rude and offensive vocabulary or have been created to insult other character names.<br /><br />Examples:<br />Illegal - You can report names like:<br />Stupid Retard, Katie the Moron, Dickhead<br /><br />Legal - Names like the following are legal and must not be reported:<br />Noob, Crazy Guy, Silly Gerta, Charlie the fool";Reasons["racist"] = "Names can be reported if they reflect prejudice or hatred against people from other races or other countries.<br /><br />Examples:<br />Illegal - You can report names like:<br />Jew hater, White Power, Niggerkiller, Stupid Polak<br /><br />Legal - Names like the following are legal and must not be reported:<br />Polish warrior, Tiago de Brasilia, Black Fighter";Reasons["sexually_related"] = "Names can be reported if they refer to sex, a sexual orientation or intimate body parts.<br />Also names of well-known prostitutes or porn stars may be reported.<br /><br />Examples:<br />Illegal - You can report names like:<br />Sixty-nine, Hetero Guy, Nipple, Breastfeeder<br /><br />Legal - Names like the following are legal and must not be reported:<br />Sweet Kiss, Macho, Long Legs";Reasons["drug_related"] = "Names can be reported if they explicitly relate to drugs and other illegal substances or to well-known drug dealers.<br />The same is true for names that refer to alcoholism.<br /><br />Examples:<br />Illegal - You can report names like:<br />Junkie, Weedsmoker, Pablo Escobar, Alcoholic<br /><br />Legal - Names like the following are legal and must not be reported:<br />Water pipe, Tobacco Man, Rum bottle, Drunk Dwarf";Reasons["harassing"] = "Names can be reported if they have been made to harass other players or to threaten other players in real life.<br /><br />Examples:<br />Illegal - You can report names like:<br />Ikillyou Reallife, Wheelchair Marcin<br /><br />Legal - Names like the following are legal and must not be reported:<br />Tomurka\'s friend, Bubble Two";Reasons["objectionable"] = "Names can be reported if they are distasteful and likely to offend people, e.g. references to body fluids, excrements, serious diseases or organised crime, also names of contemporary persons known for serious crimes or inhuman actions.<br /><br />Examples:<br />Illegal - You can report names like:<br />Snot, Moe the Mongolist, Mafia Hitman, Hitler<br /><br />Legal - Names like the following are legal and must not be reported:<br />Vial of Blood, Blind beggar, Genghis Khan";Reasons["parts_of_sentence"] = "Names can be reported if they are sentences, recognisable parts of a sentence or if they contain exclamations or greetings.<br /><br />Examples:<br />Illegal - You can report names like:<br />John rox, Knight likes to, Oh my god, Hello<br /><br />Legal - Names like the following are legal and must not be reported:<br />Pretty girl, Flowers with thorns, Sesux, Fly";Reasons["badly_formatted"] = "Names can be reported if they lack several spaces or have several weirdly placed spaces.<br /><br />Examples:<br />Illegal - You can report names like:<br />Mikethebigknight, Miketh ebigk night<br /><br />Legal - Names like the following are legal and must not be reported:<br />Mike the bigknight, Alba tross";Reasons["nonsensical"] = "Names can be reported if they contain more than 2 spelling mistakes, use the same string of letters more than twice in a row, or contain an unpronounceable string of letters.<br /><br />Examples:<br />Illegal - You can report names like:<br />Masster Drruuidd, Bababa, Jasdhschf, Mr Robinson<br /><br />Legal - Names like the following are legal and must not be reported<br />Maaster Druidd, Babajaba, Jasdoh Sachif, Prof Robinson";Reasons["third_party"] = "Names can be reported if they contain advertising for worldwide known products, services or companies including titles of other online games.<br /><br />Examples:<br />Illegal - You can report names like:<br />Nike Shoes, Siemens, Frank Google, World of Warcraft<br /><br />Legal - Names like the following are legal and must not be reported:<br />Goddess Nike, Jennifer Lopez, Harry Potter, Real Madrid";Reasons["unrelated"] = "Names can be reported if they contain advertising for content which is not related to the game.<br /><br />Examples:<br />Illegal - You can report names like:<br />Mobile Sale, Buy headset, Sell My Car<br /><br />Legal - Names like the following are legal and must not be reported:<br />Merchant, Potionbuyer";Reasons["trade"] = "Names can be reported if they contain advertising that imply the selling or buying of Tibia items for real life money.<br /><br />Examples:<br />Illegal - You can report names like:<br />Premium Seller, Goldseller<br /><br />Legal - Names like the following are legal and must not be reported:<br />Trader Frank, Goldcoin Collector";Reasons["religious_political"] = "Names can be reported if they refer to a specific religion or to a person or position that is connected to a certain religion. The same is true for names that express political views or refer to contemporary and well-known politicians.<br /><br />Examples:<br />Illegal - You can report names like:<br />Hindu Master, Jesus Christ, Pope Frank, Anarchist, Lula da Silva<br /><br />Legal - Names like the following are legal and must not be reported:<br />Jesus Gonzales, Elfish Priest, God of War, Satan, Abraham Lincoln";Reasons["unfitting"] = "Names can be reported if they are completely out of place in Tibia\'s fantasy setting.<br /><br />Examples:<br />Illegal - You can report names like:<br />Spaceship commander, Remote control, Kalashnikov<br /><br />Legal - Names like the following are legal and must not be reported:<br />Soccer Player, Space observer, Red armchair, Teacher Fred";Reasons["supporting_rule_violation"] = "Names can be reported if they support a rule break, encourage others to break a Tibia Rule or announce or imply a violation of the Tibia Rules. The same is true for names that have been created to fake an official position.<br /><br />Examples:<br />Illegal - You can report names like:<br />Sellacc, Spam Sponsor, Bothater, God Durin, System Admin, Senator Kate<br /><br />Legal - Names like the following are legal and must not be reported:<br />Evil Thief, Bad Guy, Steve Johnson, God of War, Count Stephan";</script>
You are about to report a character name that violates the <a href="index.php?subtopic=tibiarules" target="_blank">Tibia Rules</a>.
<br /><br />
<form action="index.php?subtopic=report_name&name='.$name.'&action=confirmation" method="post">
<div class="TableContainer">
<div class="CaptionContainer">
<div class="CaptionInnerContainer">
<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<div class="Text">Report Character Name</div>
<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
</div>
</div><table class="Table1" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td>
<div class="InnerTableContainer">
<table style="width:100%;">
<tbody>
<tr>
<td class="LabelV">Name:</td>
<td style="width:50%;" colspan="2">'.$name.' <input type="hidden" name="name" value="'.$name.'"></td>
</tr>
<tr>
<td class="LabelV">Reason:</td>
<td style="width:50%;"><select id="reasonid_select" name="reasonid" style="width: 25em" onChange="document.getElementById(&#39;reason_description&#39;).innerHTML = Reasons[this.value];"><option value="">--- please select one ---</option><option value="insulting">insulting</option><option value="racist">racist</option><option value="sexually_related">sexually related</option><option value="drug_related">drug-related</option><option value="harassing">harassing</option><option value="objectionable">generally objectionable</option><option value="parts_of_sentence">parts of sentence</option><option value="badly_formatted">badly formatted words</option><option value="nonsensical">nonsensical combination of letters</option><option value="third_party">advertising brand, product or service of a third party</option><option value="unrelated">advertising content which is not related to the game</option><option value="trade">advertising a trade for real money</option><option value="religious_political">religious or political view</option><option value="unfitting">not fitting Tibia\'s medieval fantasy setting</option><option value="supporting_rule_violation">supporting rule violation</option></select>
</td>
<td>Please select the <a href="index.php?subtopic=tibiarules" target="_blank">Tibia Rule</a> which is violated by the name</td>
</tr>
<tr>
<td class="LabelV"></td>
<td style="width:50%;"> <div id="reason_description" style="width: 25em; text-align: justify"></div></td>
<td>
</td>
</tr>
<tr>
<td class="LabelV">Translation:</td><td style="width:50%;">
<textarea id="translation_input" name="translation" style="width: 25em" rows="4"></textarea>
</td>
<td>Please give a translation if the name is not in English</td>
</tr>
<tr>
<td class="LabelV">Comment:</td>
<td style="width:50%;"> <textarea id="comment_input" name="comment" style="width: 25em" rows="4"></textarea>
</td>
<td>Please explain why you think this name violates the <a href="index.php?subtopic=tibiarules" target="_blank">Tibia Rules</a></td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</div>
<br />
<table style="width:100%;">
<tbody>
<tr align="center">
<td>
<table border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="border:0px;">
<div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
<input class="ButtonText" type="image" name="Submit" alt="Submit" src="'.$layout_name.'/images/buttons/_sbutton_submit.gif">
</div>
</div>
</td>
</tr>
<tr>
</tr>
</tbody>
</table>
</td>
<td>
</form>
<form style="margin: 0px;padding:0px;" method="post" action="index.php?subtopic=characters">
<div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url('.$layout_name.'/images/buttons/sbutton_over.gif); visibility: hidden;">
</div>
<input class="ButtonText" type="image" name="Back" alt="Back" src="'.$layout_name.'/images/buttons/_sbutton_back.gif">
</div>
</div>
</form>
</td>
</tr>
</tbody>
</table>
';}
if ($action == "confirmation"){
$main_content .='
<form action="index.php?subtopic=report_name&name='.$name.'&comment='.$comment.'&reasonid='.$reasonid.'&action=send" method="post">
<div class="TableContainer">
<div class="CaptionContainer">
<div class="CaptionInnerContainer">
<span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
<span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<div class="Text">Confirmation Report</div>
<span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);"></span>
<span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
</div>
</div><table class="Table1" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td>
<div class="InnerTableContainer">
<table style="width:100%;">
<tbody>
<tr>
<td class="LabelV">Name:</td>
<td style="width:50%;" colspan="2">'.$name.' <input type="hidden" name="name" value="'.$name.'"></td>
</tr>
<tr>
<td class="LabelV">Reason:</td>
<td style="width:50%;">
'.$reasonid.'
</td>
<td width="30%">&nbsp;</td>
</tr>
<tr>
<td class="LabelV"></td>
<td style="width:50%;"></td>
<td>
</td>
</tr>
<tr>
<td class="LabelV">Translation:</td><td style="width:50%;">
'.$translation.'
</td>
</tr>
<tr>
<td class="LabelV">Comment:</td>
<td style="width:50%;"> '.$comment.'
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</div>
<br />
<table style="width:100%;">
<tbody>
<tr align="center">
<td>
<table border="0" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="border:0px;">
<div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
<input class="ButtonText" type="image" name="Submit" alt="Submit" src="'.$layout_name.'/images/buttons/_sbutton_submit.gif">
</div>
</div>
</td>
</tr>
<tr>
</tr>
</tbody>
</table>
</td>
<td>
</form>
<form style="margin: 0px;padding:0px;" method="post" action="index.php?subtopic=characters">
<div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url('.$layout_name.'/images/buttons/sbutton_over.gif); visibility: hidden;">
</div>
<input class="ButtonText" type="image" name="Back" alt="Back" src="'.$layout_name.'/images/buttons/_sbutton_back.gif">
</div>
</div>
</form>
</td>
</tr>
</tbody>
</table>
';
}
if ($action == "send"){
$SQL->query("OPTIMIZE TABLE  `reports`");
$SQL->query("INSERT INTO `reports` (`id` ,`player_id` ,`date` ,`reason` ,`description`) VALUES (NULL,  '".$name."',  '".time()."',  '".$reasonid."', '".$comment."');");
$main_content .='
<div class="TableContainer">
<div class="CaptionContainer">
<div class="CaptionInnerContainer">
<span class="CaptionEdgeLeftTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionBorderTop" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionVerticalLeft" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span> 
<div class="Text">Reported Successfully</div> 
<span class="CaptionVerticalRight" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<span class="CaptionBorderBottom" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionEdgeLeftBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
</div>
</div>
<table class="Table1" cellpadding="0" cellspacing="0"> 
 <tbody><tr>
<td>
<div class="InnerTableContainer"> 
<table style="width: 100%;">
<tbody>
<tr>
<td>
'.$name.' has been reported for reason '.$reasonid.'.<br />
Aguarde 24horas para analisarmos o caso.
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</div>
<br />
<center>
<table border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="border: 0px none;">
<div class="BigButton" style="background-image: url('.$layout_name.'/images/buttons/sbutton.gif);">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
<form action="?subtopic=latestnews" method="post">
<input class="ButtonText" name="Back" alt="Back" src="'.$layout_name.'/images/vips/_sbutton_back.gif" type="image">
</form>
</div>
</div>
</td>
</tr>
</tbody>
</table>
</center>
';
}
?>