<?php
if ($logged){
if ($action == ""){
$_REQUEST['guild_name'];
$_REQUEST['guild_logo'];
$_REQUEST['description'];
$_REQUEST['player_id'];
$query_exibe = $SQL->query("SELECT * FROM `guilds` WHERE 1");
foreach($query_exibe as $row)
if($_REQUEST['name'] == $row['name']){
$main_content .='
<form action="index.php?subtopic=reportguild&action=agreement" method="post">
<input type="hidden" name="player_id" value="'.$account_logged->getID().'" />
Wich guild information would you like to report?<br><br>
<div class="TableContainer">
<div class="CaptionContainer">
<div class="CaptionInnerContainer">
<span class="CaptionEdgeLeftTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionBorderTop" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionVerticalLeft" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span> 
<div class="Text">Select Guild Information</div> 
<span class="CaptionVerticalRight" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<span class="CaptionBorderBottom" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionEdgeLeftBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
</div>
</div>
<table class="Table1" cellpadding="0" cellspacing="0"> 
<tbody><tr>
<td>
<div class="InnerTableContainer"> 
<table style="width: 100%;">
<tbody>
<tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="21%"><input name="report_type" type="radio" value="Name - '.$guild_name.'" />
    <strong>Name:</strong></td>
    <td width="79%">'.$row['name'].'</td>
  </tr>
  <tr>
    <td valign="top"><input name="report_type" type="radio" value="Logo - '.$guild_logo.'" />
    <strong>Logo:</strong></td>
    <td><img src="guilds/'.$guild_logo.'" width="120" height="120" />'; $guild_logo = $row['logo_gfx_name'];
foreach (array("/", "\\", "..") as $char) {
$guild_logo = str_replace($char, "", $row['logo_gfx_name']);
}
if (empty($guild_logo) || !file_exists("guilds/".$guild_logo)) {
$guild_logo = "default_logo.gif";
} 
$main_content .='</td>
 </tr>
  <tr>
    <td><input name="report_type" type="radio" value="Description - '.$description.'" />
    <strong>Description:</strong></td>
    <td>'.$description.'</td>
  </tr>
  <tr>
    <td><strong>Description<br /> a report types:</strong></td>
    <td><textarea name="description" cols="50" rows="10" id="description"></textarea></td>
  </tr>
</table>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</div>
<br />
<center>
<table width="100%">
<tbody>
<tr align="center">
<td>
<table border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td style="border: 0px none;">
<a href="javascript:void();">
<div class="BigButton" style="background-image: url('.$layout_name.'/images/buttons/sbutton.gif);">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
<input class="ButtonText" name="Continue" alt="Continue" src="'.$layout_name.'/images/vips/_sbutton_continue.gif" type="image">
</div>
</div>
</a>
</td>
</tr>
<tr>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</center>
</form>';}
}

if ($action == "agreement"){
$_POST['guild_name'];
$_POST['guild_logo'];
$_POST['description'];
$_POST['player_id'];

$SQL->query("OPTIMIZE TABLE  `reports`");
$SQL->query("INSERT INTO `reports` (`id` ,`player_id` ,`date` ,`reason` ,`description`) VALUES (NULL,  '".$_POST['player_id']."',  '".time()."',  '".$_POST['report_type']."', '".$description."');");
$main_content .='
<div class="TableContainer">
<div class="CaptionContainer">
<div class="CaptionInnerContainer">
<span class="CaptionEdgeLeftTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionBorderTop" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionVerticalLeft" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span> 
<div class="Text">Reported Successfully</div> 
<span class="CaptionVerticalRight" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<span class="CaptionBorderBottom" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionEdgeLeftBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
</div>
</div>
<table class="Table1" cellpadding="0" cellspacing="0"> 
 <tbody><tr>
<td>
<div class="InnerTableContainer"> 
<table style="width: 100%;">
<tbody>
<tr>
<td>
Voc� reportou a guild pelo motivo do <b>'.$_POST['report_type'].'</b> estar inadequado com as regras vigentes no servidor. Agradecemos seu relato, ser� feito uma an�lize especifica na mesma.
<br />
<br />
<b style="color:red;">Caso haja abuso da ferramenta, ser� punida a account que expediu o relato.</b>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</div>
<br />
<center>
<table border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="border: 0px none;">
<div class="BigButton" style="background-image: url('.$layout_name.'/images/buttons/sbutton.gif);">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
<form action="?subtopic=guilds" method="post">
<input class="ButtonText" name="Back" alt="Back" src="'.$layout_name.'/images/vips/_sbutton_back.gif" type="image">
</form>
</div>
</div>
</td>
</tr>
</tbody>
</table>
</center>
';
}
}else{
$link = "index.php?subtopic=guilds";
include("login.php");
}
?>