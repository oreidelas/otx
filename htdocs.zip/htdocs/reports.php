<?php
if($group_id_of_acc_logged >= $config['site']['access_admin_panel']) {
if ($logged){
if ($action == ""){
$query_exibe = $SQL->query("SELECT * FROM `reports`");
$main_content .='
<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="5" WIDTH="100%">
<tr BGCOLOR="'.$config['site']['vdarkborder'].'" >
<td CLASS="white" colspan="4"><b>Reports Table</b></td>
</tr>
<tr bgcolor="'.$config['site']['darkborder'].'">
<td><b>#ID</b></td>
<td><b>Reason Report:</b></td>
<td><b>Player Name:</b></td>
<td><b>Comment:</b></td>
</tr>';
foreach($query_exibe as $row){
if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .='
<tr BGCOLOR='.$bgcolor.'>
<td><b style="color:green;">#'.$row['id'].'</b>&#160;[<a href="index.php?subtopic=reports&action=delete&id='.$row['id'].'">Excluir</a>]</td>
<td>'.$row['reason'].'</td>
<td>'.$row['player_id'].'</td>
<td>'.$row['description'].'</td>
</tr>';}
if (!$row['id']){
if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
$main_content .='
<tr BGCOLOR='.$config['site']['lightborder'].'>
<td align="center" colspan="4"><i>Nenhum report relatado.</i></td>
</tr>
';}
$main_content .='
</TABLE>
';}}
if ($action == "delete"){
$SQL->query("DELETE FROM `reports` WHERE `reports`.`id` = ".$id."");
$SQL->query("OPTIMIZE TABLE  `reports`");
$main_content .='<div align="center">Report deletado com sucesso!</div>
<meta charset="iso-8859-8" http-equiv="refresh" content="1;index.php?subtopic=reports" />';
} /* Logged */
} /* Access Page */
if (!$logged){
include ("login.php");
$link = "index.php?subtopic=reports";
}
?>