<?php
if (!$logged){include("login.php"); $link = 'index.php?subtopic=sendbug';}
if ($logged)
if ($action == ""){
$main_content .='
<script type="text/javascript">
var Reasons = new Array();
Reasons[""] = "";
Reasons["map"] = "Reletar bugs no mapa, exemplos:<br />R�plicar Items, Bugar Servidor fazendo o mesmo cair e etc.<br /><br />";
Reasons["server"] = "Reletar bugs no server, exemplos:<br />Fazer servidor cair, invas�o de servidor por meio de bugs no distro, etc.<br /><br />";
Reasons["site"] = "Reletar bugs no site, exemplos:<br />Invadir o banco de dados, invas�o por meio de Inje��es SQL, etc.<br /><br />";

var Prioridade = new Array();
Prioridade[""] = "";
Prioridade["baixa"] = "";
Prioridade["normal"] = "";
Prioridade["emergencial"] = "<b style=\'color: red;\'>Prioridade emergencial</b>, este relato pode levar voce a receber alguns premios de colabora��o com o servidor, isto seja, se o bug for verdadeiro.<br /><br />";
</script>
Reporte erros no servidor/site utilizando esta ferramenta.<br /><br />
<div class="TableContainer">
<div class="CaptionContainer">
<div class="CaptionInnerContainer">
<span class="CaptionEdgeLeftTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightTop" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span>
<span class="CaptionBorderTop" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionVerticalLeft" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span> 
<div class="Text">Reportar bug</div> 
<span class="CaptionVerticalRight" style="background-image: url('.$layout_name.'/images/content/box-frame-vertical.gif);"></span>
<span class="CaptionBorderBottom" style="background-image: url('.$layout_name.'/images/content/table-headline-border.gif);"></span> 
<span class="CaptionEdgeLeftBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
<span class="CaptionEdgeRightBottom" style="background-image: url('.$layout_name.'/images/content/box-frame-edge.gif);"></span> 
</div>
</div>
<table class="Table1" cellpadding="0" cellspacing="0"> 
<tbody><tr>
<td>
<div class="InnerTableContainer"> 
<table style="width: 100%;">
<tbody>
<tr>
<td>

<form action="?subtopic=sendbug&action=send" method="post">
<input type="hidden" name="player_id" value="'.$account_logged->getID().'" />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><strong>Location:</strong></td>
    <td>
	<select id="location_select" name="location" style="width: 25em" onChange="document.getElementById(&#39;reason_description&#39;).innerHTML = Reasons[this.value];">
	<option value="">--- please select one reason ---</option>
    <option value="map">Map</option>
	<option value="site">Site</option>
	<option value="server">Server</option>
	</select>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div id="reason_description" style="width: 25em; text-align: justify"></div></td>
  </tr>
  <tr>
    <td><strong>Prioridade:</strong></td>
    <td>
	<select id="prioridade_select" name="prioridade" style="width: 25em" onChange="document.getElementById(&#39;prioridade_desc&#39;).innerHTML = Prioridade[this.value];">
      <option value="" selected="selected">--- please select one priority ---</option>
      <option value="baixa">Baixa</option>
      <option value="normal">Normal</option>
      <option value="emergencial">Emergencial</option>
    </select></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div id="prioridade_desc" style="width: 25em; text-align: justify"></div></td>
  </tr>
  <tr>
    <td><strong>Descri��o:</strong></td>
    <td><textarea name="description" cols="39" rows="10"></textarea></td>
  </tr>
</table>



</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</div>
<br />
<center>
<table border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="border: 0px none;">
<div class="BigButton" style="background-image: url('.$layout_name.'/images/buttons/sbutton.gif);">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
<input class="ButtonText" name="Continue" alt="Continue" src="'.$layout_name.'/images/buttons/_sbutton_continue.gif" type="image">
</form>
</div>
</div>
</td>
</tr>
</tbody>
</table>
</center>
';
}
if ($action == "send"){
	$reason = $_POST['location'];
	$description = $_POST['description'];
	$location = $_POST['location'];
	$player_id = $_POST['player_id'];
	$prioridade = $_POST['prioridade'];
	$date = time();
	$SQL->query("INSERT INTO `reports` (`id`, `player_id`, `date`, `reason`, `description`) VALUES (NULL, '$player_id', '$date', '$reason', '$description, $prioridade');");
$main_content .='
<TABLE BORDER="0" CELLSPACING="1" CELLPADDING="5" WIDTH="100%">
<tr BGCOLOR="'.$config['site']['vdarkborder'].'">
<td CLASS="white"><b>Report send successfully!</b></td>
</tr>
<tr BGCOLOR='.$config['site']['darkborder'].'>
<td>Relato enviado com sucesso, agradecemos pela colabora��o!</td>
</tr>
</TABLE>
<br />
<center>
<table border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="border: 0px none;">
<form action="index.php?subtopic=latestnews" method="post">
<div class="BigButton" style="background-image: url('.$layout_name.'/images/buttons/sbutton.gif);">
<div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div>
<input class="ButtonText" name="Back" alt="Back" src="'.$layout_name.'/images/buttons/_sbutton_back.gif" type="image">
</form>
</div>
</div>
</td>
</tr>
</tbody>
</table>
</center>';
}
?>