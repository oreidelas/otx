<?PHP
if($config['site']['serverinfo_page'])
{
	$stages = simplexml_load_file($config['site']['server_path'].'/data/XML/stages.xml');
	$servers = simplexml_load_file($config['site']['server_path'].'/data/XML/servers.xml');
	$main_content .= '<center><center>
		<table border="0" cellpadding="4" cellspacing="1" width="99%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Status</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td width="50%"><font class="white"><b>Name</b></font></td><td><font class="white"><b>Value</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>Server Status:</td><td>'.(($config['status']['serverStatus_online'] == 1) ? '<b>Online</b>' : '<b>Offline</b>').'</td>
			</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
				<td>Dedicated</td><td>Hosted in EUA</td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>IP Connection</td><td>go.darkglobal.com</td>
			</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
				<td>Version</td><td>8.60 (<a href="?subtopic=downloads" target="_blank">download client here</a>)</td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>Port</td><td>7171</td>
			</tr>
		</table>
		<br>';
	if($config['server']['experienceStages'] == false)
        $rateExperience .= $config['server']['rateExperience'].'x';
    else
	{
        $rateExperience .= '<table width="100%">';
        foreach($stages as $exp1)
        {
			$i = 0;
			$ots = (int) $exp1["id"];
			if($ots > 0)
				$rateExperience .= '<tr align="center" bgcolor="'.$config['site']['vdarkborder'].'"><td colspan="3"><strong>Experience Stages on '.$config['site']['worlds'][$ots].'</strong></td></tr>';
			$rateExperience .= '<tr align="center" bgcolor="'.$config['site']['vdarkborder'].'"><td class="white">From Level</td><td class="white">To Level</td><td class="white">Rate</td></tr>';
			foreach($exp1 as $exp)
            {
				if(isset($exp["maxlevel"]))
					$max = $exp["maxlevel"];
				else
					$max = "-";
				if(is_int($i/2))
					$bgcolor=$config['site']['lightborder'];
				else
					$bgcolor=$config['site']['darkborder'];
				$rateExperience .= '<tr align="center" bgcolor="'.$bgcolor.'"><td>'.$exp["minlevel"].'</td><td>'.$max.'</td><td>'.$exp["multiplier"].'x</td></tr>';
				$i++;
			}
        }
        $rateExperience .= '</table>';
	}
	$main_content .= '<table border="0" cellpadding="4" cellspacing="1" width="99%">
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td colspan="2"><font class="white"><b>Rates</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['vdarkborder'].'">
				<td><font class="white"><b>Name</b></font></td><td><font class="white"><b>Value</b></font></td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td width="50%">Experience</td><td>'.$rateExperience.'</td>
			</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
				<td>Skill</td><td>'.$config['server']['rateSkill'].'x</td>
			</tr>
			<tr bgcolor="'.$config['site']['darkborder'].'">
				<td>Magic</td><td>'.$config['server']['rateMagic'].'x</td>
			</tr>
			<tr bgcolor="'.$config['site']['lightborder'].'">
				<td>Loot</td><td>'.$config['server']['rateLoot'].'x</td>
			</tr>
		</table><br>';
	foreach($servers as $server)
	{
		$v1 = $server['versionMin'];
		$v2 = $server['versionMax'];
		if($v1 == $v2) 
        {
            $version = str_split($v1); 
            $version = $version[0].'.'.$version[1].$version[2];
        }
		else
        {
            $v1 = str_split($v1); 
            $v2 = str_split($v2); 
            $version = $v1[0].'.'.$v1[1].$v1[2].'~'.$v2[0].'.'.$v2[1].$v2[2]; 
        }
	}
	///Queries ///
		$query = $SQL->query('SELECT `name`, `id`, `level`, `experience` FROM `players` WHERE players.group_id < '.$config['site']['players_group_id_block'].' AND account_id != 1 ORDER BY `level` DESC, `experience` DESC LIMIT 1;')->fetch();
		$query2 = $SQL->query('SELECT `id`, `name` FROM `players` ORDER BY `id` DESC LIMIT 1;')->fetch();
		$housesfree = $SQL->query('SELECT COUNT(*) FROM `houses` WHERE `owner`=0;')->fetch();
		$housesrented = $SQL->query('SELECT COUNT(*) FROM `houses` WHERE `owner`=1;')->fetch();
		$banned = $SQL->query('SELECT COUNT(*) FROM `bans` WHERE `id`>0;')->fetch();
		$accounts = $SQL->query('SELECT COUNT(*) FROM `accounts` WHERE `id`>0;')->fetch();
		$players = $SQL->query('SELECT COUNT(*) FROM `players` WHERE `id`>0;')->fetch();
		$guilds = $SQL->query('SELECT COUNT(*) FROM `guilds` WHERE `id`>0;')->fetch();
	///End Queries ///
	$main_content .= '<table border="0" cellpadding="4" cellspacing="1" width="99%">
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td colspan="2"><font class="white"><b>Info Server</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td width="50%"><font class="white"><b>Name</b></font></td><td><font class="white"><b>Value</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>World Type</td><td>';
			$w=strtolower($config['server']['worldType']);
if(in_array($w, array('pvp','2','normal','open','openpvp')))
	$main_content .= 'Open PvP';
elseif(in_array($w, array('no-pvp','nopvp','non-pvp','nonpvp','1','safe','optional','optionalpvp')))
	$main_content .= 'Optional PvP';
elseif(in_array($w, array('pvp-enforced','pvpenforced','pvp-enfo','pvpenfo','pvpe','enforced','enfo','3','war','hardcore','hardcorepvp')))
	$main_content .= 'Hardcore PvP';
			$main_content .='</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Server motd</td><td>'.$config['server']['motd'].'</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Last joined</td><td><a href="?subtopic=characters&name='.urlencode($query2['name']).'">'.$query2['name'].'</a></td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Best Level</td><td><a href="index.php?subtopic=characters&name='.urlencode($query['name']).'">'.$query['name'].'</a> (<b>Level&nbsp;'.$query['level'].'</b>)</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Global Server Save:</td><td>06:00 AM</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Server Save:</td><td>30 in 30 minutes.</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Clean Map:</td><td>6 in 6 hours.</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Presentes (b�nus):</td><td>Voc� ganha 2 dias de VIP ao criar sua account.<br>Ao chegar no level 20 voc� ganha +20 leveis!<br>At� o level 50 n�o se perde loot ao morrer.<br>No level 25 voc� ganha 30.000 golds (30k).<br>No level 100 voc� ganha 50.000 golds (50k).<br>No level 150 voc� ganha 100.000 golds (100k).<br>No level 230 voc� ganha um Addon Doll.<br>No level 310 voc� ganha 300.000 golds (300k).<br>No level 400 voc� ganha 400.000 golds (400k).<br>No level 450 voc� ganha 500.000 golds (500k).<br></td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Comandos:</td><td>!online - !frags - !uptime - !serveinfo - !save - !buybless - !aol - !changesex - !soft - !firewalker - !buyhouse - !sellhouse - !leavehouse</td>
		</tr>
	</table><br>';
    
	$whiteSkullTime = explode("*", $config['server']['whiteSkullTime']);
	$whiteSkullTime = $whiteSkullTime[0].(count($whiteSkullTime) == 3 ? ' minutes' : ' seconds'); 
	# Info for Red Skull
	$redSkullLength = explode("*", $config['server']['redSkullLength']);
    $redSkullLength = $redSkullLength[0].(count($redSkullLength) == 4 ? ' days' : ' hours'); 
	$fragsToRedSkull = 'Daily: '.$config['server']['fragsToRedSkull'].' | Weekly: '.$config['server']['fragsSecondToRedSkull'].' | Monthly: '.$config['server']['fragsThirdToRedSkull'];
	# Info for Ban
	$killsBanLength = explode("*", $config['server']['killsBanLength']);
    $killsBanLength = $killsBanLength[0].(count($killsBanLength) == 4 ? ' days' : ' hours'); 
    $kill_daily = is_numeric($config['server']['dailyFragsToBanishment']) ? $config['server']['dailyFragsToBanishment'] : $config['server']['fragsToRedSkull'];
    $kill_weekly = is_numeric($config['server']['weeklyFragsToBanishment']) ? $config['server']['weeklyFragsToBanishment'] : $config['server']['fragsSecondToRedSkull'];
    $kill_monthly = is_numeric($config['server']['monthlyFragsToBanishment']) ? $config['server']['monthlyFragsToBanishment'] : $config['server']['fragsThirdToRedSkull'];
	$fragsToBanishment = 'Daily: '.$kill_daily.' | Weekly: '.$kill_weekly.' | Monthly: '.$kill_monthly;
	# Info for Black Skull
	if($config['server']['useBlackSkull'] == true)
	{
		$blackSkullLength = explode("*", $config['server']['blackSkullLength']);
		$blackSkullLength = $blackSkullLength[0].(count($blackSkullLength) == 4 ? ' days' : ' hours'); 
		$black_daily = is_numeric($config['server']['fragsToBlackSkull']) ? $config['server']['fragsToBlackSkull'] : $config['server']['fragsToRedSkull'];
		$black_weekly = is_numeric($config['server']['fragsSecondToBlackSkull']) ? $config['server']['fragsSecondToBlackSkull'] : $config['server']['fragsSecondToRedSkull'];
		$black_monthly = is_numeric($config['server']['fragsThirdToBlackSkull']) ? $config['server']['fragsThirdToBlackSkull'] : $config['server']['fragsThirdToRedSkull'];
		$fragsToBlackSkull = 'Daily: '.$black_daily.' | Weekly: '.$black_weekly.' | Monthly: '.$black_monthly;
		$blackSkull = $blackSkullLength;
	}
	else
	{
		$blackSkull = "Disabled";
		$fragsToBlackSkull = "Disabled";
	}
	$main_content .= '<table border="0" cellpadding="4" cellspacing="1" width="99%">
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td colspan="2"><font class="white"><b>Frags</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td width="50%"><font class="white"><b>Name</b></font></td><td><font class="white"><b>Value</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>White Skull Time</td><td>'.$whiteSkullTime.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Red Skull Time</td><td>'.$redSkullLength.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Black Skull Time</td><td>'.$blackSkull.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Kills Ban Time</td><td>'.$killsBanLength.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Frags to Red Skull</td><td>'.$fragsToRedSkull.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Frags to Black Skull</td><td>10</td>
		</tr>
	</table><br>';
	$idleKickTime = explode("*", $config['server']['idleKickTime']);
	$idleKickTime = $idleKickTime[0].(count($idleKickTime) == 4 ? ' hours' : ' minutes');
	$pzLocked = explode("*", $config['server']['pzLocked']);
	$pzLocked = $pzLocked[0].(count($pzLocked) == 3 ? ' minuts' : ' seconds'); 
	if($config['server']['freePremium'] == true)
		$freePremium = "Free";
	else
		$freePremium = 'Not Free';
	if($config['server']['bankSystem'] == true)
		$bankSystem = "Enabled";
	else
		$bankSystem = "Disabled";
	if($config['server']['guildHalls'] == true)
		$guildHalls = "Enabled";
	else
		$guildHalls = "Disabled";
	$main_content .= '<table border="0" cellpadding="4" cellspacing="1" width="99%">
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td colspan="2"><font class="white"><b>Onther information</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['vdarkborder'].'">
			<td width="50%"><font class="white"><b>Name</b></font></td><td><font class="white"><b>Value</b></font></td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Premium</td><td>'.$freePremium.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Bank System</td><td>'.$bankSystem.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Guild halls</td><td>'.$guildHalls.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Kick Time</td><td>'.$idleKickTime.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>PZ Lock</td><td>'.$pzLocked.'</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Protection Level</td><td>'.$config['server']['protectionLevel'].'</td>
		</tr>
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td>Level to buy house</td><td>'.$config['server']['levelToBuyHouse'].'</td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td>Level to create guild</td><td>'.$config['site']['guild_need_level'].'</td>
		</tr>
		<!--
		<tr bgcolor="'.$config['site']['darkborder'].'">
			<td></td><td></td>
		</tr>
		<tr bgcolor="'.$config['site']['lightborder'].'">
			<td></td><td></td>
		</tr>
		-->
	</table><br>';
	$main_content .= '</center>';
}
else
	$main_content .= "Invalid subtopic. Can't load page.";
?>

