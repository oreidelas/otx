<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Tibia Outfit Images Generator 10.92</title>
</head>
<body>
	<span style="font-size:20px">Open <b>outfit.php</b> with valid parameters to generate STATIC image [idle]. For example:<br />
	<a href="outfit.php?id=128&addons=3&head=123&body=12&legs=23&feet=31&mount=0&direction=2">outfit.php?id=128&addons=3&head=123&body=12&legs=23&feet=31&mount=0&direction=2</a><br />
</body>
</head>