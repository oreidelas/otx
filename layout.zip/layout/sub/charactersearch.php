
	<h2>Character search</h2>
	<form type="submit" action="characterprofile.php" method="get">
	
	<table>
		<tr><th >Search Character</th></tr>
		<tr><td>
			<table style="width: auto;margin: 0;">
			
				
				<tr>
					<td><strong>Name:</strong></td><td><input size="29" type="text" name="name" class="search"></td>
					<td>
					<input type="Submit" value="" class="hover" style="background: url(layout/tibia_img/sbutton_submit.gif); width:120px;height:18px;border: 0 none;" border="0"></td>
				</tr>
				

			</table>
		</td></tr>
	</table>
	
	</form>