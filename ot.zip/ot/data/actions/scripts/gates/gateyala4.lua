function onUse(cid, item, frompos, item2, topos)
doTeleportThing(cid,{x=543, y=564, z=5})
return TRUE
end