function onUse(cid, item, frompos, item2, topos)
doTeleportThing(cid,{x=672, y=601, z=5})
return TRUE
end