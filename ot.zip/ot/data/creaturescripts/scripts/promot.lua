function onLogin(cid)
if isPremium(cid) then
doPlayerSetPromotionLevel(cid, 2)
end
return true
end
