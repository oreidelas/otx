/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef THEFORGOTTENSERVER_PRIVATE_H
#define THEFORGOTTENSERVER_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.4.0.0"
#define VER_MAJOR	0
#define VER_MINOR	4
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"OtLand.net"
#define FILE_VERSION	"0.4"
#define FILE_DESCRIPTION	"The Forgotten Server"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"The Forgotten Server.exe"
#define PRODUCT_NAME	"The Forgotten Server"
#define PRODUCT_VERSION	"0.4"

#endif /*THEFORGOTTENSERVER_PRIVATE_H*/
