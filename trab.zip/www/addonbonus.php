   <?php 
$main_content .= ' 
<style> 
.KL{background-color:none;} 
.KL:hover{background-color:white;font-weight:bold;color:black;} 
</style> 
<hr/> 
<center><b>Bonus funciona apenas com outfit full.</b></center> 
<hr/> 


<TABLE table  BGCOLOR="'.$config['site']['darkborder'].'" BORDER=0 CELLPADDING=4 CELLSPACING=1 WIDTH=100%> 
<TR BGCOLOR="'.$config['site']['vdarkborder'].'" ><TD CLASS=white COLSPAN=5><B>Outfit Bonus Table</B></TD></TR> 
<TR><TD><TABLE BORDER=0 CELLPADDING=2 CELLSPACING=1 WIDTH=100%> 
<TR BGCOLOR=#eeddb9><TD><B>Outfit</B></TD><TD><B>Bonus</B></TD></TR> 

<TR class="KL" BGCOLOR=#eeddb9><TD><center><b>Citizen</b><br> 
<img src="./images/addons/1028.gif"/>&nbsp</center><br></TD><TD>+5 speed, +100 hp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Hunter</b><br> 
<img src="./images/addons/1029.gif"/>&nbsp</center><br></TD><TD>+3 distance</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Mage</b><br> 
<img src="./images/addons/1030.gif"/>&nbsp</center><br></TD><TD>+2 magic level, +200 mp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Knight</b><br> 
<img src="./images/addons/1039.gif"/>&nbsp</center><br></TD><TD>+3 sword</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Nobleman/Noblewoman</b><br> 
<img src="./images/addons/1032.gif"/>&nbsp</center><br></TD><TD>+3 club</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Summoner</b><br> 
<img src="./images/addons/1033.gif"/>&nbsp</center><br></TD><TD>+2 magic level, +100 mp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Warrior</b><br> 
<img src="./images/addons/1034.gif"/>&nbsp</center><br></TD><TD>+3 sword</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Barbarian</b><br> 
<img src="./images/addons/1043.gif"/>&nbsp</center><br></TD><TD>+3 axe</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Druid</b><br> 
<img src="./images/addons/1044.gif"/>&nbsp</center><br></TD><TD>+2 magic level</TD></TR>
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Wizard</b><br> 
<img src="./images/addons/1045.gif"/>&nbsp</center><br></TD><TD>+1 magic level, +100 mp</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Oriental</b><br> 
<img src="./images/addons/1046.gif"/>&nbsp</center><br></TD><TD>+200 mp, +200 hp, +5 speed</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Pirate</b><br> 
<img src="./images/addons/1051.gif"/>&nbsp</center><br></TD><TD>+3 club, +100 hp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Assassin</b><br> 
<img src="./images/addons/1052.gif"/></center><br></TD><TD>+5 speed, +2 distance</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Beggar</b><br> 
<img src="./images/addons/1053.gif"/>&nbsp</center><br></TD><TD>+200 hp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Shaman</b><br> 
<img src="./images/addons/1054.gif"/>&nbsp</center><br></TD><TD>+2 magic level</TD></TR> 
<TR  class="KL"  BGCOLOR=#eeddb9><TD><center><b>Norseman/Norsewoman</b><br> 
<img src="./images/addons/1151.gif"/>&nbsp</center><br></TD><TD>+2 shielding, +200 hp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Nightmare</b><br> 
<img src="./images/addons/1168.gif"/>&nbsp</center><br></TD><TD>+3 shielding</TD></TR>
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Jester</b><br> 
<img src="./images/addons/1058.gif"/>&nbsp</center><br></TD><TD>+5 speed, +100 hp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Brotherhood</b><br> 
<img src="./images/addons/1178.gif"/>&nbsp</center><br></TD><TD>+2 magic level, +100 hp</TD></TR>
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Demonhunter</b><br> 
<img src="./images/addons/1059.gif"/></center><br></TD><TD>+10 speed, +200 hp</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Yalaharian</b><br> 
<img src="./images/addons/924.gif"/></center><br></TD><TD>+2 magic level, +5 speed</TD></TR> 
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Warmaster</b><br> 
<img src="./images/addons/1060.gif"/></center><br></TD><TD>+2 magic level, +15 speed, +100 hp</TD></TR>
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Wayfarer</b><br> 
<img src="./images/addons/1061.gif"/></center><br></TD><TD>+10 speed, +2 shield, +2 sword</TD></TR> 
</TABLE></TD></TR> 
</TABLE>'; 
?>