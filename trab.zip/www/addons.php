<?PHP
 $main_content .= '<table width="90%" border="0" cellspacing="0" align="center">
  <tr> 
   <td><div align="center"><font size="10"><b>Addons</font></div></b></b></td>
  </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Citizen</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +25 Speed.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
   </b>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/128.gif"> 
           <img src="images/addons/1028.gif"> 
           <br>
           <img src="images/addons/428.gif"> 
           <img src="images/addons/728.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/136.gif"> 
           <img src="images/addons/1036.gif"> 
           <br>
           <img src="images/addons/436.gif"> 
           <img src="images/addons/736.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Minotaur Leather</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Chicken Feather, 50 Honeycomb, 1 Legion Helmet</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Hunter</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +3 Distance.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/129.gif"> 
           <img src="images/addons/1029.gif"> 
           <br>
           <img src="images/addons/429.gif"> 
           <img src="images/addons/729.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/137.gif"> 
           <img src="images/addons/1037.gif"> 
           <br>
           <img src="images/addons/437.gif"> 
           <img src="images/addons/737.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Elanes Crossbow, 100 Lizard Leather, 100 Red Dragon Leather, 5 Enchanted Chicken Wing, 1 Piece of Royal Steel, 1 Piece of Hell Steel, 1 Piece of Draconian Steel</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Sniper Gloves</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Knight</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +3 Skils , Sword, CLub and Axe.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/131.gif"> 
           <img src="images/addons/1031.gif"> 
           <br>
           <img src="images/addons/431.gif"> 
           <img src="images/addons/731.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/139.gif"> 
           <img src="images/addons/1039.gif"> 
           <br>
           <img src="images/addons/439.gif"> 
           <img src="images/addons/739.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Huge Chunk of Crude Iron, 100 Iron Ore</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Perfect Behemoth Fang, 1 Damaged Steel Helmet, 1 Warriors Sweat, 1 Piece of Royal Steel</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Mage</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +5 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/130.gif"> 
           <img src="images/addons/1030.gif"> 
           <br>
           <img src="images/addons/430.gif"> 
           <img src="images/addons/730.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/138.gif"> 
           <img src="images/addons/1038.gif"> 
           <br>
           <img src="images/addons/438.gif"> 
           <img src="images/addons/738.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Winning Lottery Ticket, 1 Terra Rod, 1 Snakebite Rod, 1 Hailstorm Rod, 1 Necrotic Rod, 1 Moonlight Rod, 1 Wand of Inferno, 1 Wand of Decay, 1 Wand of Cosmic Energy, 1 Wand of Vortex, 1 Wand of Dragonbreath, 10 Magic Sulphur, 20 Ankh, 1 Soul Stone</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Ferumbras Hat</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Barbarian</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +4 Skills Axe.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/143.gif"> 
           <img src="images/addons/1043.gif"> 
           <br>
           <img src="images/addons/443.gif"> 
           <img src="images/addons/743.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/147.gif"> 
           <img src="images/addons/1047.gif"> 
           <br>
           <img src="images/addons/447.gif"> 
           <img src="images/addons/747.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Iron Ore, 1 Huge Chunk of Crude Iron, 50 Perfect Behemoth Fang, 50 Lizard Leather</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Fighting Spirit, 1 Warriors Sweat, 50 Red Piece of Cloth, 50 Green Piece of Cloth, 10 Spool of Yarn</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Druid</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +3 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/144.gif"> 
           <img src="images/addons/1044.gif"> 
           <br>
           <img src="images/addons/444.gif"> 
           <img src="images/addons/744.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/148.gif"> 
           <img src="images/addons/1048.gif"> 
           <br>
           <img src="images/addons/448.gif"> 
           <img src="images/addons/748.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>50 Wolf Paw, 50 Bear Paw</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Demon Dust, 1 Waterhose, 1 Ceirons Wolf Tooth Chain</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Nobleman</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, +15 Speed.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/132.gif"> 
           <img src="images/addons/1032.gif"> 
           <br>
           <img src="images/addons/432.gif"> 
           <img src="images/addons/732.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/140.gif"> 
           <img src="images/addons/1040.gif"> 
           <br>
           <img src="images/addons/440.gif"> 
           <img src="images/addons/740.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>150k</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>150k</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Oriental</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +40 Speed.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/146.gif"> 
           <img src="images/addons/1046.gif"> 
           <br>
           <img src="images/addons/446.gif"> 
           <img src="images/addons/746.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/150.gif"> 
           <img src="images/addons/1050.gif"> 
           <br>
           <img src="images/addons/450.gif"> 
           <img src="images/addons/750.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Mermaid Comb</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Ape Fur, 100 Fish Fin, 2 Enchanted Chicken Wing, 100 Blue Piece of Cloth</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Summoner</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +4 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/133.gif"> 
           <img src="images/addons/1033.gif"> 
           <br>
           <img src="images/addons/433.gif"> 
           <img src="images/addons/733.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/141.gif"> 
           <img src="images/addons/1041.gif"> 
           <br>
           <img src="images/addons/441.gif"> 
           <img src="images/addons/741.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Winning Lottery Ticket, 1 Terra Rod, 1 Snakebite Rod, 1 Hailstorm Rod, 1 Necrotic Rod, 1 Monlight Rod, 1 Wand of Inferno, 1 Wand of Decay, 1 Wand of Cosmic Energy, 1 Wand of Vortex, 1 Wand of Dragonbreath, 10 Magic Sulphur, 20 Ankh, 1 Soul Stone</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>70 Bat Wing, 20 Red Piece of Cloth, 40 Ape Fur, 35 Holy Orchid, 10 Spool of Yarn, 60 Lizard Scale, 40 Red Dragon Scale, 15 Magic Sulphur, 30 Vampire Dust, 1 Ferumbras Hat</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Warrior</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +4 Sword.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/134.gif"> 
           <img src="images/addons/1034.gif"> 
           <br>
           <img src="images/addons/434.gif"> 
           <img src="images/addons/734.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/142.gif"> 
           <img src="images/addons/1042.gif"> 
           <br>
           <img src="images/addons/442.gif"> 
           <img src="images/addons/742.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 hardened bone, 100 turtle shell, 1 fighting spirit, 1 dragon claw</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Piece of Royal Steel, 100 Iron Ore </b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Wizard</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +3 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/145.gif"> 
           <img src="images/addons/1045.gif"> 
           <br>
           <img src="images/addons/445.gif"> 
           <img src="images/addons/745.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/149.gif"> 
           <img src="images/addons/1049.gif"> 
           <br>
           <img src="images/addons/449.gif"> 
           <img src="images/addons/749.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Crown Legs, 1 Ring of The Sky, 1 Dragon Scale Mail, 1 Medusa Shield</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>50 Holy Orchid</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Assassin</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +5 Distance.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/152.gif"> 
           <img src="images/addons/1052.gif"> 
           <br>
           <img src="images/addons/452.gif"> 
           <img src="images/addons/752.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/156.gif"> 
           <img src="images/addons/1056.gif"> 
           <br>
           <img src="images/addons/456.gif"> 
           <img src="images/addons/756.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>30 Beholder Eye, 10 Red Dragon Leather, 30 Lizard Scale, 20 Fish Fin, 20 Vampire Dust, 10 Demon Dust, 1 Warriors Sweat</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>50 White Piece of Cloth, 50 Green Piece of Cloth, 50 Red Piece of Cloth, 50 Blue Piece of Cloth, 50 Brown Piece of Cloth, 50 Yellow Piece of Cloth, 10 Spool of Yarn</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Beggar</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +2 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/153.gif"> 
           <img src="images/addons/1053.gif"> 
           <br>
           <img src="images/addons/453.gif"> 
           <img src="images/addons/753.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/157.gif"> 
           <img src="images/addons/1057.gif"> 
           <br>
           <img src="images/addons/457.gif"> 
           <img src="images/addons/757.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Ape Fur and 20k</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Simon the Beggars Favorite Staff</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Brotherhood of Bones</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +3 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/278.gif"> 
           <img src="images/addons/1178.gif"> 
           <br>
           <img src="images/addons/578.gif"> 
           <img src="images/addons/878.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/279.gif"> 
           <img src="images/addons/1179.gif"> 
           <br>
           <img src="images/addons/579.gif"> 
           <img src="images/addons/879.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1500 Demonic Essences.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1500 Demonic Essences.</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Demon Hunter</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus 4 Skills Sword, Club, and Axe.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/289.gif"> 
           <img src="images/addons/1189.gif"> 
           <br>
           <img src="images/addons/589.gif"> 
           <img src="images/addons/889.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/288.gif"> 
           <img src="images/addons/1188.gif"> 
           <br>
           <img src="images/addons/588.gif"> 
           <img src="images/addons/888.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido completando Inquisition Quest.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido completando Inquisition Quest.</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Jester</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +15 Speed.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/273.gif">
           <img src="images/addons/1173.gif"> 
           <br>
           <img src="images/addons/573.gif">
           <img src="images/addons/873.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/270.gif">
           <img src="images/addons/1170.gif"> 
           <br>
           <img src="images/addons/570.gif">
           <img src="images/addons/870.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Spool of Yarn, 4 Minotaur Leather</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>5 White Piece of Cloth</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Nightmare</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +6 Shield.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/268.gif"> 
           <img src="images/addons/1168.gif"> 
           <br>
           <img src="images/addons/568.gif"> 
           <img src="images/addons/868.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/269.gif"> 
           <img src="images/addons/1169.gif"> 
           <br>
           <img src="images/addons/569.gif"> 
           <img src="images/addons/869.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1500 Demonic Essence</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1500 Demonic Essence</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Norseman</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +4 Club.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/251.gif"> 
           <img src="images/addons/1151.gif"> 
           <br>
           <img src="images/addons/551.gif"> 
           <img src="images/addons/851.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/252.gif"> 
           <img src="images/addons/1152.gif"> 
           <br>
           <img src="images/addons/552.gif"> 
           <img src="images/addons/852.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>5 Shard</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>10 Shard</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Pirate</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +2 Sword, Club and Axe.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/151.gif"> 
           <img src="images/addons/1051.gif"> 
           <br>
           <img src="images/addons/451.gif"> 
           <img src="images/addons/751.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/155.gif"> 
           <img src="images/addons/1055.gif"> 
           <br>
           <img src="images/addons/455.gif"> 
           <img src="images/addons/755.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Peg Leg, 100 Hook, 100 Eye Patch</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>1 Brutus Bloodbeards Hat, 1 Lethal Lissys Shirt, 1 Ron The Rippers Sabre, 1 Deadeye Deviouseye Patch</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Shaman</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +4 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/154.gif">
           <img src="images/addons/10541.gif"> 
           <br>
           <img src="images/addons/Male_Shaman_1.gif">
           <img src="images/addons/Male_Shaman_2.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/158.gif">
           <img src="images/addons/758.gif"> 
           <br>
           <img src="images/addons/Female_Shaman_1.gif">
           <img src="images/addons/Female_Shaman_2.gif"> 
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>5 Voodoo Doll, 1 Mandrake</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>5 Banana Staff, 5 Tribal Mask</b></font></td>
     </tr>
   </table>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Yalaharian</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +4 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/325.gif"> 
           <img src="images/addons/325.gif"> 
           <br>
           <img src="images/addons/625.gif"> 
           <img src="images/addons/925.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/324.gif"> 
           <img src="images/addons/324.gif"> 
           <br>
           <img src="images/addons/624.gif"> 
           <img src="images/addons/924.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido na Yalahar Quest.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido na Yalahar Quest.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Warmaster</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus ???.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/26.gif"> 
           <img src="images/addons/28.gif"> 
           <br>
           <img src="images/addons/30.gif"> 
           <img src="images/addons/24.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/27.gif"> 
           <img src="images/addons/29.gif"> 
           <br>
           <img src="images/addons/31.gif"> 
           <img src="images/addons/25.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido na Pits of Inferno Quest.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido na Pits of Inferno Quest.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Wayfarer</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus ???.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/58.gif"> 
           <img src="images/addons/18.gif"> 
           <br>
           <img src="images/addons/20.gif"> 
           <img src="images/addons/22.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/17.gif"> 
           <img src="images/addons/19.gif"> 
           <br>
           <img src="images/addons/21.gif"> 
           <img src="images/addons/23.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido na Wrath of the Emperor Quest.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Pode ser obtido na Wrath of the Emperor Quest.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Afflicted</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +2 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/59.gif"> 
           <img src="images/addons/61.gif"> 
           <br>
           <img src="images/addons/63.gif"> 
           <img src="images/addons/65.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/60.gif"> 
           <img src="images/addons/62.gif"> 
           <br>
           <img src="images/addons/64.gif"> 
           <img src="images/addons/66.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Plague Mask.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Plague Bell.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Elementalist</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +4 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/44.gif"> 
           <img src="images/addons/46.gif"> 
           <br>
           <img src="images/addons/48.gif"> 
           <img src="images/addons/42.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/45.gif"> 
           <img src="images/addons/47.gif"> 
           <br>
           <img src="images/addons/49.gif"> 
           <img src="images/addons/43.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Mages Cap.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Elemental Spikes.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Insectoid</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus ???.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/67.gif"> 
           <img src="images/addons/69.gif"> 
           <br>
           <img src="images/addons/71.gif"> 
           <img src="images/addons/73.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/68.gif"> 
           <img src="images/addons/70.gif"> 
           <br>
           <img src="images/addons/72.gif"> 
           <img src="images/addons/74.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Waspoid Wing.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Waspoid Claw.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Deepling</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus ???.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/34.gif"> 
           <img src="images/addons/38.gif"> 
           <br>
           <img src="images/addons/39.gif"> 
           <img src="images/addons/36.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/35.gif"> 
           <img src="images/addons/41.gif"> 
           <br>
           <img src="images/addons/40.gif"> 
           <img src="images/addons/37.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Eye of a Deepling.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>100 Spellsingers Seal.</b></font></td>
     </tr>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Red Baron</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus +2 Magic Level.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/54.gif"> 
           <img src="images/addons/55.gif"> 
           <br>
           <img src="images/addons/56.gif"> 
           <img src="images/addons/52.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/50.gif"> 
           <img src="images/addons/51.gif"> 
           <br>
           <img src="images/addons/57.gif"> 
           <img src="images/addons/53.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Sem informa�oes.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Sem informa�oes.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Crystal Warlod</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus ???.</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/1.gif"> 
           <img src="images/addons/1.gif"> 
           <br>
           <img src="images/addons/7.gif"> 
           <img src="images/addons/8.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/5.gif"> 
           <img src="images/addons/5.gif"> 
           <br>
           <img src="images/addons/4.gif"> 
           <img src="images/addons/6.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Sem informa�oes.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Sem informa�oes.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
     <td>
   <table style="border: 2px solid rgb(93, 67, 16);" width="100%" border="0" cellspacing="0" dwcopytype="CopyTableRow">
     <tr> 
       <td colspan="4" bgcolor="#505050"><div align="center"><font color="white" size="4">Soil Guardian</font></div></td>
     </tr>
     <tr> 
       <td width="25%" bgcolor="#D4C0A1"><div align="right"><font color="">Premium required:</font></div></td>
       <td width="25%" bgcolor="#F1E0C6"><font size="1"><b>No, Bonus ???</b></font></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Male</font></div></td>
       <td style="border: 1px solid rgb(93, 67, 16);" width="20%" bgcolor="#D4C0A1"><div align="center"><font color="">Female</font></div></td>
     </tr>
     <tr>
       <td bgcolor="#D4C0A1"></td>
       <td bgcolor="#F1E0C6"></b></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/13.gif"> 
           <img src="images/addons/14.gif"> 
           <br>
           <img src="images/addons/15.gif"> 
           <img src="images/addons/16.gif"> 
         </center></td>
       <td style="border: 1px solid rgb(93, 67, 16);" rowspan="3" bgcolor="#F1E0C6"> <center>
           <img src="images/addons/9.gif"> 
           <img src="images/addons/10.gif"> 
           <br>
           <img src="images/addons/11.gif"> 
           <img src="images/addons/12.gif">
         </center></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><div align="right"><font color="">First Required:</font></div></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Sem informa�oes.</b></font></td>
     </tr>
     <tr> 
       <td bgcolor="#D4C0A1"><p align="right"><font color="">Second Required:</font></p></td>
       <td bgcolor="#F1E0C6"><font size="1"><b>Sem informa�oes.</b></font></td>
     </tr>
   </table>
  </td>
  </td>
 </tr>
 <tr>
 </tr></table>';
  $main_content .= '';
?> 