<?
if($group_id_of_acc_logged >= $config['site']['access_admin_panel']) {
$conexao=mysql_connect("localhost","root","str4ng23"); 
mysql_select_db("Thunder");
$sql = "SELECT * FROM confirmacao";
$resultado =mysql_query($sql);
while($pegar = mysql_fetch_array($resultado)) {  
header("Content-Type: text/html; charset=ISO-8859-1",true); 
$main_content .= '
<span><b>Player:</b></span><br />
'.$pegar[player].'<br /><Br />
<span><b>Assunto:</b></span><br /> 
'.$pegar[assunto].'<br /><br>
<span><b>Banco:</b></span><br />
'.$pegar[banco].'<br /><Br />
<span><b>Nome:</b></span><br />
'.$pegar[nome].'<br /><Br />
<span><b>Email:</b></span><br />
'.$pegar[email].'<br /><Br />
<span><b>Conta:</b></span><br />
'.$pegar[conta].'<br /><Br />
<span><b>Data:</b></span><br />
'.$pegar[data].'<br /><Br />
<span><b>Hora:</b></span><br />
'.$pegar[hora].'<br /><Br />
<span><b>Valor:</b></span><br />
'.$pegar[valor].'<br /><Br />
<span><b>Foto:</b></span><br />
<img src="confirmacao/images/'.$pegar[foto].'" width="400px" height="400px"/>
<br /><Br />=========================================<br>';}}else{$main_content .= 'Area reistrita, somente administradores podem ver está pagina';}
?>
