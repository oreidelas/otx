<form target="pagseguro" method="post" action="https://pagseguro.uol.com.br/security/webpagamentos/webpagto.aspx" name="LOGIN" class="formulario">
<input type="hidden" name="email_cobranca" value="suporte.thunder@live.com">
<input type="hidden" name="tipo" value="CP">
<input type="hidden" name="moeda" value="BRL">

<input type="hidden" name="item_id_1" value="2000050">
<input type="hidden" name="item_quant_1" value="1"> 

<input type="hidden" name="item_frete_1" value="0">
<input type="hidden" name="item_quant_1" value="1">
<input type="hidden" name="item_peso_1" value="0">
<input type="hidden" name="item_descr_1" value="Servicos - Str4ng">
<input type="hidden" name="ref_transacao" value="Servicos - Str4ng">
<table border="0" cellpadding="4" cellspacing="1" width="100%" id="#estilo"><tbody>
    </tr>
        <td><strong><center><br><img src="https://stc.pagseguro.uol.com.br/pagseguro/i/pagseguro_uol.gif"/><br></strong></td>
    </tr>
    <tr>
        <td width="10%"><br><b>Valor do pagamento: 
          <select name="item_valor_1" id="item_valor_1" tabindex="2">
            <option selected>Selecione</option>
            <option value="10,00">10 reais</option>
            <option value="12,00">12 reais</option>
            <option value="20,00">20 reais</option>
            <option value="30,00">30 reais</option>
            <option value="40,00">40 reais</option>
            <option value="50,00">50 reais</option>
          </select>
        </b></td>
        <td>&nbsp;</td>
        </tr>
    <tr>
        <td colspan="2"><br>
            <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/carrinhoproprio/btnFinalizar.jpg" name="submit" alt="Pague com PagSeguro - &eacute; r&aacute;pido, gr&aacute;tis e seguro!" /></center><br>
        </td>
        </tr>
</tbody></table></form>



</tbody></table><br><br>
			       </tbody></table>        <br>