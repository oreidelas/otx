<?                         
$conexao=mysql_connect("localhost","root","str4ng23");
mysql_select_db("Thunder");
function upload($diretorio, $name) {
$nome_original = md5(uniqid($_FILES["$name"]["name"])). "." .$ext[1];
$nome_temporario = $_FILES["$name"]["tmp_name"];
$ext = array("gif","jpg","PNG","png");
$sql = "INSERT into confirmacao (id_confirmacao,nome,email,conta,data,hora,valor,foto) values ('null','$nome','$email','$conta','$data','$hora','$valor', '$nome_original$ext[1]')";
$consulta = mysql_query($sql);
if(!file_exists($diretorio.$nome_original.$ext[1])){
copy ($nome_temporario,$diretorio.$nome_original.$ext[1]) or die ("Erro ao tentar salvar o arquivo.");
}else{
$main_content .= '<br>Opa! Você já hospedou este arquivo, ou seja.. já há um arquivo com este nome!';
}
}
if($_POST["confirmar"]){
upload("imagens/", "anexo", "$ext");
}else{?>
<br />
Foto:<input name="anexo" type="file" /> <input type="submit" class="form1" name="confirmar" value="Enviar">
<br />
<? } ?>
