<?PHP
$main_content .= '<center><IMG SRC="images/letters/c.gif" BORDER=0 ALIGN=bottom><IMG SRC="images/letters/a.gif" BORDER=0 ALIGN=bottom><IMG SRC="images/letters/s.gif" BORDER=0 ALIGN=bottom><IMG SRC="images/letters/s.gif" BORDER=0 ALIGN=bottom><IMG SRC="images/letters/i.gif" BORDER=0 ALIGN=bottom><IMG SRC="images/letters/n.gif" BORDER=0 ALIGN=bottom><IMG SRC="images/letters/o.gif" BORDER=0 ALIGN=bottom>
<br/>
<br/>
<IMG SRC="http://i52.tinypic.com/nvpr4h.jpg" BORDER=0 ALIGN=bottom> Encontra-se no andar da pris&atilde;o (TEMPLO). Basta <b>voc&ecirc; ter 1k e puxar a alavanca e tentar fazer sequancias premiadas</b> (Puxar alavanca varias vezes ajuda a parar na escolha) (Ainda em ajuste de pr&ecirc;mio e etc..)
<br/>
<br/>
<br/>
<IMG SRC="http://i56.tinypic.com/294guox.png" BORDER=0 ALIGN=bottom>
<br/>
___
<br/>


';
?>
