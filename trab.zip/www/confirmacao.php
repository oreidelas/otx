<?php header("Content-Type: text/html; charset=ISO-8859-1",true); 
/*/by Victor Fasano Raful /*/ 
#Credits may cause the deleted file not working 
if(isset($_POST["acao"]) && $_POST["acao"] == "enviar") 
        {require ("pagamentos/gravar.php");} 

        if(isset($msg)) 
         echo "<div id=\"msg\">$msg</div>"; 
$main_content .= '<script>function abreJanela(URL) {

		location.href = URL;

	}</script>
<div id="ProgressBar">  <div id="Headline">Confirma��o de Doa��o</div>  <div id="MainContainer">    <div id="BackgroundContainer">    
  <img id="BackgroundContainerLeftEnd" src="layouts/tibiacom/images/vips/stonebar-left-end.gif">      <div id="BackgroundContainerCenter">     
  <div id="BackgroundContainerCenterImage" style="background-image: url(layouts/tibiacom/images/content/stonebar-center.gif);"></div>     
  </div>      <img id="BackgroundContainerRightEnd" src="layouts/tibiacom/images/vips/stonebar-right-end.gif">    </div>    
  <img id="TubeLeftEnd" src="layouts/tibiacom/images/vips/progress-bar-tube-left-green.gif">    <img id="TubeRightEnd" src="layouts/tibiacom/images/vips/progress-bar-tube-right-blue.gif">   
  <div id="FirstStep" class="Steps">      <div class="SingleStepContainer">        <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-0-green.gif">     
  <div class="StepText" style="font-weight: normal;">Regras da Doa��o</div>      </div>    </div>    <div id="StepsContainer1">      <div id="StepsContainer2">      
  <div class="Steps" style="width: 25%;">          <div class="TubeContainer">            <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green.gif">    
  </div>          <div class="SingleStepContainer">            <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-1-green.gif">            
  <div class="StepText" style="font-weight: normal;">Metodo de Pagamento</div>          </div>        </div>        <div class="Steps" style="width: 25%;">         
  <div class="TubeContainer">            <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green.gif">          </div>          <div class="SingleStepContainer"> 
  <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-2-green.gif">            <div class="StepText" style="font-weight: normal;">Informa��es do Pedido</div>     
  </div>        </div>        <div class="Steps" style="width: 25%;">          <div class="TubeContainer">            
  <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green.gif">          </div>          <div class="SingleStepContainer">       
  <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-3-green.gif">            <div class="StepText" style="font-weight: bold;">Confirma��o</div>     
  </div>        </div>        <div class="Steps" style="width: 25%;">          <div class="TubeContainer">            
  <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green-blue.gif">          </div>          <div class="SingleStepContainer">         
  <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-4-blue.gif">            <div class="StepText" style="font-weight: normal;">Pedido Realizado</div>  
  </div>        </div>      </div>    </div>  </div></div>

 

 Aqui voc� encontra tudo que � necessario para fazer sua doa��o com seguran�a e facilidade.<br><br>
 <div class="TableContainer">  <div class="CaptionContainer">    
 <div class="CaptionInnerContainer">      
 <span class="CaptionEdgeLeftTop" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>      
 <span class="CaptionEdgeRightTop" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>      
 <span class="CaptionBorderTop" style="background-image: url(layouts/tibiacom/images/content/table-headline-border.gif);"></span>  
 <span class="CaptionVerticalLeft" style="background-image: url(layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>   
 <div class="Text">Informa��es para realiza��o da sua doa��o.</div>      

 <span class="CaptionVerticalRight" style="background-image: url(layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>     
 <span class="CaptionBorderBottom" style="background-image: url(layouts/tibiacom/images/content/table-headline-border.gif);"></span>     
 <span class="CaptionEdgeLeftBottom" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>       
 <span class="CaptionEdgeRightBottom" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>    
 </div>    </div>    <table class="Table1" cellpadding="0" cellspacing="0">    <tbody><tr>      <td>        <div class="InnerTableContainer">       
 <table style="width: 100%;"><tbody>
 <td valign="middle" width="25px;">';
if(@$_GET['action'] == 'banco'){
include "confirmacao/banco.php";
}elseif(@$_GET['action'] == 'pagseguro'){
$main_content .= 'N�o � mais necess�rio confirmar donates via pagseguro, aguarde que seus points chegar�o.';
}elseif(@$_GET['action'] == ''){
$main_content .= '<span><b>Tipo de Pagamento:</b><span style="color:red;"><small>*</small></span></span>  <br /> 
			 <select name="tipo" onchange="javascript: abreJanela(this.value)">
			 <option value="" selected="">  </option> 
			 <option value="?subtopic=confirmacao&action=pagseguro">PagSeguro</option> 
			 <option value="?subtopic=confirmacao&action=banco">Caixa Economica Federal</option>
			 <option value="?subtopic=confirmacao&action=banco">Banco It�u</option></select>';}
$main_content .= '
 </tbody></table>        </div>  </td></tr></tbody></table></div><br>';
?>