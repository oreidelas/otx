<?PHP
$main_content .='<center><h1>Dota Event<h1></center>
<h2><center>The Power of the Generators</center></h2>

	<table width="100%" cellspacing="1" cellpadding="6">

	<tr widht="100%" bgcolor="#505050">

		<th align="center">Informa&ccedil;&otilde;es Gerais do Evento</th>

	</tr>

	<tr widht="100%" bgcolor="#D4C0A1">

		<td><font color="red"><b>Se voc� morrer no Dota voc� perder� level e skills normalmente, mas a EXP dos geradores s�o relativamente altas.</b></font></td>

	</tr>

	<tr widht="100%" bgcolor="#F1E0C6">

		<td><b> O Time que ganhar o evento vai ganhar um Dota Medal + um item random que varia de Golden Legs, Mms, Mpa etc..</b></td>

	</tr>

	<tr widht="100%" bgcolor="#D4C0A1">

		<td>O Dota � um evento que ocorre aos Domingos, Ter�as e Sextas �s 17:00 Horas, no qual as times tem que destruir todos os geradores para ganhar o evento.</td>

	</tr>

	<tr widht="100%" bgcolor="#F1E0C6">

		<td>Quando der o horario do evento vai liberar a pedra por 10 minutos para os times se prepararem, ap�s os 10 minutos o evento come�ar� e pedra voltara a entrada, sendo assim s� entrar� novos players quando o evento come�ar de outra vez.</td>

	</tr>

	<tr widht="100%" bgcolor="#D4C0A1">

		<td>Ap�s o evento ter come�ado n�o tem tempo para acabar, ser�o uma luta contra o rel�gio onde o time que matar os 3 geradores mais rapido ter� acesso a sala de recompensas para pegar seus respectivos premios, e os perdedores v�o para o seu templo natal e poder�o tentar novamente de outra vez!</td>

	</tr>

	<tr widht="100%" bgcolor="#F1E0C6">

		<td>Caso ocorra algum BUG ou algo do g�nero por favor reporte em nosso Forum para o mesmo ser corrigido o mais rapido o poss�vel.</td>

	</tr>


	<tr width="100%" bgcolor="#D4C0A1">

	</tr>

</table></center>

<h2><center>Video Demonstrativo do Evento</h2></center>
<center><iframe width="420" height="315" src="http://www.youtube.com/embed/bBxZaZetEYE" frameborder="0" allowfullscreen></iframe></center><br/> 

<br>

';

?>