<?PHP
$main_content .= '
<br>
Before you can download the client program please read the Tibia Service Agreement and state if you agree to it by clicking on the appropriate button below.
<br>
<p>
<div class="TableContainer" > 
<table class="Table1" cellpadding="0" cellspacing="0" >
<div class="CaptionContainer" >
<div class="CaptionInnerContainer" >
<span class="CaptionEdgeLeftTop" style="background-image:url(http://static.tibia.com/images/global/content/box-frame-edge.gif);" /></span>
<span class="CaptionEdgeRightTop" style="background-image:url(http://static.tibia.com/images/global/content/box-frame-edge.gif);" /></span>
<span class="CaptionBorderTop" style="background-image:url(http://static.tibia.com/images/global/content/table-headline-border.gif);" ></span>
<span class="CaptionVerticalLeft" style="background-image:url(http://static.tibia.com/images/global/content/box-frame-vertical.gif);" /></span>
<div class="Text" >Tibia Service Agreement</div>
<span class="CaptionVerticalRight" style="background-image:url(http://static.tibia.com/images/global/content/box-frame-vertical.gif);" /></span>
<span class="CaptionBorderBottom" style="background-image:url(http://static.tibia.com/images/global/content/table-headline-border.gif);" ></span>
<span class="CaptionEdgeLeftBottom" style="background-image:url(http://static.tibia.com/images/global/content/box-frame-edge.gif);" /></span>
<span class="CaptionEdgeRightBottom" style="background-image:url(http://static.tibia.com/images/global/content/box-frame-edge.gif);" /></span>
</div></div>     

<tr><td class="LabelV150" >
<br>
 This agreement describes the terms on which CipSoft GmbH offers you access to an account for being able to play the online role playing game "Tibia". By creating an account or downloading the client software you accept the terms and conditions below and state that you are of full legal age in your country or have the permission of your parents to play this game.
<p>
 You agree that the use of the software is at your sole risk. We provide the software, the game, and all other services "as is". We disclaim all warranties or conditions of any kind, expressed, implied or statutory, including without limitation the implied warranties of title, non-infringement, merchantability and fitness for a particular purpose. We do not ensure continuous, error-free, secure or virus-free operation of the software, the game, or your account.
<P>
 We are not liable for any lost profits or special, incidental or consequential damages arising out of or in connection with the game, including, but not limited to, loss of data, items, accounts, or characters from errors, system downtime, or adjustments of the gameplay.
<p>
 While you are playing "Tibia", you must abide by some rules ("Tibia Rules") that are stated on this homepage. If you break any of these rules, your account may be removed and all other services terminated immediately.
<br><br>
</b></td></div>  </table></div></td></tr>

<BR>
<center>
<tr>
</form>
</table>
</td>
<td>
<table border="0" cellspacing="0" cellpadding="0" >
<form action="?subtopic=downloadsclient" method="post" >
<tr>
<td style="border:0px;" >
<div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)" >
<div onMouseOver="MouseOverBigButton(this);" onMouseOut="MouseOutBigButton(this);" >
<div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);" >
</div><input class="ButtonText" type="image" name="I Agree" alt="I Agree" src="'.$layout_name.'/images/buttons/_sbutton_iagree.gif" >
</div>
</div>
</td>
</tr>
</form>
</table>
</td>
</tr>
</table></center>  
';
