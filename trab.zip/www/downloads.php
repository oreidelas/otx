<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
<?PHP
$main_content .= ' 
<center>
<table border="1">
<tbody><tr><td><table width="500" border="0" cellpadding="4" cellspacing="1">
  <tbody>
    <tr>
      <td colspan="2" bgcolor="#505050"><b><font color="#505050">..</font><font color="WHITE">Downloads!</font></b></td>  
 </tr>
    <tr bgcolor="#d4c0a1">
      <td colspan="2">Fa�a o Download do Tibia 8.60</td>
    </tr>
    <tr bgcolor="#f1e0c6">
      <td width="80" align="center"><img src="http://1.bp.blogspot.com/_XyYbN_2bWn8/SfErD-MadjI/AAAAAAAABBM/HNi7D04VScw/S220/TibiaIcon.png" alt="" /><br />
        </td>
      <td>
Cliente 8.60 original <a href="http://tibiabr.com/Downloads/Tibia_8.60">Download!</a>
        </td>
        
    </tr>
    <tr bgcolor="#d4c0a1">
    </tr>
    <tr bgcolor="#f1e0c6">
      <td width="80" align="center"><img src="http://1.bp.blogspot.com/_XyYbN_2bWn8/SfErD-MadjI/AAAAAAAABBM/HNi7D04VScw/S220/TibiaIcon.png" alt="" /><br />
        </td>
      <td>
Cliente Dangera Serv <a href="http://www.4shared.com/file/-o8anp0Q/DangeraOT.html">Download!</a> (n�o precisa ip changer}
        </td>
</tr>
    <tr bgcolor="#d4c0a1">
      <td colspan="2">IP Changer(nao prescisa usar no client proprio)</td>
    <tr bgcolor="#d4c0a1">
    </tr>
    <tr bgcolor="#f1e0c6">
      <td width="80" align="center"><img src="http://files.nireblog.com/blogs4/tibianos/files/asprate.jpg" alt="" /><br />
        </td>
      <td>
Asparate Multi IP Changer <a href="http://baixe.net/baixar/down1393.html">Download!</a>
    </tr>
    <tr>
      <td colspan="2" bgcolor="#505050"><b><font color="#505050">..</font><font color="WHITE">Ultilitarios!</font></b></td>
    </tr>
    <tr bgcolor="#d4c0a1">
      <td colspan="2"><b>Team Speak 2 {<a href="http://www.dangera.com">Tuturial</a>}</b></td>
    </tr>
    <tr bgcolor="#d4c0a1">
    </tr>
    <tr bgcolor="#f1e0c6">
      <td width="80" align="center"><img src="http://img94.imageshack.us/img94/1526/7510daxriderteamspeak2r.jpg" alt="" /><br />
        </td>
      <td>
Team Speak 2 <a href="ftp://ftp.freenet.de/pub/4players/teamspeak.org/releases/ts2_client_rc2_2032.exe">Download!</a>
    </tr>
    <tr bgcolor="#d4c0a1">
      <td colspan="2">Grave seus videos.</td>
    <tr bgcolor="#d4c0a1">
    </tr>
    <tr bgcolor="#f1e0c6">
      <td width="80" align="center"><img src="http://img831.imageshack.us/img831/5092/hc3mytake.jpg" alt="" /><br />
        </td>
      <td>
Hypercam <a href="http://www.baixaki.com.br/download/hypercam.htm">Download!</a>
    </tr>
  </tbody>
</table>
      </td>
</tr></tbody></table>
</center>';
?>