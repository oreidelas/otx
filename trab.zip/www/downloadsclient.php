<?PHP
$main_content .= '
    <div class="TableContainer" >
  <table class="Table4" cellpadding="0" cellspacing="0" >
    <div class="CaptionContainer" >
      <div class="CaptionInnerContainer" >
        <span class="CaptionEdgeLeftTop" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>
        <span class="CaptionEdgeRightTop" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>  
      <span class="CaptionBorderTop" style="background-image:url(https://static.tibia.com/images/global/content/table-headline-border.gif);" >
</span>
        <span class="CaptionVerticalLeft" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-vertical.gif);" />
</span>  
      <div class="Text" >Download Client</div>
        <span class="CaptionVerticalRight" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-vertical.gif);" />
</span> 
       <span class="CaptionBorderBottom" style="background-image:url(https://static.tibia.com/images/global/content/table-headline-border.gif);" >
</span>    
    <span class="CaptionEdgeLeftBottom" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>
        <span class="CaptionEdgeRightBottom" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>
      </div>
    </div>
    <tr>  
    <td> 
       <div class="InnerTableContainer" >      
    <table style="width:100%;" >
<tr>
<td>
<table width="100%" cellpadding=0 cellspacing=0><tr><td style="vertical-align:top" >
<div class="TableShadowContainerRightTop" > 
 <div class="TableShadowRightTop" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rt.gif);" >
</div>
</div>
<div class="TableContentAndRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rm.gif);" >
  <div class="TableContentContainer" >
    <table class="TableContent" width="100%" >
<tr>
<td>
<table style="width:100%;text-align:center" >
<tr>
<td>
  <img style="width:180;height:180px;border:0px;" src="layouts/tibiacom/images/content/download_windows.gif" />
</a>
</td>
 <td>
<img style="width:180;height:180px;border:0px;" src="layouts/tibiacom/images/content/download_ipchanger.png" />
<br/>
</a>
</td>
</tr>
<tr>
<td valign="top" >
<a href="http://remeresmapeditor.com//files/tibia/tibia954.exe" type="application/octet-stream" target="_top" >Cliente 9.54 download</a>
</td>
<td valign="top" >
<a href="download/ipchange.exe" type="application/octet-stream" target="_top" >Download Tibia Ip Changer</a>
</td>
</tr>
<tr>
</td>
<tr>
</table>  <center>[<a href="/?subtopic=requirementes">System Requirements</a>]</center>
</tr>
</table>

</table> 

<div class="TableShadowContainer" >  <div class="TableBottomShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bm.gif);" >
    <div class="TableBottomLeftShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bl.gif);" >
</div>
   <div class="TableBottomRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-br.gif);" >

  </div>
</div>
</td>
<td style="vertical-align:top" >
<div class="TableShadowContainerRightTop" >  
<div class="TableShadowRightTop" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rt.gif);" >
</div>
<div class="TableContentAndRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rm.gif);" >
  <div class="TableContentContainer" >
    <table class="TableContent" width="100%" >
<tr>
<td style="text-align:center;" >
<img style="width:254;height:218px;margin:7px;" src="layouts/tibiacom/images/content/successful_download.jpg" />
</td>
</tr>
    </table>
</div></div>
<div class="TableShadowContainer" >
  <div class="TableBottomShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bm.gif);" >
    <div class="TableBottomLeftShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bl.gif);" >
</div>
    <div class="TableBottomRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-br.gif);" >
</div>  


</td>
</tr>
<div class="TableShadowContainerRightTop" >
  <div class="TableShadowRightTop" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rt.gif);" >
</div></table>
<div class="TableContentAndRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rm.gif);" >
  <div class="TableContentContainer" >
    <table class="TableContent" width="100%" >

<td class="LabelV" >Disclaimer</td>
</tr>

<td>The software and any related documentation is provided "as is" without warranty of any kind. The entire risk arising out of use of the software remains with you. In no event shall CipSoft GmbH be liable for any damages to your computer or loss of data.
</td>
    </table>
  </div>
</div>
<div class="TableShadowContainer" >
  <div class="TableBottomShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bm.gif);" >
    <div class="TableBottomLeftShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bl.gif);" >
</div>
    <div class="TableBottomRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-br.gif);" >
</div></table></table></table></div></table></table></table></table></table></table>
  ';
