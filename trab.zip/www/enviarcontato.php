﻿<?php
// configuração
$oturl = "http://maelstrom-ot.com/";
$destinatario = "suporte.maelstrom@gmail.com";
// configuração

require("libs/class.phpmailer.php"); // Certifique-se de que o caminho está certo.

$mail = new PHPMailer();
$emailremetente    = $_POST['email'];
$metodopagto           = $_POST['metodopagto'];
$valor          = $_POST['valor'];
$servidor          = $_POST['servidor'];
$accname         = $_POST['accname'];

$mail->SetLanguage("br", "libs/"); // Linguagem
$mail->SMTP_PORT  = "465"; // Porta do SMTP
$mail->SMTPSecure = "tsl"; // Tipo de comunicação segura

$mail->IsSMTP();
$mail->Host     = "smtp.gmail.com";  // Endereço do servidor SMTP
$mail->SMTPAuth = true; // Requer autenticação?
$mail->Username = "suporte.maelstrom@gmail.com"; // Usuário SMTP
$mail->Password = "jonathan23"; // Senha do usuário SMTP

$mail->From     = "suporte.maelstrom@gmail.com"; // E-mail do remetente
$mail->FromName = "Donation"; // Nome do remetente
$mail->AddAddress("$destinatario"); // E-mail do destinatário

$mail->IsHTML(true);
$mail->Subject = "Novo pagamento no $servidor - (R$$valor)";
$mail->Body    = "<p>
Servidor:<b style=\"font-size:14px;\"> $servidor </b>
<br />
E-mail: $emailremetente
<br /> 
Account name:<b style=\"color:red; font-size:14px;\"> $accname </b>
<br />
Método de Pagto: $metodopagto
<br /> 
Valor: <b style=\"color:green; font-size:14px;\">R$ $valor </b>
<br /> 
</p>";

if(!$mail->Send()) {
echo "Erro: " . utf8_decode($mail->ErrorInfo);
} else {
Header("Location: $oturl");
}

?>
