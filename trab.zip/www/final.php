<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
<?PHP
$main_content .= '

<div class="BoxContent" style="background-image:url(layouts/tibiacom/images/content/scroll.gif); min-height:400px;">
	
			<div class="BoxContent" style="background-image: url(layouts/tibiacom/images/content/scroll.gif);">

	<div id="ProgressBar">  <div id="Headline">Confirma��o Enviada</div>  <div id="MainContainer">    <div id="BackgroundContainer">      <img id="BackgroundContainerLeftEnd" src="layouts/tibiacom/images/vips/stonebar-left-end.gif">      <div id="BackgroundContainerCenter">        <div id="BackgroundContainerCenterImage" style="background-image: url(layouts/tibiacom/images/content/stonebar-center.gif);"></div>      </div>      <img id="BackgroundContainerRightEnd" src="layouts/tibiacom/images/vips/stonebar-right-end.gif">    </div>    <img id="TubeLeftEnd" src="layouts/tibiacom/images/vips/progress-bar-tube-left-green.gif">    <img id="TubeRightEnd" src="layouts/tibiacom/images/vips/progress-bar-tube-right-green.gif">    <div id="FirstStep" class="Steps">      <div class="SingleStepContainer">        <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-0-green.gif">        <div class="StepText" style="font-weight: normal;">Regras da Doa��o</div>      </div>    </div>    <div id="StepsContainer1">      <div id="StepsContainer2">        <div class="Steps" style="width: 25%;">          <div class="TubeContainer">            <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green.gif">          </div>          <div class="SingleStepContainer">            <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-1-green.gif">            <div class="StepText" style="font-weight: normal;">Metodo de Pagamento</div>          </div>        </div>        <div class="Steps" style="width: 25%;">          <div class="TubeContainer">            <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green.gif">          </div>          <div class="SingleStepContainer">            <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-2-green.gif">            <div class="StepText" style="font-weight: normal;">Informa��es do Pedido</div>          </div>        </div>        <div class="Steps" style="width: 25%;">          <div class="TubeContainer">            <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green.gif">          </div>          <div class="SingleStepContainer">            <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-3-green.gif">            <div class="StepText" style="font-weight: normal;">Confirma��o</div>          </div>        </div>        <div class="Steps" style="width: 25%;">          <div class="TubeContainer">            <img class="Tube" src="layouts/tibiacom/images/vips/progress-bar-tube-green.gif">          </div>          <div class="SingleStepContainer">            <img class="StepIcon" src="layouts/tibiacom/images/vips/progress-bar-icon-4-green.gif">            <div class="StepText" style="font-weight: bold;">Pedido Realizado</div>          </div>        </div>      </div>    </div>  </div></div><div class="TableContainer">  <div class="CaptionContainer">      <div class="CaptionInnerContainer">     
	  <span class="CaptionEdgeLeftTop" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>       
	  <span class="CaptionEdgeRightTop" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>    
	  <span class="CaptionBorderTop" style="background-image: url(layouts/tibiacom/images/content/table-headline-border.gif);"></span>   
	  <span class="CaptionVerticalLeft" style="background-image: url(layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>   
	  <div class="Text">Pedido realizado com sucesso.</div>       
	  <span class="CaptionVerticalRight" style="background-image: url(layouts/tibiacom/images/content/box-frame-vertical.gif);"></span>      
	  <span class="CaptionBorderBottom" style="background-image: url(layouts/tibiacom/images/content/table-headline-border.gif);"></span>   
	  <span class="CaptionEdgeLeftBottom" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>   
	  <span class="CaptionEdgeRightBottom" style="background-image: url(layouts/tibiacom/images/content/box-frame-edge.gif);"></span>     
	  </div>    </div>    <table class="Table1" cellpadding="0" cellspacing="0">    <tbody><tr>      <td>        <div class="InnerTableContainer">       
	  <table style="width: 100%;"><tbody><tr><td><br><b><center>O Thunder War agradece pela sua confirma��o de doa��o!</center></b><br><br>
	  <center><img class="PaymentResultImage" src="layouts/tibiacom/images/vips/payment_accepted.gif" alt="order accepted"></center><br><center>Voc� realizou com sucesso a confirma��o de uma doa��o.</center><br>
	  <br>Quando sua doa��o for creditada ela ser� mostrada na pagina <a href="?subtopic=shopsystem&action=show_history"><b>Historicos de Doa��es</b></a>.<br><br>As confirma��es s�o verificadas todos dias as 14:00 da tarde <b>(e seus points poder�o ser entregues no prazo de at� 48 horas)</b>, e s�o ativadas imediatamente lembrando que s�o ativadas as do dia anterior depositadas em horario util. Verifique sempre o seu email, caso sua doa��o atrase ou ocorra algum problema entraremos em contato. O Thunder War agradece sua doa��o, assim podemos sempre continua prestando nossos servi�os da melhor maneira possivel, lembrando que todo dinheiro arrecadado � voltado para o beneficio do servidor.
	<br>
	</td></tr>          </tbody></table>        </div>
	  </td></tr></tbody></table></div><br><center><table border="0" cellpadding="0" cellspacing="0">
	  <tbody><tr><td style="border: 0px none;">
	  <form action="?subtopic=accountmanagement" method="POST">
	  <div class="BigButton" style="background-image: url(layouts/tibiacom/images/buttons/sbutton.gif);">
	  <div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image: url(http://underwar.org/layouts/tibiacom/images/buttons/sbutton_over.gif); visibility: hidden; "></div>
	  <input class="ButtonText" name="Back" alt="Back" src="layouts/tibiacom/images/vips/_sbutton_back.gif" type="image"></div></div></form></td></tr></tbody></table></center> 
	  </div>
	   
      </div>

      ';?>