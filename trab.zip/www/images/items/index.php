<?
header ("Location: ../index.php");
?>
