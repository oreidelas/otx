  <?PHP
        $main_content .= "<center><h2> | Mounts | ".$config['server']['serverName']." |</h2></center>";
        $main_content .= "<style type=\"text/css\">
        .bordafina {
        border-collapse : collapse;
        }
        </style>";



        $main_content .= "<div align=\"center\">";
          $main_content .= "<table width=\"550\" class=\"bordafina\" border=\"1\" >
                <tr>
                  <th width=\"54\" bordercolor=\"#0033FF\" scope=\"col\"><div align=\"center\">Mounts</div></th>
                  <th width=\"220\" scope=\"col\"><div align=\"center\">Items Needed</div></th>
                  <th width=\"389\" scope=\"col\"><div align=\"center\">Monsters that drop</div></th>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/3/36/Widow_Queen.gif\" width=\"50\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/d/df/Sweet_Smelling_Bait.gif\" width=\"32\" height=\"32\">1 Sweet Smelling Bait</div></td>
                  <td><div align=\"center\">Banshee, The Old Widow.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/1/14/Black_Sheep_%28Mount%29.gif\" width=\"32\" height=\"32\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/9/91/Reins.gif\">1 Reins</div></td>
                  <td><div align=\"center\">Dark Apprentice, Dark Magician.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/e/ea/Blazebringer.gif\" width=\"40\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"images/itemmounts/Deed_of_Ownership.gif\" width=\"32\" height=\"32\">1 Deed of OwnerShip</div></td>
                  <td><div align=\"center\"><b>Apenas em Eventos</b></div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"images/mounts/Draptor.gif\" width=\"54\" height=\"54\"></div></td>
                  <td><div align=\"left\"><img src=\"images/itemmounts/Harness.gif\" width=\"32\" height=\"32\">1 Harness</div></td>
                  <td><div align=\"center\">Draken Spellweaver, Draken Abomination</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/1/1f/Midnight_Panther_%28Mount%29.gif\" width=\"32\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/4/44/Leather_Whip.gif\" width=\"32\" height=\"32\">1 Leather Whip</div></td>
                  <td><div align=\"center\">Vampire Bride</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/d/d1/Racing_Bird.gif\" width=\"48\" height=\"48\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/b/b7/Carrot_on_a_Stick.gif\" width=\"32\" height=\"32\">1 Carrot on a Stick</div></td>
                  <td><div align=\"center\">Carniphila e Tiquandas Revenge.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/9/9e/Rapid_Boar.gif\" width=\"32\" height=\"46\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/e/e7/Hunting_Horn.gif\">1 Hunting Horn</div></td>
                  <td><div align=\"center\">Desconhecido</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"images/mounts/Stampor.gif\" width=\"44\" height=\"44\"></div></td>
                  <td><div align=\"left\"><img src=\"images/itemmounts/Hollow_Stampor_Hoof.gif\">30 Hollow Stampor Hoof<br>
                  <img src=\"images/itemmounts/Stampor_Horn.gif\">50 Stampor Horn<br>
                  <img src=\"images/itemmounts/Stampor_Talon.gif\">100 Stampor Talon</div></td>
                  <td><div align=\"center\">Stampor. (Localizado apenas em �reas Vip)</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/c/c2/Tin_Lizzard.gif\" width=\"45\" height=\"65\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/f/fe/Tin_Key.gif\">1 Tim Key</div></td>
                  <td><div align=\"center\">Behemoth, War Golem.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/3/32/Titanica.gif\" width=\"56\" height=\"56\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/b/b6/Giant_Shrimp.gif\">1 Giant Shrimp</div></td>
                  <td><div align=\"center\">Quaras</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/8/86/Undead_Cavebear_%28Mount%29.gif\" width=\"54\" height=\"54\"></div></td>
                  <td><div align=\"left\"><img src=\"http://tibiawiki.com.br/images/2/25/Maxilla_Maximus.gif\">1 Maxilla Maximus</div></td>
                  <td><div align=\"center\">Undead Dragon, Lich.</div></td>
                </tr>
                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/e/e5/War_Bear.gif\" width=\"32\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/0/0b/Slingshot.gif\">1 Slingshot</div></td>
                  <td><div align=\"center\">Hunter e Poacher.</div></td>
                </tr>

                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/2/24/Donkey.gif\" width=\"50\" height=\"55\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/4/44/Bag_of_Apple_Slices.gif\">1 Bag of Apple Slices</div></td>
                  <td><div align=\"center\">Witch</div></td>
                </tr>

                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/0/07/Kingly_Deer.gif\" width=\"65\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/8/8d/Golden_Fir_Cone.gif\">1 Golden Fir Cone</div></td>
                  <td><div align=\"center\">Frost Dragon</div></td>
                </tr>

                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/4/45/Scorpion_King.gif\" width=\"40\" height=\"62\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/e/eb/Scorpion_Sceptre.gif\">1 Scorpion Sceptre</div></td>
                  <td><div align=\"center\">Tomb Servant ,Ferumbras</div></td>
                </tr>

                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/4/4e/Shadow_Draptor.gif\" width=\"55\" height=\"50\"></div></td>
                  <td><div align=\"left\">Desconhecido</div></td>
                  <td><div align=\"center\">Desconhecido</div></td>
                </tr>

                <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/6/62/Tamed_Panda.gif\" width=\"35\" height=\"45\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/2/24/Bamboo_Leaves.gif\">1 Bamboo Leaves</div></td>
                  <td><div align=\"center\">Draken Spellwaver</div></td>
                </tr>

               <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/c/cc/Tiger_Slug.gif\" width=\"40\" height=\"45\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/5/58/Slug_Drug.gif\">1 Slug Drug</div></td>
                  <td><div align=\"center\">Desconhecido</div></td>
                </tr>

               <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/f/f1/Inoperative_Uniwheel.gif\" width=\"35\" height=\"36\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/e/e1/Golden_Can_of_Oil.gif\">1 Golden can of Oil</div></td>
                  <td><div align=\"center\">Golden Servant, Diamond servant</div></td>
                </tr>

               <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/f/f2/Crystal_Wolf_%28Mount%29.gif\" width=\"32\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/4/43/Diapason.gif\">1 Diapason</div></td>
                  <td><div align=\"center\">Worken Golem</div></td>
                </tr>
               <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/e/e7/War_Horse.gif\" width=\"50\" height=\"55\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/b/b4/Sugar_Oat.gif\">1 Sugar Oat</div></td>
                  <td><div align=\"center\">Dromedary</div></td>
                </tr>

               <tr>
                  <td><div align=\"center\"><img src=\"http://www.tibiawiki.com.br/images/f/f4/Dromedary_%28Mount%29.gif\" width=\"50\" height=\"50\"></div></td>
                  <td><div align=\"left\"><img src=\"http://www.tibiawiki.com.br/images/5/50/Fist_on_a_Stick.gif\">1 Fist on a Stick</div></td>
                  <td><div align=\"center\">Tomb Servant</b></div></td>
                </tr>

          </table>";
        $main_content .= "</div>";
        ?>