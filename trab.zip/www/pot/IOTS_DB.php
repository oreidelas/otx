<?php

/**#@+
 * @version 0.1.3
 */

/**
 * @package POT
 * @author Wrzasq <wrzasq@gmail.com>
 * @copyright 2007 - 2008 (C) by Wrzasq
 * @license http://www.gnu.org/licenses/lgpl-3.0.txt GNU Lesser General Public License, Version 3
 */

/**
 * @package POT
 * @deprecated 0.0.5 Don't rely on this interface - it is for backward compatibility only. Check PDO instance instead.
 */
interface IOTS_DB
{
}

/**#@-*/

?>
