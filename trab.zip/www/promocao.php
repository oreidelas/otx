<?PHP
// {made by Renato Ribeiro}

$main_content .= '<table border="0" cellspacing="1" cellpadding="3" width="100%">
	<tr>
		<td colspan="2" class="titleForm"></td>
	</tr>
	<tr>
		<td class="styleTD1">
			<p>&nbsp;<span style="font-size: medium;"><b><font color="red"/><center>Promo��o NeoTibia por templo limitado.</center></font></b></span></p>
<br />

<p><i><h2><center>Veja a Seguinte Promo��o para as " Guilds " !!! </center></h2></i> <br />
<br />

Bom teremos um sistema de doa��es em grupo onde players pode fazer suas doa��es juntos e Obter Points bonus e Itens.</p>

<p style="text-align: center;"></p>
		</td>
	</tr>

</table>
<center><table cellpadding="5" cellspacing="1"><tr><td width="500" colspan="3" bgcolor="#555555"><font color="white" size="3"><b>Vantagens para Doa��es de Guild</b></font></td></tr><tr><td width="500" bgcolor="#F1E0C6"><b>Categoria e Valores</b></td><td width="125" bgcolor="#F1E0C6"><center><b>Pontos</center></b></td><td width="125" bgcolor="#F1E0C6"><b><font color="red"/><center>Bonus</font></b></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">DG1 | Doa��es de 70 reais</td><td width="125" bgcolor="#D4C0A1"><center>70 Points</center> </center></td><td width="125" bgcolor="#D4C0A1"><center><center>30 Points</center></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">DG2 | Doa��es de 100 reais</td><td width="125" bgcolor="#D4C0A1"><center>100 Points</center></td><td width="125" bgcolor="#D4C0A1"><center><center><center>40 Points</center></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">DG3 | Doa��es de 150 reais</td><td width="125" bgcolor="#D4C0A1"><center>150 Points</center></td><td width="125" bgcolor="#D4C0A1"><center>50 Points</center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">DG4 | Doa��es de 200 reais</td><td width="125" bgcolor="#D4C0A1"><center>200 Points</center></td><td width="125" bgcolor="#D4C0A1"><center>70 Points</center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">DG5 | Doa��es de 250 reais</td><td width="125" bgcolor="#D4C0A1"><center>250 Points </center></td><td width="125" bgcolor="#D4C0A1"><center>100 Points</center></td></tr>

<center><table cellpadding="5" cellspacing="1"><tr><td width="500" colspan="3" bgcolor="#555555"><font color="white" size="3"><b>Veja os Itens Bonus de cada Categoria</b></font></td></tr><tr><td width="500" bgcolor="#F1E0C6"><b>Voc� recebera os Itens Bonus seguindo as Categorias abaixo</b></td><td width="125" bgcolor="#F1E0C6"><center><b>Addon Doll</center></b></td><td width="125" bgcolor="#F1E0C6"><b><font color="red"/><center>Doll 2x Exp</font></b></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">Categoria  |  DG3 </td><td width="125" bgcolor="#D4C0A1"><center>4 addon doll</center></td><td width="125" bgcolor="#D4C0A1"><center>10 Itens Xp</center></td></tr>
<tr><td width="500" bgcolor="#D4C0A1">Categoria  |  DG4 </td><td width="125" bgcolor="#D4C0A1"><center>6 addon doll</center></td><td width="125" bgcolor="#D4C0A1"><center>15 Itens Xp</center></td></tr>
<tr><td width="500" bgcolor="#D4C0A1">Categoria  |  DG5 </td><td width="125" bgcolor="#D4C0A1"><center>10 addon doll</center></td><td width="125" bgcolor="#D4C0A1"><center>25 Itens Xp</center></td></tr>
  </table>
  <tr>
    <td width="700" bgcolor="#D4C0A1"><b><font color="red"/>Imagens dos Itens VIP<center><br><h1><img src="lucass/outfit.gif"></h1><br></b></font></center><br></td></tr>
</table>
<table border="0" cellspacing="1" cellpadding="4" width="100%">
        <tr bgcolor="#505050"><td colspan="1" class="white"><center><b>Leia com ATEN��O para fazer confirma��o de Doa��o em Grupo.</b></center></td></tr>
        </table></center></center><br><br>
<b>Qualquer Player pode participar desta promo��o basta apenas ter amigos(a) que tambem queiram fazer doa��o.<br><br>
Ap�s todos do grupo terem feito suas doa��es individual, apenas uma pessoa podera confirmar a doa��o !!! ( mas como n�s iremos fazer???)<br><br>
Muito Simples Basta apenas juntar todos dados de compravante de pagamento e enviar para um membro do seu grupo, ele estara responsavel por todos os points. <br><br>
Veja a Baixo um Exemplo de como confirmar Doa��o em Grupo:<br><br><br><br>

<table border="0" cellspacing="1" cellpadding="4" width="100%">
        <tr bgcolor="#505050"><td colspan="1" class="white"><center><b>Mande um e-mail para " neotibia@live.com " com os seguintes dados.</b></center></td></tr>
        <tr bgcolor="#D4C0A1"><td><b>Player 1:</b> Caixa Economica Federal   |<b>Data e Hora:</b> 01/01/2012  14:32:29  |<b>Valor:</b>25,00 reais.
        <tr bgcolor="#D4C0A1"><td><b>Player 2:</b> Caixa Economica Federal   |<b>Data e Hora:</b> 01/01/2012  16:51:56  |<b>Valor:</b>25,00 reais.
        <tr bgcolor="#D4C0A1"><td><b>Player 3:</b> PagSeguro   |<b>Data e Hora:</b> 01/01/2012  14:43:23  |<b>Valor:</b>25,00 reais.
        <tr bgcolor="#D4C0A1"><td><b>Player 4:</b> PagSeguro   |<b>Data e Hora:</b> 01/01/2012  15:12:43  |<b>Valor:</b>25,00 reais.<br><br></td></tr>
</table><br/></b>
        <center>Ap�s colocar todos os dados de todas as formas de pagamento descreva qual a <b>Categoria</b> e <b>Nick da conta</b> que ira receber todos os pontos.</center><br><br>
       <table border="0" cellspacing="1" cellpadding="4" width="100%">
        <tr bgcolor="#D4C0A1"><td><b>Nick Player:  </b>Teste<br>
        <tr bgcolor="#D4C0A1"><td><b>Categoria:    </b> DG2.<br>
</td></tr>
</table><br/>

<h5><center>Qualquer problema ou Duvida sobre esta promo��o entre em contato com a nossa equip atraves do Chat Online no site.</center></h5>

</center><h2><center>Clique abaixo e adquira seus pontos !</center></h2><h2><center><a href="index.php?subtopic=donate">Comprar Pontos</a></center></h2><br>'
?>
