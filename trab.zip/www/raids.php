<?PHP
{
$main_content .= '
  <div align="center"><em>*As invas&otilde;es s&atilde;o executadas automaticamente nas horas especificadas abaixo.</em><br></div>
<br />';
$main_content .= '<table border="0" cellspacing="1" cellpadding="5" width="100%" class="cellspadding">
 <tr bgcolor="'.$config['site']['vdarkborder'].'">
  <td width="50%" align="center"><strong>Nome</strong></td>
  <td width="50%" align="center"><strong>Data/Hora</strong></td>
 </tr>';
$main_content .= '
<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Rats in Thais</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20070906222430/tibia/en/images/a/af/Rat.gif">&nbsp;</center><br></td><td><center>Segunda, 08:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Orcs in Thais</b><br>
<img src="http://images1.wikia.nocookie.net/__cb20050501021751/tibia/en/images/2/21/Orc.gif">&nbsp;</center><br></td><td><center>Quarta, 12:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Barbarians</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20070620112924/tibia/en/images/f/ff/Barbarian_Headsplitter.gif">&nbsp;</center><br></td><td><center>Quinta, 10:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Angry Nomads</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20061212204505/tibia/en/images/d/d8/Nomad.gif">&nbsp;</center><br></td><td><center>Quarta, 08:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Elfs invasion</b><br>
<img src="http://images4.wikia.nocookie.net/__cb20050501015707/tibia/en/images/a/a8/Elf.gif">&nbsp;</center><br></td><td><center>Ter&ccedil;a, 10:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Argh! Pirates</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20060804204013/tibia/en/images/6/64/Pirate_Buccaneer.gif">&nbsp;</center><br></td><td><center>S&aacute;bado, 06:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Good Morning Quaras!</b><br>
<img src="http://images4.wikia.nocookie.net/__cb20060803212936/tibia/en/images/9/9d/Quara_Mantassin.gif">&nbsp;</center><br></td><td><center>Sexta, 04:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Early Scarabs</b><br>
<img src="http://images4.wikia.nocookie.net/__cb20050501022731/tibia/en/images/e/e7/Scarab.gif">&nbsp;</center><br></td><td><center>Ter&ccedil;a, 05:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Undead Army</b><br>
<img src="http://images3.wikia.nocookie.net/__cb20080506191855/tibia/en/images/d/de/Demon_Skeleton.gif">&nbsp;</center><br></td><td><center>Quinta, 20:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Darashia Undeads</b><br>
<img src="http://images4.wikia.nocookie.net/__cb20060613220117/tibia/en/images/a/ab/Ghost.gif">&nbsp;</center><br></td><td><center>Sexta, 12:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Demodras</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20050828183807/tibia/en/images/7/73/Demodras.gif">&nbsp;</center><br></td><td><center>Domingo, 15:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Horned Fox</b><br>
<img src="http://images4.wikia.nocookie.net/__cb20050828185824/tibia/en/images/1/1e/The_Horned_Fox.gif">&nbsp;</center><br></td><td><center>Domingo, 08:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Necropharus</b><br>
<img src="http://images4.wikia.nocookie.net/__cb20050828185531/tibia/en/images/2/23/Necropharus.gif">&nbsp;</center><br></td><td><center>Quinta, 20:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Old Widow</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20050819175526/tibia/en/images/4/42/The_Old_Widow.gif">&nbsp;</center><br></td><td><center>Quarta, 19:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Morgaroth</b><br>
<img src="http://images1.wikia.nocookie.net/__cb20070703000152/tibia/en/images/c/ce/Morgaroth.gif">&nbsp;</center><br></td><td><center>Sexta, 18:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Zulazza the Corruptor</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20091212072417/tibia/en/images/b/ba/Zulazza_the_Corruptor.gif">&nbsp;</center><br></td><td><center>Ter&ccedil;a, 20:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Orshabaal</b><br>
<img src="http://images2.wikia.nocookie.net/__cb20080705233443/tibia/en/images/7/75/Demon.gif">&nbsp;</center><br></td><td><center>Domingo, 18:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Ghazbaran</b><br>
<img src="http://images1.wikia.nocookie.net/__cb20070727220522/tibia/en/images/5/5e/Ghazbaran.gif">&nbsp;</center><br></td><td><center>Segunda, 16:00</center></td>
</tr>

<tr bgcolor="'.$config['site']['lightborder'].'">
<td><center><b>Ferumbras</b><br>
<img src="http://images1.wikia.nocookie.net/__cb20060826062547/tibia/en/images/0/0f/Ferumbras.gif">&nbsp;</center><br></td><td><center>S&aacute;bado, 22:00</center></td>
</tr>';

$main_content .= '</table>';
}
?>
</div></div>