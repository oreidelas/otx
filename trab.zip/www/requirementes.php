<?PHP
$main_content .= '
</head><body>
<div class="Headline" ><center><h1>Requirements:</h1>
</div>
<br/>
<div class="Text" >
<B>Windows:</B>
<UL>
<LI>Windows 95/98/ME/XP/2000/Vista/7</LI><LI>DirectX version 5.0 or later, or OpenGL</LI>
<LI>52 MB free space on your hard disk</LI>
<LI>A connection to the internet</LI>
</UL><B>Linux:</B>
<UL>
<LI>Linux with libc version 6 or later</LI>
<LI>X-Window system installed</LI>
<LI>Hardware accelerated graphics driver</LI>
<LI>55 MB free hard disk space</LI>
<LI>A connection to the internet</LI>
</UL>
</div>
<br/>
<center>
<img src="http://static.tibia.com/images/global/content/ornament.gif" />
<br/>
<a href="/?subtopic=downloadsclient" type="application/octet-stream" target="_top" >Close Window</a>
</center>
</body>
</html>
  ';
