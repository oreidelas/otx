<?PHP
if($action == "") {
$main_content .= '
<center><h2><b><img src="images/letters/A.gif">qui voc� pode conferir as tasks do servidor!</h2></b></center>
<TABLE BGCOLOR='.$config['site']['darkborder'].' BORDER=0 CELLPADDING=4 CELLSPACING=1 WIDTH=100%>
<TR BGCOLOR='.$config['site']['vdarkborder'].'><TD CLASS=white COLSPAN=5><b>Task List and rewards.</b></TD></TR>
<TR><TD><TABLE BORDER=0 CELLPADDING=2 CELLSPACING=1 WIDTH=100%>
<TR BGCOLOR='.$config['site']['lightborder'].'><TD><B><center>Monstro</center></B></TD><TD><B><center>Amount</center></B></TD><TD><B><center>Task Point</center></B></TD><TD><B><center>Recompensa</center></B></TD></TR>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Crocodiles</center></td><td align="center">300</td><td><center> 1 Point </center></td><td><center>1 Knight Armor</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Tarantulas</center></td><td align="center">300</td><td><center> 1 Point </center></td><td><center>1 Knight Legs</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Carniphilas</center></td><td align="center">150</td><td><center> 1 Point </center></td><td><center>1 Mandrake</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Mammoths</center></td><td align="center">300</td><td><center> 2 Point </center></td><td><center>1 Mammoth fur Cape</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Stone Golems</center></td><td align="center">200</td><td><center> 1 Point </center></td><td><center>50 Platinum Coins</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Ice Golems</center></td><td align="center">300</td><td><center> 2 Point </center></td><td><center>1 Diapason</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Quara Scout</center></td><td align="center">300</td><td><center> 2 Point </center></td><td><center>Giant Shrimp</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Quaras</center></td><td align="center">300</td><td><center> 2 Point </center></td><td><center>1 Relic Sword</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Water Elemental</center></td><td align="center">70</td><td><center> 1 Point </center></td><td><center>1 Crystal Coin</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Earth Elemental</center></td><td align="center">70</td><td><center> 1 Point </center></td><td><center>2 Crystal Coin</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Energy Elemental</center></td><td align="center">70</td><td><center> 1 Point </center></td><td><center>70 Platinum Coins</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Fire Elemental</center></td><td align="center">70</td><td><center> 1 Point </center></td><td><center>1 Demon Backpack</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Mutated Rat</center></td><td align="center">200</td><td><center> 2 Point </center></td><td><center>1 Terra Mantle</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Giant Spider</center></td><td align="center">500</td><td><center> 2 Point </center></td><td><center>1 Spool of Yarn</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Hydras</center></td><td align="center">2000</td><td><center> 3 Point </center></td><td><center>1 Egg of the Many</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Sea Serpent</center></td><td align="center">2000</td><td><center> 4 Point </center></td><td><center>1 Leviathan Amulet</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Behemoths</center></td><td align="center">2000</td><td><center> 4 Point </center></td><td><center>1 Earthborn Titan Armor</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Serpent Spawn</center></td><td align="center">1500</td><td><center> 4 Point </center></td><td><center>1 Claw of The Noxious Spawn</center></td></tr>
<tr class="KL" bgcolor="#eeddb9"><td height="2">
<center>Pirates</center></td><td align="center">3000</td><td><center> 1 Point </center></td><td><center>Matar ramdom Pirate</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Necromancer</center></td><td align="center">4000</td><td><center> 4 Point </center></td><td><center>Matar Necropharus</center></td></tr>
<TR BGCOLOR='.$config['site']['lightborder'].'><td height="2">
<center>Demon</center></td><td align="center">6666</td><td><center> 4 Point </center></td><td><center>(Need 50 Task Points) 1 Horned Helmet</center></td></tr>
</TABLE></TD></TR>
</TABLE>
</TD>
<TD></TD>
</TR></TABLE>
';
}
?>