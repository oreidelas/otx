<?PHP
	$question = array();
	
	$question[1] = array(
		'question' => 'A player asks in help channel if he is allowed to post a link to his guild page somewhere on the Tibia website. What do you answer?', 
		'answers' => array(
			'Links to unsupported websites are illegal everywhere on the Tibia website.',
			'Links to unsupported websites are illegal. However, you are allowed to link to guild pages on the real life board.',
			'Links to unsupported websites are illegal. However, you are allowed to post a link to your guild page in the guild section of the official Tibia website.',
			'Links to unsupported websites are illegal. However, you are allowed to post a link to your guild page in your signature unless it violates other rules.',
			'You can post a link to your guild page if the site can be considered safe.'
		), 
		'correct' => array(
			'Links to unsupported websites are illegal. However, you are allowed to post a link to your guild page in the guild section of the official Tibia website.'
		));
	$question[2] = array(
		'question' => 'A player asks you for your password. Would you give it to the player?', 
		'answers' => array(
			'No, nobody needs to know my password.',
			'Yes, if the player claims to be a member of the CipSoft Team.',
			'Yes, if the player is a gamemaster.',
			'Yes, if the player is a tutor.',
			'Yes, if the player seems trustworthy.'
		), 
		'correct' => array(
			'No, nobody needs to know my password.'
		));
	$question[3] = array(
		'question' => 'A tutor comes across the name "Fucking Retard" and decides to report it. Which of the following report comments would be suitable?', 
		'answers' => array(
			'Clearly offensive. Foul language, swear words and insults are not allowed in Tibia.',
			'Este nombre viola las normas.',
			'I think this name is clearly offensive. You should lock it. BTW: CM you rox. :)',
			'It\'s obvious!!!',
			'Name contains an insult and violates Tibia Rule 1a. Please choose a decent name!',
			'No comment.',
			'Player made offensive statements in game chat!'
		), 
		'correct' => array(
			'Clearly offensive. Foul language, swear words and insults are not allowed in Tibia.',
			'Name contains an insult and violates Tibia Rule 1a. Please choose a decent name!'
		));
	$question[4] = array(
		'question' => 'As a tutor, how can I submit proposals to improve the game?', 
		'answers' => array(
			'Post on the help board.',
			'Post on the proposal board.',
			'Post on the support boards.',
			'Send an email to CipSoft.',
			'Use the bug report function.',
			'Use the rule violation report.' 
		), 
		'correct' => array(
			'Post on the proposal board.'
		));
	$question[5] = array(
		'question' => 'How can you protect yourself against hacking?', 
		'answers' => array(
			'If you have bought a Premium Account, do not personalise the account to make sure no hacker can learn your real life data.',
			'Never accept files from other Tibia players.',
			'Never give your password or account number to anybody.',
			'Never use any tools for Tibia that are not released by CipSoft.',
			'Save the password in a file on your computer.',
			'Share your account only with good friends.',
			'Use a firewall and check your computer regularly with anti-virus programs.',
			'Use a very simple and short password.' 
		), 
		'correct' => array(
			'Never accept files from other Tibia players.',
			'Never give your password or account number to anybody.',
			'Never use any tools for Tibia that are not released by CipSoft.',
			'Use a firewall and check your computer regularly with anti-virus programs.'
		));
	$question[6] = array(
		'question' => 'How long can it take until payments for premium points arrive?', 
		'answers' => array(
			'No more than 24 hours.',
			'No more than one week.',
			'Up to three months.',
			'Automatically.'
		), 
		'correct' => array(
			'Automatically.'
		));
	$question[7] = array(
		'question' => 'How many charges does a full Desintegrate rune have?', 
		'answers' => array(
			'1',
			'2',
			'3',
			'4',
			'5'
		), 
		'correct' => array(
			'3'
		));
	$question[8] = array(
		'question' => 'How many experience points do you need for level 36?', 
		'answers' => array(
			'28096000',
			'450000',
			'658000',
			'685000'
		), 
		'correct' => array(
			'658000'
		));
	$question[9] = array(
		'question' => 'How many hitpoints does a dragon have?', 
		'answers' => array(
			'1000',
			'1200',
			'2000'
		), 
		'correct' => array(
			'1000'
		));
	$question[10] = array(
		'question' => 'How many hitpoints does a warlock have?', 
		'answers' => array(
			'2500',
			'3500',
			'4000',
			'5000'
		), 
		'correct' => array(
			'3500'
		));
	$question[11] = array(
		'question' => 'Which statements about the recovery key system are true?', 
		'answers' => array(
			'If you order a new recovery key, Zeltonia cannot be held responsible if the confirmation key letter does not arrive due to an incorrect account registration.',
			'Only players with a premium account can request a recovery key.',
			'The 18-digit recovery key can be used to instantly register accounts to a new email address.',
			'The address in your registration can be changed instantly.'
		), 
		'correct' => array(
			'If you order a new recovery key, Zeltonia cannot be held responsible if the confirmation key letter does not arrive due to an incorrect account registration.'
		));
	$question[12] = array(
		'question' => 'Which statements about the isle Nargor are true?', 
		'answers' => array(
			'It is surrounded by a jungle.',
			'Nargor is the second largest isle of the Shattered Isles.',
			'Sharp reefs around Nargor make it hard for every ship to reach the coast.',
			'The isle contains a large volcano that rises in its middle.',
			'The isle is full of chakoyas.'
		), 
		'correct' => array(
			'Nargor is the second largest isle of the Shattered Isles.',
			'Sharp reefs around Nargor make it hard for every ship to reach the coast.'
		));
		$question[13] = array(
		'question' => 'What are the duties of a senior tutor?', 
		'answers' => array(
			'Answer questions on the world boards.',
			'Report illegal names via Ctrl+R.',
			'Report illegal names.',
			'Report illegal statements.',
			'Report illegal threads or posts. '
		), 
		'correct' => array(
			'Report illegal names.',
			'Report illegal statements.',
			'Report illegal threads or posts. '
		));
		$question[14] = array(
		'question' => 'What do you do as a tutor if you are told about an error (bug) in the game?', 
		'answers' => array(
			'Check if it is a real bug. If necessary, report it by using the bug report function.',
			'Ignore the report and don\'t do anything.',
			'Keep it secret and try exploiting it yourself.',
			'Post the news about the bug in the game channel and on the website forum.'
		), 
		'correct' => array(
			'Check if it is a real bug. If necessary, report it by using the bug report function.'
		));
		$question[15] = array(
		'question' => 'What do you do if you have forgotten your password?', 
		'answers' => array(
			'Contact the gamemasters.',
			'Upgrade your account to a Premium Account.',
			'Use the Lost Account Interface on the website.',
			'Write an email to Zeltonia.'
		), 
		'correct' => array(
			'Use the Lost Account Interface on the website.'
		));
		$question[16] = array(
		'question' => 'What does the login message "Account disabled for 5 minutes" mean?', 
		'answers' => array(
			'A gamemaster has banished you for 5 minutes.',
			'It is possible that somebody is trying to hack your account.',
			'The server is full. You should try again in 5 minutes.',
			'You or somebody else has entered an incorrect password five times in a row.',
			'Your account has been deleted.'
		), 
		'correct' => array(
			'It is possible that somebody is trying to hack your account.',
			'You or somebody else has entered an incorrect password five times in a row.'
		));
		$question[17] = array(
		'question' => 'What happens if your Premium Account runs out?', 
		'answers' => array(
			'All items in your house will be placed in your depot.',
			'You cannot visit Thais anymore.',
			'You will lose your houses.',
			'You will lose your tutor position.',
			'You will not be able to cast premium spells.',
			'Your account will be banished.',
			'Your characters will be reset to Rookgaard.',
			'Your promotions will be suspended.'
		),
		'correct' => array(
			'All items in your house will be placed in your depot.',
			'You will lose your houses.',
			'You will not be able to cast premium spells.',
			'Your promotions will be suspended.'
		));	
?>