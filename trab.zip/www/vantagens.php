<?PHP
// {made by Renato Ribeiro}

$main_content .= '<table border="0" cellspacing="1" cellpadding="3" width="100%"> 
	<tr> 
		<td colspan="2" class="titleForm"></td> 
	</tr> 
	<tr> 
		<td class="styleTD1"> 
			<p>&nbsp;<span style="font-size: medium;"><b><font color="#0099CC"/>Por que adquirir VIP?</font></b></span></p>

<br />

<p>*<i> Algumas das vantagems abaixa! ! </i> <br />

<br />

Por favor note que esta n&atilde;o &eacute; uma lista exaustiva. Muitos outros benef&iacute;cios n&atilde;o est&atilde;o listados. &Eacute; poss&iacute;vel que os atuais benef&iacute;cios sejam alterados ou at&eacute; mesmo eliminados no futuro. Adquira sua VIP Time hoje e aproveite o servidor em sua melhor forma!</p>

<p style="text-align: center;"></p> 
		</td> 
	</tr> 
</table> 

<center><table cellpadding="5" cellspacing="1"><tr><td width="500" colspan="3" bgcolor="#555555"><font color="white" size="3"><b>Vantagens de ser Vip Account</b></font></td></tr><tr><td width="500" bgcolor="#F1E0C6"><b>Feature</b></td><td width="125" bgcolor="#F1E0C6"><center><b>Conta Free</center></b></td><td width="125" bgcolor="#F1E0C6"><b><font color="#00FF00"/><center>Conta VIP</font></b></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">Acesso � cidades exclusivas para VIP</td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">Acesso � novas �reas de hunts</td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">N�o enfrente filas</td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">Acesso � todas as quests do servidor</td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1"><b><font color="red"/>Bonus +30% de exp</b></font></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">VIP List com mais capacidade</td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">Poder jogar no servidor livremente</td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>

<tr><td width="500" bgcolor="#D4C0A1">Depot com maior capacidade</td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>
  
  <tr>
  <td width="500" bgcolor="#D4C0A1"><b><font color="red"/>Regenera��o MP/HP mais r�pida</b></font></td>
  <td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>
  <tr>
  <td width="500" bgcolor="#D4C0A1"><b><font color="red"/>Menos perda de Experi�ncia na morte</b></font></td>
  <td width="125" bgcolor="#D4C0A1"><center><img src="/images/false.png" /></center></td><td width="125" bgcolor="#D4C0A1"><center><img src="/images/true.png" /></center></td></tr>
  <tr>
      <td width="500" bgcolor="#D4C0A1"><b><font color="red"/></font>Outfits exclusivos:</b> Insectoid Outfits ,Entrepreneur Outfits ,Elementalist Outfits ,Deepling Outfits.
        <center>
          <br />
        </center>
        <br /></td>
      <td width="125" bgcolor="#D4C0A1"><center>
        <img src="/images/false.png" />
      </center></td>
      <td width="125" bgcolor="#D4C0A1"><center>
        <img src="/images/true.png" />
      </center></td>
    </tr>
</table>
</center><h2><center>Clique abaixo e adquira seus pontos !</center></h2><h2><center><a href="index.php?subtopic=donate">Comprar Pontos</a></center></h2><br>'
?>