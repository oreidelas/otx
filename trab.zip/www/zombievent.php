<?php header("Content-Type: text/html; charset=ISO-8859-1", true); 
$main_content .= ' 


<br>
 <center> <h1> Zombie Event </h1>
  
<b></b><img src="images/zombie.jpg">
<br> <br> 
<b _moz-rs-heading="">O que � o Zombie Event?<br></b> 
<br> 
� um evento que acontece aos Domingos, Quartas e Sextas as 18:00 hrs no servidor.<br> 
<br> 
<br> 
<b>Como funciona?<br></b> 
<br> 
Quando estiver na hora ir� abrir um teleport no templo de Thais, basta voc� entrar e aguardar o tempo para inicio do Evento,<br> 
o objetivo do evento � correr dos zombies, a cada 20 segundos ira nascer um novo em alguma area randomica da arena, voc� deve correr pois se eles te tocarem voc� automaticamente
� retirado do evento e volta para o seu templo.<br> 
O ultimo jogador que sobrar vivo vencer� o evento.<br> 
<br> 
<b>Quais s�o os premios?<br></b> 
<br> 
Os premios variam entre sua posi��o, mais o ultimo jogador sempre ira ganhar 200k, uma Boots of Haste e um trof�u com o nome dele.
<br> 
';

?>